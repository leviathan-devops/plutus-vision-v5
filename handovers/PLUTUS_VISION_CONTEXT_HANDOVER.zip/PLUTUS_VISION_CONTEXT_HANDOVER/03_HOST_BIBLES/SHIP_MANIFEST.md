# SHIP_MANIFEST — plutus-browser

| field | value |
|---|---|
| package | `SHIP_PACKAGES/plutus-browser` |
| version | `2026.11.07-1` (supersedes 2026.11.06-1: that one was a bare runtime; this is the host tool) |
| source | `PLUTUS_VISION/plutus-browser/` |
| Electron | 28.3.3 (pinned: package.json + package-lock.json) |

## What is installed on deploy (DEPLOY.sh)

| artifact | installed at | sha256-16 |
|---|---|---|
| `cli/plutus-browser` | `~/.local/share/plutus-browser/plutus-browser`, linked at `~/.local/bin/plutus-browser` | `fbe74ce43b5564da` |
| `cli/actions.json` | `~/.local/share/plutus-browser/actions.json` | `776ad6644a512067` |
| `src/main.js` | `~/.local/share/plutus-browser/app/src/main.js` | `69880afaf36f585e` |
| `extension/index.ts` | `~/.omp/agent/extensions/plutus-browser/index.ts` (the `plutus_browser` tool) | `0cdb88466d577f6f` |
| `package.json` / `package-lock.json` | `~/.local/share/plutus-browser/app/` (npm ci) | `5ba408df7e8adde2` / `4f34a9481e501425` |

Verified this cycle: the package's own DEPLOY.sh was run and every installed file matched the packaged SHA (PACKAGE_AUDIT.md section e).

## Not verified

- `plutus_browser` through the omp tool surface: the extension compiles (`bun build` exit 0) and is installed, but omp binds extensions at session start, so it has not been called as a tool yet.
- (resolved 2026-11-07 later) Worker -> Workers VPC service 01a1b53f-a0b8-7de2-a193-78f0b6d5f835 -> named tunnel 972a42d8… -> local browser: PASS, see docs/TESTING_LOG.md.
- `eval` of a throwing expression returns the generic SURFACE_ERROR (docs/FAILURE_LOG.md, F-6).
