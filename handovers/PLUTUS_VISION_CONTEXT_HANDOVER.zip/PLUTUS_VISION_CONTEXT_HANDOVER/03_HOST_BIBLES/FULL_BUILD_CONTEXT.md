# FULL_BUILD_CONTEXT — plutus-browser

## Project identity

plutus-browser is a self-contained headed-browser runtime forked from the PLUTUS dashboard's browser tab. It exists because investinglive.com returns `403 Request blocked` (CloudFront) to headless browsers, and the canon prompt (Trident_System_Prompt_v5.3.3, Protocol A) requires reading that page's expiry data. The fork provides one Electron window with a loopback HTTP control server, so a Cloudflare Worker (the eventual pi-durable mechanical workflow) can drive it through a Cloudflare Tunnel.

## Architecture

```
CLOUDFLARE (the compute)                LOCAL (the one headed step)
  WORKER /run {pair, week}                plutus-browser (Electron 28.3.3)
    DURABLE OBJECT PvSidecar               ┌────────────────────────┐
      (pi-durable harness)                 │ BrowserWindow :6       │
      mechanical workflow, no loop         │ investinglive.com      │
           │                               │ forexfactory.com       │
           ├─ fetch() ────► TreasuryDirect  │ tradingview.com        │
           ├─ BROWSER RUN ► ForexFactory    └──────────┬─────────────┘
           ├─ CLAIRIC ────► reads an image             │
           ├─ CLEF ───────► judges receipts  ┌──────────▼─────────────┐
           │                                 │ control server :9470   │
           └─ HEADED ─────► via Tunnel ────► │ /navigate /eval        │
               (the one local step)          │ /capture /images       │
                                             │ /back /forward /reload│
                                             │ /input /status /health│
                                             └────────────────────────┘
```

## Key files

| File | Lines | Role |
|---|---|---|
| `src/main.js` | 198 | The entire runtime: BrowserWindow + control server + all handlers |
| `package.json` | 9 | Pins Electron 28.3.3; no other dependencies |
| `upstream/view-surfaces.js` | 378 | The dashboard's LIVE handlers (the port source; read-only copy) |
| `upstream/surface.js` | 370 | The dashboard's standalone runner (the boot pattern; read-only copy) |
| `upstream/PROVENANCE.md` | 8 | The source SHAs and what was taken from each |
| `docs/BUILD_REPORT.md` | 124 | What was built, why, how, the evidence |
| `docs/TESTING_LOG.md` | 85 | The test plans + results (all live, no unit tests) |
| `docs/DEBUG_LOG.md` | 51 | 4 bug/fix/lesson entries |
| `docs/FAILURE_LOG.md` | 51 | 5 failure entries (2 open, both operator dashboard edits) |

## Design decisions

1. **Electron 28.3.3, not newer** — the dashboard's pinned version; `navigationHistory` (Electron 31+) is not used, `canGoBack/goBack` (Electron 28) is used instead. This avoids the bug the dashboard's own standalone mode has.

2. **One process, not 26** — the dashboard's browser tab carries 26 processes (Xvfb, weston, MT5, 5 servers, SQLite, terminal bridge, agent display). The fork is one Electron process with one BrowserWindow and one HTTP server. 253 MB vs the dashboard's full footprint.

3. **Bearer token, not session-based** — the token is 64 hex chars in `~/.plutus-browser/token` (mode 600). Every route except `/health` requires it. The token is compared with `crypto.timingSafeEqual`. No session, no cookies, no expiry — one token, one file.

4. **Loopback-only by default** — the server binds to `127.0.0.1`. The Cloudflare Tunnel makes it reachable from outside without opening a port.

5. **The LIVE handlers, not the standalone** — the dashboard has two implementations of the same browser-control behaviour: `view-surfaces.js` (the LIVE path, used by the dashboard's tab) and `surface.js` (the standalone path, which broke). The fork ports the LIVE one.

6. **No renderer UI** — the fork has no HTML page, no renderer script. The BrowserWindow loads the target page (investinglive, ForexFactory) directly. There is no "browser UI" — the control is entirely via the HTTP routes.

## Implementation patterns

- **The loud-fail-or-clear-pass law:** every required input has exactly one source. A missing input produces a named error with the fix, and a nonzero exit. No defaults, no fallbacks, no guessing.
- **The mechanical router:** the control server is a plain HTTP router — pathname → handler → JSON response. No middleware, no framework, no model. This is R-21's "mechanical workflow" at the micro level.
- **The provenance copy:** the upstream sources are copied read-only into the package, with their SHAs recorded. This makes the fork's lineage verifiable without the source repo.

## Known bugs (open)

1. The named Cloudflare Tunnel cannot be created from this session (missing `argotunnel.write` permission). The quick tunnel proved the path works.
2. The system DNS resolver cannot resolve `trycloudflare.com` (systemd-resolved limitation). The `--resolve` workaround bypasses it. The named tunnel uses a different zone, avoiding the issue.

## Operational knowledge

- **Start:** `DISPLAY=:N ./node_modules/.bin/electron . --port=9470`
- **Verify:** `curl http://127.0.0.1:9470/health` → `{"success":true,"data":{"up":true,"pid":...}}`
- **Navigate:** `curl -H "Authorization: Bearer $(cat ~/.plutus-browser/token)" "http://127.0.0.1:9470/navigate?url=https://investinglive.com/Orders/"`
- **Extract data:** `curl -H "$AUTH" -G --data-urlencode "js=document.body.innerText" http://127.0.0.1:9470/eval`
- **Capture:** `curl -H "$AUTH" http://127.0.0.1:9470/capture | python3 -c 'import json,sys,base64;d=json.load(sys.stdin);open("out.png","wb").write(base64.b64decode(d["data"]["png_base64"]))'`
- **Stop:** kill the Electron process (the control server closes with the window)
- **Tunnel:** `cloudflared tunnel --url http://127.0.0.1:9470` (quick) or a named tunnel for production

## Compaction recovery

If you are a fresh agent reading this after a compaction:
1. Read `MASTER_CONTEXT/OPERATOR_RULINGS_PV.md` — rulings R-12 through R-26 govern everything
2. Read `docs/BUILD_REPORT.md` — what was built and why
3. Read `docs/TESTING_LOG.md` — what was verified and how
4. Read this file — the architecture and the operational commands
5. The runtime is at `PLUTUS_VISION/plutus-browser/` (source) and `SHIP_PACKAGES/plutus-browser/` (shipped)
6. The dashboard source was NEVER written — verify with `git -C .../dashboard log --oneline -1` (HEAD should not change from what PROVENANCE.md records)

## UPDATE 2026-11-07 — THE OPERATIONAL KNOWLEDGE ABOVE IS SUPERSEDED BY THE HOST TOOL

Start/stop/verify are no longer hand-run Electron commands. Install with `bash DEPLOY.sh`; run with
`plutus-browser --session NAME up --url <u>` / `text` / `shot` / `down` (README.md). Instances are computer-use v2 core
instances (ids 10..99, control port 30000 + id, one profile per port). The token stays at ~/.plutus-browser/token (0600).
Installed SHAs this version: CLI `fbe74ce43b5564da`, verb table `776ad6644a512067`, main.js `69880afaf36f585e`, extension `0cdb88466d577f6f`.
Compaction recovery: read OPERATOR_RULINGS_PV.md (R-12..R-26), docs/BUILD_REPORT.md (2026-11-07 section), docs/TESTING_LOG.md, docs/THEATRICALITY_LOG.md (what is NOT verified).
