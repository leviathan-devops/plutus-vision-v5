# Pinebox - Operator Manual

| | |
|---|---|
| **What you operate** | `pinebox`: a headed Pine IDE and Backtest room that you start, look at, switch, drive and judge from a shell or from an omp session. It runs on its own private display, in its own browser, with its own data. |
| **Version** | deployment fingerprint `ae76ebcf094c3e1ee671c1fab4befe8045adbf7ba5dc63109d571efff43645b2` (sha256 of `cu-v2/MANIFEST.sha256`, 712 rows) - repo `2fcd5ac` - built 2026-11-08 |
| **Your job** | See a Pine script or a backtest replay actually rendered, on a display you can open and read, and get a judged verdict that it works. |
| **Companions** | WHY it is designed this way: `design/DESIGN_BLUEPRINT_PINEBOX.md`. WHAT is true about it: `FULL_BUILD_CONTEXT.md` and `context_management/`. HOW to use it: this file. `pinebox` runs on `computer` (computer-use v2): the manual for that tool is the README of the `computer-use-v2` repository. |

## 0. READ THIS FIRST — WHICH PINBOX, WHICH DATA, WHICH INTERFACE (as of 2026-11-08, checkpoint `ship-approved-nov-8`)

**Two placements, one product.** The same CLI and the same page run in two places:

| placement | start verb | where it renders | who sees it |
|---|---|---|---|
| **cloud (the operator's product)** | `pinebox spawn-cloud-mac` | a native browser tab on the paired Mac (Orca `open-url`) | the operator, on their own screen |
| **cloud (this Linux box)** | `pinebox spawn-cloud-linux` | a native browser tab in this machine's Orca window | whoever looks at the Linux display |
| **local (no browser, no network)** | `pinebox spawn-local` | a private weston display on this box | only you, via `shot`/`view` |

- **The cloud page is what the operator runs.** URL: `https://pinebox-cloud.cryptoforex36963.workers.dev/i/<session>:<id>?k=<session>`. Pine, the chart engine and the backtest room run **in that browser**; the CLI drives them over the network by verb name. Nothing is streamed, and nothing runs on this host for the cloud mode.
- **If the operator says "Pinebox" without a placement, the answer is the cloud page on their machine** (`spawn-cloud-mac`). Use `spawn-local` only for a quick check with no network.
- **The data is the TradingView bar store, not a fixture week:** TVC:DXY, FX:EURUSD, FX:GBPUSD at 15m/30m/1H/4H, **2 Feb 2025 to the last fetch** (265 month files in `data/tv-bars/`; `pinebox data --op fetch-latest` tops it up). A backtest session is a DATE WINDOW over that store; any timeframe is a VIEW of the same session.
- **The cloud worker ships in the package** under `src/pinebox-cloud/` (worker + `dist-web/` served assets + `wrangler.jsonc`): a blind operator can rebuild and redeploy it with the commands at the end of `design/HOW_PINEBOX_CLOUD_WAS_BUILT.md` (the CF token comes from `~/.config/pinebox/cf.env`, never from the docs).
- **An agent-facing operating skill ships with this package:** `skills/pinebox/SKILL.md` (single self-contained file, validator PASS) plus its slash-command companion `skills/pinebox/command/pinebox.md`. Install them into `~/.omp/agent/managed-skills/pinebox/` and `~/.omp/agent/commands/` (plural — OMP discovers `commands/`, a file under `command/` is inert) — a blind agent then has the placement table, the verb map, the refusal table and the proof rule in one file. The operator's own one-keystroke launcher is `~/.omp/agent/commands/pinebox-cloud.md`: `/pinebox-cloud` starts Pinebox in an Orca tab on the Mac (one tool call, no arguments).
- **Read next, in this order:** `design/HOW_PINEBOX_CLOUD_WAS_BUILT.md` (how the cloud version was built, checkpoint by checkpoint), `design/CLOUDFLARE_ARCHITECTURE_PINEBOX_CLOUD.md` (routes/objects/config, measured), then section 1 for the verbs.

Every command below was run on a cold session before it was written down. Samples are real output. A line that starts with `REFUSED` is the tool saying no; the token after it is the thing to look up in section 6.

---

## 1. WHAT THIS IS FOR

**The one outcome:** a Pine indicator (or a Backtest replay session) is drawn on a chart you have looked at, `pinebox verify` says `WORKS`, and you can say which asset, timeframe and week you looked at.

**Use it when you need to:**
- load a Pine script and see it on candles (`load`, `run`, `insert`);
- switch between the three assets and four timeframes and watch the chart change (`asset`, `tf`, `week`);
- replay a backtest session bar by bar, create sessions for other markets, place simulated orders (`tab`, `backtest`, `drive`);
- get an independent judged verdict on a rendered chart (`verify`);
- run another GUI program inside the same private display (`spawn`).

**Do not use it when you need:**
- real or live market data (the data is the harvested TradingView store, Feb 2025 -> the last fetch: exact bars, refreshed with `pinebox data --op fetch-latest`; never a live feed);
- an HTTP API, a trading account, TradingView, or anything on the internet at run time;
- to see something on the human operator's own screen - you may not raise a window unless they asked (`view --confirm`, section 4 A-12);
- a Windows or macOS machine (Linux x86_64 only).

---

## 2. BEFORE YOU START

Tick every line. Each has a command and the answer you must get.

| # | Check | Command | You must see |
|---|---|---|---|
| C-1 | the system programs exist | `for b in bash python3 node npm jq curl rsync tar weston Xwayland xdotool tmux; do command -v $b >/dev/null \|\| echo MISSING $b; done` | nothing printed |
| C-2 | the display layer works | `computer doctor` | last line `VERDICT   DRIVEABLE` |
| C-3 | the CLI is installed | `pinebox list --session check-one` | `{"ok":true,"instances":[]}` |
| C-4 | the pinned browser is installed | `~/.local/share/pinebox/runtime/chrome/chrome-linux/chrome --version` | `Chromium 159.0.8143.0` (or the build in `~/.local/share/pinebox/BROWSER_VERSION`) |
| C-5 | the Pine engine is installed | `ls ~/.local/share/pinebox/fork/pine-ide/pine-station/node_modules/pinets` | a directory listing, not `No such file` |
| C-6 | the judge answers | `curl -s http://127.0.0.1:8090/health` | `{"ok":true,"model":"imajev-4b",...,"modalities":["text","image"]...}` |
| C-7 | you have a session name | pick `my-run-1` | 4 to 80 characters of `A-Z a-z 0-9 . _ -` |
| C-8 | a graphical session is logged in on this machine | `echo $DISPLAY` | something like `:1` (if empty, add `--adapter xvfb` to `up`) |

If C-3 to C-5 fail, install the package (section 7, "Install"). If C-6 fails, `verify` will refuse `JUDGE_DOWN`; everything else still works.

---

## 3. THE QUICK START (the 80% case - 7 steps)

Replace `my-run-1` with your session name. Use the same name in every command. (From an omp session you do not pass `--session`: the host supplies it.)

1. **Start it.**
   `pinebox up --session my-run-1 --pine ~/.local/share/pinebox/test/fixtures/ema-ribbon.pine`
   You see `pinebox up  instance 1`, then `week      2026-W28`, then a `load` line ending in `"bars":508,"onChart":6`. It takes about 10 seconds.
2. **Look at it.**
   `pinebox shot --session my-run-1 --out /tmp/pb-1.png` then open `/tmp/pb-1.png` with an image reader. You must see DXY candles, a yellow and a blue line, green triangles.
3. **Switch the market.**
   `pinebox asset --session my-run-1 --set EURUSD --tf 4H`
   You see `{"ok":true,...,"symbol":"EURUSD","timeframe":"4H","bars":128,...}`. Shoot again (step 2) and read the frame: the price axis is now around 1.13.
4. **Open the Backtest tab and step the replay.**
   `pinebox tab --session my-run-1 --to backtest` then `pinebox backtest --session my-run-1 --op step --n 3`
   You see `"moved":3` and a `cursor` three higher than before.
5. **Go back and judge it.**
   `pinebox tab --session my-run-1 --to pine` then `pinebox asset --session my-run-1 --set DXY --tf 1H` then `pinebox verify --session my-run-1`
   You see `{"verdict":"WORKS",...}`.
6. **Open the final frame** (`pinebox shot ... --out /tmp/pb-2.png`) and read it. A verdict without a frame you have opened is not a result.
7. **Shut it down.** `pinebox down --session my-run-1 --all` -> `{"ok":true,"down":"all","instances":1}`.

If any step prints `REFUSED`, go to section 6 with the token.

---

## 4. THE FULL PROCEDURE

Each action: PRECONDITION - ACTION - EXPECTED - IF NOT - PROVES. `--session NAME` is on every command; leave it out only inside an omp session.

### A-1 Choose a session name
- PRECONDITION: none. ACTION: pick a name of 4-80 characters from `A-Z a-z 0-9 . _ -`. EXPECTED: any command accepts it. IF NOT: `REFUSED BAD_SESSION` -> pick a longer name. PROVES: every instance you make belongs to you; nobody else can address it and you cannot address theirs.
- Without `--session` outside an omp session you get `REFUSED NO_SESSION`.

### A-2 Bring an instance up
- PRECONDITION: C-1..C-6. ACTION (the START VERBS: the verb name IS the placement, no other argument): `pinebox spawn-cloud-mac --session S` | `pinebox spawn-cloud-linux --session S` | `pinebox spawn-local --session S`. The low-level form below is only for a pinned id or an explicit adapter: `pinebox up --session S [--surface local|orca] [--pine FILE] [--pair DXY|EURUSD|GBPUSD] [--tf 15m|30m|1H|4H] [--week 2026-W28] [--adapter weston-x11|weston-vnc|xvfb]`.
- Defaults: week `2026-W28`, pair `DXY`, tf `1H`, adapter `weston-x11` (a window on your own desktop display, kept behind your work).
- EXPECTED (verbatim from a cold run):
```
pinebox up  instance 1
  shell     :6 (weston-x11) host window 0x2600005
  services  station :9841 · rail :9854 (up) · server :9951  (apiBase/pineStation verified in the served bytes)
  room      :9543  (own db, own HOME; /health names this port)
  page      chrome in a window on :6 · CDP :9322 · profile /run/user/1000/pinebox/i1/chrome
  frame     /run/user/1000/pinebox/i1/frame.png  (144028 bytes, 283 colours, CDP capture)
  week      2026-W28 (the IDE control now reads 2026-W28)
  load      ema-ribbon.pine  DXY 1H  -> {"bars":508,"onChart":6,"counts":{"plots":2,"plotPoints":800,"markers":4,...
```
- **`--surface orca` (browser mode):** only when the operator says "browser mode" or asks to see Pinebox in Orca. The page opens as a tab of Orca's browser in YOUR worktree (the one your session runs in), so everyone connected to the Orca server sees it beside your session. Every other verb works exactly the same. Orca must be running on this machine. EXPECTED: the `page` line reads `page      Orca tab <page-id> · CDP :<port> · TZ_HELD UTC 0` and the last line `READY     instance 1  slot :6  surface orca (Orca tab <page-id>)`; `list` shows `"surface":"orca","page":"<page-id>"`. The frames are the size of the tab in Orca (walked: 1569x969), not 1626x931 - take a `shot` before you read click positions off it. IF NOT: `REFUSED ORCA_UNAVAILABLE` = no Orca CLI on this machine (use the default); `REFUSED ORCA_TAB_FAILED` = Orca refused the tab (the message is Orca's own; start Orca, then `up` again).
- Without `--pine` the IDE opens on its own buffer script. With `--pair EURUSD --tf 4H --pine FILE` the `load` line reads `EURUSD 4H -> {"bars":128,...`.
- IF NOT: a second `up` in the same session prints `REFUSED INSTANCE_LIVE - pinebox instance 1 is already running - run: pinebox down --id 1`. PROVES: an instance exists, its services answer, a frame was captured.

### A-3 Find out what is running
- `pinebox list --session S` (your instances and ports), `pinebox status --session S` (week, pair, tf, pids, memory), `pinebox ports --session S` (which process holds each port).
- EXPECTED `list`: `{"ok":true,"instances":[{"id":1,"slot":"6","adapter":"weston-x11","ports":{"station":9841,"rail":9854,"server":9951,"cdp":9322,"ws":10031,"vnc":5901,"room":9543},...`. IF NOT: `"instances":[]` means you have none - run A-2. You never see other sessions' instances. PROVES: the instance is alive and which ports are yours.

### A-4 Look at it (this is how you check anything)
- `pinebox shot --session S --out /tmp/x.png [--section chart|plot]` captures the page through the browser. `--section chart` is the whole chart workspace (1042x841), `--section plot` is the plotting area only (998x764); without it you get the whole 1626x931 window.
- `pinebox look --session S --out name.png` captures through the display; the file lands in the instance folder (`/run/user/1000/pinebox/iN/name.png`); a path with `..` is refused `SCOPE_VIOLATION`.
- EXPECTED: `{"ok":true,"path":"/tmp/x.png","bytes":62492,"colours":403,"via":"cdp","section":"chart","c3":"held"}`. `c3:"held"` means the human operator's focus did not move.
- You must open the PNG with an image-capable reader and read it. Name what you see: the chart title (symbol, timeframe), the price axis range, the date axis, the lines and markers, and the status row under the editor (`FIXTURE · DXY · 1H · 508 bars` - the bar count is read from that row or from `asset --get`, not counted from pixels). `colours` near 1 means a blank frame. If you have no image reader you cannot complete this step: say so in your report and rely on the JSON fields, never claim you looked.

### A-5 Switch asset, timeframe, week
- `pinebox asset --session S --set EURUSD [--tf 4H]` - assets: `DXY`, `EURUSD`, `GBPUSD`. `pinebox asset --session S --get` reads the current one.
- `pinebox tf --session S --tf 30m` - timeframes: `15m`, `30m`, `1H`, `4H`. `pinebox tf --session S --get` reads it. **`tf` acts on the tab that is visible:**
  - on the PINE IDE tab it switches the IDE chart (answer `{"ok":true,...,"timeframe":"30m","bars":5000,"market":{...}}`);
  - on the BACKTEST tab it switches the room chart's VIEW of the attached session - never a new session, never the replay clock: answer `{"ok":true,"surface":"backtest","timeframe":"30m","bars":10542,"session":"bt-..."}`. A finer view than the session's own timeframe shows the store's real 15m/30m bars up to the replay clock (the last 15m bar closes with the current 1H bar); a coarser one aggregates the bars the replay has revealed (the newest 4H bar is still forming). Measured: 191-207 ms locally, 0.7-2.4 s through the cloud relay.
  - refusals: `REFUSED TF_SET_FAILED - unsupported timeframe "1D" (15m, 30m, 1H, 4H)`; on the backtest tab `--symbol` is `REFUSED BAD_ARGS - in the backtest room a symbol is a session (backtest --op create|open); tf changes the view only`; `ROOM_VIEW_TF_FAILED` if the chart does not show the timeframe within 5 s.
- `pinebox week --session S --set 2026-W28` (or `--get`). Only weeks that have a fixture file exist; a bad label is `REFUSED BAD_ARGS`.
- The data is the TradingView store (TVC:DXY, FX:EURUSD, FX:GBPUSD; 15m, 30m, 1H, 4H; 2 Feb 2025 to the last fetch). The Pine IDE chart holds the newest 5000 bars of a cell (4H: all of them - DXY 4H measured 2832). `pinebox data --op fetch-latest` tops every series up to now.
- EXPECTED: `{"ok":true,"id":1,"verb":"asset","symbol":"EURUSD","timeframe":"4H","bars":128,"market":{"symbol":"fixture:EURUSD","provider":"fixture","timeframe":"240",...}}`.
- IF NOT: `REFUSED ASSET_ABSENT - unsupported instrument 'XYZ' (DXY, EURUSD, GBPUSD)` or `REFUSED TF_SET_FAILED - unsupported timeframe '7m' (15m, 30m, 1H, 4H)`; the chart is put back where it was. You can also click the chart's own symbol button and timeframe menu with `drive` (A-8); both lists contain only these markets.
- PROVES: the page changed market. Read the frame to prove it drew.

### A-6 Run a Pine script
- `pinebox load --session S --pine FILE [--pair P --tf T]` puts the script in the editor, runs it on the bars and checks the drawing. `pinebox run --session S --pine FILE` runs it; `pinebox insert --session S --pine FILE` only inserts it into the editor; `pinebox editor --session S --mode get` prints the editor's source.
- EXPECTED `load`: the same `"bars":508,"onChart":6,"counts":{"plots":2,...}` as in A-2.
- IF NOT: `REFUSED PINE_ABSENT` (path wrong) or `REFUSED PINE_COMPILE_FAILED` (the script has an error; the message carries the compiler's line); `REFUSED NO_DRAWINGS` (it ran and drew nothing).
- PROVES: the script compiled and drew; the frame (A-4) proves what it drew.

### A-7 Get a judged verdict
- `pinebox verify --session S` - the arithmetic checks, then an independent judge reads a fresh capture. `--arith` runs the arithmetic only and can only answer `UNJUDGED` (never `WORKS`). `--clause C1.1,C1.2` demands named clauses. `pinebox phase --session S --close PHASE` closes a phase when all its clauses hold signed tickets.
- EXPECTED: `{"verdict":"WORKS","verify":{"ok":true,"id":1,"week":"2026-W28","verdict":"ARITH_OK","checks":[{"check":"rail","ok":true,...` followed by one judge ticket per clause asked. WHICH clauses are asked: the universal two (C0.1, C1.2) on every frame; a script's own clauses when its file name is bound (`ema-ribbon.pine`: C1.1, and C1.3 only when the run drew 2 or more crossover markers - a cell with fewer reports it under `judge.unbound` with the reason); the week's month clause when one is calibrated (July 2026 -> C2.1). So your own script on DXY 1H week 2026-W28 is judged on C0.1 C1.2 C2.1 - on both shells.
- IF NOT: see section 6 (`JUDGE_DOWN`, `NO_SCRIPT_LOADED`, `WEEK_MISMATCH`, `JUDGE_FAILED` with the clause that failed).
- **It only judges 1H and 4H cells** (section 9). PROVES: the chart drew what the script says, on the week loaded.

### A-8 Move the chart and click things
- `pinebox chart --session S --op fit|zoom|pan|view [--dir IN|OUT] [--dx 0.2]` - `fit` frames every bar, `view` only reads. EXPECTED: `{"ok":true,...,"op":"fit",...,"after":{"range":{...},"allBarsInView":true,"total":508}}`. `--op resize` is always `REFUSED RESIZE_UNSUPPORTED`.
- `pinebox widget --session S --action list|open|close [--name N]` - the editor/face/verdict/focus toggles. `list` shows names; an unknown name is `REFUSED WIDGET_NOT_FOUND`.
- `pinebox drive --session S --action click --x X --y Y` / `--action type --text T` / `--action key --key Escape` drives the page. **X and Y are the ORIGINAL pixel coordinates of a `pinebox shot` PNG** (the window is 1626x931 and the PNG is the whole window). If your image viewer shows the PNG scaled (for example 1568x898), multiply the coordinates you read by 1626 divided by the width it shows (about 1.04) before you click. Take a shot, read the position off it, then click. A click outside the page is refused `COORD_OUT_OF_SCREEN`.
- PROVES: the chart moved (shoot again and compare).

### A-9 Use the Backtest tab
- `pinebox tab --session S --to backtest` (and `--to pine` to come back). EXPECTED: `{"ok":true,"id":1,"verb":"tab","active":"backtest","ready":{"ready":true,"room":true,"speed":true,"timeline":true}}`.
- The tab opens ON a running session by itself: DXY 1H, 382 bars, replay at bar 216 (2026-07-03 00:00 UTC), window 2026-07-03 .. 2026-07-14. Read it: `pinebox backtest --session S --op state` (`cursor` counts from zero: `cursor 215` is the replay strip's `bar 216 / 382`) -> `{"ok":true,...,"state":{"uid":"bt-...","cursor":215,"playing":false,"rate":1,...,"barsTotal":382}}`.
- Replay controls: `--op step --n 3` (EXPECTED `"moved":3`), `--op play`, `--op pause`, `--op speed --speed 10` (0.5, 1, 2, 5, 10, 25), `--op date --date 2026-07-05` (inside the window; outside is `REFUSED DATE_OUT_OF_RANGE - 2026-07-02 is outside the session's window (2026-07-03 .. 2026-07-14)`), `--op stop`, `--op session` (ensure one exists).
- **Create a session** (the same fields as the room's NEW SESSION form - session name, description, strategy, symbol, start date, end date, start balance; there is no data type: every session reads the full store): `pinebox backtest --session S --op create --name NAME --symbol DXY|EURUSD|GBPUSD --start 2025-06-02 --end 2025-07-01 [--balance 25000] [--strategy BS] [--description TEXT] [--tf 1H]`. `--start`/`--end` take `YYYY-MM-DD[THH:MM]` UTC: the replay begins on the first bar at/after `--start` with every earlier bar visible as history; `--tf` is only the session's replay timeframe (default 1H) - the chart can show any of the four timeframes afterwards. Refusals: a bad date or an end not after the start is `REFUSED BAD_ARGS`; a symbol the store lacks is `REFUSED BARS_STORE_ABSENT - the bar store carries DXY, EURUSD, GBPUSD - not XAUUSD`. `--op list` returns each session's `start_date`, `end_date`, `strategy`, `description`, `starting_balance`. The room creates it and the pane switches to it; EXPECTED `{"ok":true,...,"op":"create","result":{...,"session":"bt-...",...},"state":{"uid":"bt-...",...}}`. The NAME must be unique (the pane finds a session's row by its name): a taken name is `REFUSED SESSION_NAME_TAKEN` and nothing is created. `--balance` is the STARTING BALANCE field (default 10000, as the form).
- **Room answers** carry `canon_path` + `canon_error`: `LOCAL_STORE` means the session's summary columns were written to the room's own store; `canon_error` names why the external canon journal was not used (locally `CANON_TOKEN_UNAVAILABLE: PLUTUS_BACKTEST_TOKEN is not set` - the token is an operator's own setting; the backtest itself does not depend on it). `ROUTE` means the canon journal took them.
- **List scope**: locally `--op list` shows the sessions in THIS instance id's store (`~/.local/share/pinebox/store/room-<id>.db`: every run that used the same id); in cloud mode it shows the ONE durable backtest library every cloud instance shares (sessions from other runs included). Pick yours by the unique `--name` you created it with.
- **Switch between sessions**: `pinebox backtest --session S --op list` (every durable session: `session_uid`, `name`, symbol, timeframe, cursor, balance, fills), then `--op open --uid bt-...` - the pane switches to it (read back: `state.uid`). Two sessions with the same name cannot be told apart in the pane: `REFUSED SESSION_SWITCH_AMBIGUOUS`.
- **Orders** (the room's own order API, the same on the cloud shell): `--op place --side buy|sell --type market|limit|stop --qty UNITS [--price P for limit/stop] [--sl P] [--tp P]`; `--op modify --order ID --sl P | --tp P` (ID = a WORKING order `O…`, or an OPEN position `P…` from `state.positions[].id`: a filled order lives on as its position - modifying the filled `O…` is `ORDER_NOT_FOUND ... it became position P2`); `--op cancel --order O1`; `--op close [--pct 1..100]`; `--op note --text "..." [--tags a,b]`; `--op export` (the journal: `fills`, `events`, `summary`); `--op delete --uid bt-...`. Each answers the room's own reply under `result` plus the pane `state`. Read the LIVE position (its id `P…`, entry, `sl`, `tp`) from `--op state` -> `status.positions[]` (local and cloud alike; `status.recentFills` and `status.closedTrades` are there too), and the journal from `--op export` (`fills`: one row per entry/exit with price, qty and pnl). A position's settled values (`sl` = its INITIAL stop, `tp`, `r_multiple`, `position_pnl`, `position_bars`) are on its EXIT row only - the row that settles the trade; its entry and partial rows carry null in those columns (the live SL/TP while it is open are in `status.positions[]`). Refusals: `BAD_ORDER`, `BAD_PRICE`, `BAD_PCT`, `NO_SESSION`, `BAD_LEVEL` (an SL/TP on the wrong side of the entry reference - the last visible close for a market order, `--price` for limit/stop: a buy's SL below and TP above it, a sell's the reverse; read the close from `--op state` -> `status.now.bar.close` before sizing), the room's own (`UNSUPPORTED` hedging - cancel the working order or close first; `POSITION_NOT_FOUND`; `ORDER_NOT_FOUND` - no such id, or a filled/cancelled order), `BACKTEST_ROOM_DOWN` when the pane has no room. `--rate` is cloud-only (`CLOUD_ONLY_FLAG`): the local rate is `--op speed --speed X`.
- **Switch the room chart's timeframe**: `pinebox tf --session S --tf 4H` with the BACKTEST tab visible (or the chart's timeframe menu) - one session, any timeframe: the session, its clock and its fills do not change. A SYMBOL is a session: create or open one (`--op create|open`). A market the store lacks is refused by name on the page and the replay stays.
- Orders: the ticket is on the right. Take a `shot`, read the position of BUY (or SELL) and of PLACE ORDER, click BUY then PLACE ORDER with `drive` (walked on a fresh tab: BUY `x=1352 y=140`, PLACE ORDER `x=1472 y=541` in original pixels). A market order fills now at the last visible close: the JOURNAL shows `BUY 10,000 <price>` and the OPEN POSITION panel shows the side, size, entry, SL, TP and open P&L at once. `backtest --op state` does not change; a `step` afterwards moves the replay and the open P&L with it.
- PROVES: `state` shows the session and bar position you meant; the frame shows the same ticker and bar count.

### A-10 Run another program in the instance
- `pinebox spawn --session S --cmd "zenity --info --text hi"` starts a second instance whose first window is that program; a missing program is `REFUSED CMD_NOT_FOUND` and nothing is created. `pinebox attach --session S --id N` re-binds you to one of YOUR running instances and returns a fresh capture.

### A-11 Terminal and key-value store
- `pinebox terminal --session S --send "echo hi"` then `pinebox terminal --session S --read --lines 5` -> `{"ok":true,"session":"cu-1-0","text":"echo hi\n...$ echo hi\nhi\n..."}`. `pinebox state --session S --put k --value v` then `--get k` -> `{"ok":true,"key":"k","value":"v",...}`.

### A-12 Show it to the human operator
- Only when they asked. `pinebox view --session S --confirm` raises the instance's window on their display (on the orca surface: brings its tab to the front in Orca, answer `{"ok":true,...,"shown":"orca tab"}`). Without `--confirm` it is `REFUSED VIEW_UNCONFIRMED`. Never use it to "check" something yourself - use A-4.

### A-13 Tear down
- `pinebox down --session S --all` (or `--id N`). EXPECTED `{"ok":true,"down":"all","instances":1}`. Prove it: `pinebox list --session S` -> `"instances":[]` and `computer shell list --session S` -> `"instances":[]` (the `session` field in the `computer` answer is shortened for display - `drill-pb-two` shows as `drill-pb`; the empty `instances` list is the proof). On the orca surface `down` also closes the instance's Orca tab. Do this every time: an instance holds about 700 MB. `pinebox down --id 0` on someone else's id is `REFUSED SESSION_FOREIGN`.

### A-14 Use it from an omp session
- The tool is called `pinebox`; the host supplies the session. Call it with `verb` and the same names as the flags: `verb=up pine=/abs/path.pine`, `verb=asset symbol=EURUSD tf=4H` (`set` also works), `verb=tab to=backtest`, `verb=backtest op=step n=3`, `verb=shot out=/tmp/x.png section=chart`, `verb=verify`, `verb=down all=true`. The sister tool `computer` takes `action=shell_up|shell_spawn|screenshot|...` (see the computer-use-v2 manual).
- A session that was started BEFORE the tools were installed still runs the old ones: start a new omp session.

---

## 5. WHAT YOU SHOULD SEE (real output)

| Command | Output |
|---|---|
| `pinebox asset --get` | `{"ok":true,"id":1,"recorded":{"symbol":"DXY","timeframe":"1H"},"page":{"bars":508,"market":{"symbol":"fixture:DXY","provider":"fixture","timeframe":"60","bars":5000,"offline":false}}}` |
| `pinebox week --get` | `{"ok":true,"id":1,"week":"2026-W28","recorded":"2026-W28"}` |
| `pinebox shot --section chart` | `{"ok":true,"path":"/tmp/mw-chart.png","bytes":62492,"colours":403,"via":"cdp","section":"chart","c3":"held"}` |
| `pinebox chart --op zoom --dir IN` | `{"ok":true,"id":1,"verb":"chart","op":"zoom","before":{"range":{...},"width":934,"height":742},"after":{...},"settled_ms":1381}` |
| `pinebox widget --action list` | `{"ok":true,"id":1,"verb":"widget","widgets":[{"name":"editor","pressed":true},{"name":"face","pressed":true},{"name":"verdict","pressed":false},{"name":"focus","pressed":false}],"panes":[...]}` |
| `pinebox backtest --op step --n 2` | `{"ok":true,"id":1,"verb":"backtest","op":"step","moved":2,"partial":false,"requested":2,"before":{...},"state":{...}}` |
| `pinebox drive --action click --x 135 --y 327` | `{"ok":true,"verb":"click","x":135,"y":327,"button":"left","via":"cdp","c3":"held"}` |
| `pinebox verify` | `{"verdict":"WORKS","verify":{"ok":true,"id":1,"week":"2026-W28","verdict":"ARITH_OK",...}}` |
| `pinebox down --all` | `{"ok":true,"down":"all","instances":1}` |

Appendix A lists every verb with its exact syntax and real output.

---

## 6. WHEN IT GOES WRONG - SYMPTOM -> ACTION

A refusal prints `REFUSED  TOKEN  -  message` on stderr and exits 1. Read the token; do the action.

| SYMPTOM (token) | ACTION |
|---|---|
| `NO_SESSION` | add `--session NAME` (outside an omp session you must). |
| `BAD_SESSION` | the name must be 4-80 characters of `A-Z a-z 0-9 . _ -`. |
| `NO_INSTANCE` | you have no instance: run A-2. |
| `INSTANCE_LIVE` | you already have one: use it (`list`), or `down --id N` then `up`. |
| `SESSION_FOREIGN` | that id belongs to someone else. Never use it. Run `up` for your own. |
| `SESSION_QUOTA` | you own 9 instances: `down` some. |
| `NO_FREE_INSTANCE` | every id on this machine is taken: `down --all` yours, wait, retry. |
| `AMBIGUOUS_INSTANCE` | you own more than one: add `--id N` from `list`. |
| `ENGINE_ABSENT` | run `npm ci --omit=dev` in `~/.local/share/pinebox/fork/pine-ide/pine-station`, then retry. |
| `JUDGE_DOWN` / `JUDGE_TIMEOUT` / `JUDGE_BUSY` | the judge on `:8090` is not answering. Start it, or wait and retry. There is no other judge. Until then `verify --arith` still runs (it answers `UNJUDGED`, never `WORKS`). |
| `JUDGE_FAILED` | the chart is wrong. Read the clause named, open a fresh `shot`, fix the script or the market, run `verify` again. |
| `WEEK_MISMATCH` (`... only 13 of them move`) | you are on a 15m or 30m cell: `tf --set 1H` (or 4H) and run `verify` again. Or the week has no data: `week --set 2026-W28`. |
| `NO_SCRIPT_LOADED` | `load --pine FILE` first; `verify` judges the script you loaded. |
| `PINE_ABSENT` | the file path is wrong. |
| `PINE_COMPILE_FAILED` | the Pine source has an error; the message gives the line. Fix it, `load` again. |
| `NO_DRAWINGS` / `NO_BARS` | the script drew nothing / no bars loaded: check the market with `asset --get`, then `load` again. |
| `ASSET_ABSENT` / `TF_SET_FAILED` | only `DXY EURUSD GBPUSD` and `15m 30m 1H 4H` exist. |
| `RESIZE_UNSUPPORTED` | the window cannot be resized; it is 1626x931. |
| `TAB_NOT_FOUND` | `--to` is `pine` or `backtest`. |
| `BACKTEST_TAB_INACTIVE` | run `tab --to backtest` first. |
| `DATE_OUT_OF_RANGE` | pick a date inside the session window shown in the message. |
| `WIDGET_NOT_FOUND` | run `widget --action list` and use a listed name. |
| `COORD_OUT_OF_SCREEN` / `BAD_ARGS` on `drive` | re-shoot and read the coordinates off the new PNG; `click` needs `--x --y`, `type` needs `--text`, `key` needs `--key`. |
| `SCOPE_VIOLATION` | an `--out` path with `..` or outside the instance: use an absolute `/tmp/...png` with `shot`, a bare name with `look`. |
| `BAD_ARGS` (any verb) | a flag the verb does not take, or a missing/empty value. The message names the flags the verb takes. |
| `CMD_NOT_FOUND` | the program for `spawn --cmd` is not installed. |
| `VIEW_UNCONFIRMED` | `view` needs `--confirm`, and only when the human operator asked to see it. |
| `NO_HOST_DISPLAY` | no graphical login: `up --adapter xvfb` (or `weston-vnc`). |
| `APP_NOT_READY` | the machine is starved or the page failed to render: `down --all`, wait, `up` again. |
| `RAIL_DOWN` / `STATION_DOWN` / `PORTS_MISMATCH` | an internal service stopped: `down --all`, `up` again. |
| `FOCUS_STOLEN` | the human operator's focus moved while you drove: stop, tell them, do not continue. |
| `STATUS_ROW_MISMATCH` | the IDE's status line disagrees with the market you asked for: run `asset --get`, set the market again. |
| `ORCA_UNAVAILABLE` | no Orca CLI on this machine: bring the instance up without `--surface` (the local default). |
| `ORCA_TAB_FAILED` / `ORCA_CDP_ABSENT` | Orca did not give a tab or its CDP port: check Orca is running (`orca-ide status --json`), then `up` again; nothing is left behind. |
| `TZ_NOT_HELD` | the Orca tab did not come up in UTC: `down`, then `up` again. |
| `CHART_NOT_SETTLED` / `NO_FRESH_FRAME` | the chart was still moving: wait 2 seconds and run the command again. |

Anything else: Appendix B lists every token the tool can print, with its own message.

---

## 7. RECOVERY

**How you know it failed:** exit code 1 and `REFUSED TOKEN` on stderr; or a JSON answer with `"ok":false`. `"ok":true` is not enough: read the frame (A-4).

**Abort a run:** `pinebox down --session S --all`. It is safe to run twice. If `list` still shows an instance, run `computer shell down --session S --orphans`, then `pinebox list --session S` again. The `computer` commands you may need here (full manual: the computer-use-v2 repository): `computer doctor` (the machine check, last line `VERDICT   DRIVEABLE`), `computer shell list --session S` (your displays), `computer shell down --session S --all|--id N|--orphans`.

**Roll back an install:** every `DEPLOY.sh --install` first writes `~/.cache/computer-use/rollback/<package>-<time>.tgz`. To go back: `tar xzf <that file> -C /`, then `computer doctor`.

**Resume after your shell or agent died:** the instance keeps running under its session name. From a shell use the same `--session NAME`; `pinebox list --session NAME` shows it. A NEW omp session has a new id and can not touch it (`SESSION_FOREIGN`): shut it down from a shell with the old name, or wait - an abandoned claim is swept after 90 seconds and its id returns to the pool.

**Install or upgrade (on a machine with the package folders):**
1. `cd Ship_Packages/computer-use-v2 && ./DEPLOY.sh --install` (first; pinebox refuses `REQUIRES_COMPUTER_USE` without it).
2. `cd Ship_Packages/pinebox && ./DEPLOY.sh --install` - it needs network the first time to fetch the Chromium build and run `npm ci`.
3. Both finish with `DEPLOY_VERIFY: IDENTICAL`. Check with `./DEPLOY.sh` (read-only) any time.

---

## 8. THE SECOND RUN

- `up` after `down` starts a clean instance. `up` while one exists is `INSTANCE_LIVE`.
- On a live instance change things in place: `load` replaces the script, `asset`/`tf`/`week` change the market, `tab` flips the tab. You do not need to restart.
- Instance ids come back to the pool after `down`; do not assume you get the same id or the same ports - read them from `list`.
- Frames from earlier runs stay in `/run/user/1000/pinebox/iN/` until the next `up` on that id; `shot --out` into `/tmp` with a new name each time so you never read an old frame.

---

## 9. THE LIMITS (read before you hit one)

- **Data is a bundled fixture.** 3 assets x 4 timeframes for the week 2026-W28; other fixture weeks exist for `up --week` (2026-04-20 has EURUSD 1H only). There is no live data and no network at run time.
- **`verify` judges only 1H and 4H.** On 15m and 30m the data ends at 2026-07-06 06:00, so `verify` refuses `WEEK_MISMATCH`. You can still look at those cells and drive them.
- **No resize.** The page is 1626x931 (`chart --op resize` is refused).
- **Backtest orders fill at the last visible close**, at once. E1 zones exist for DXY and EUR/USD in the fixture week, not GBP/USD (the room says so by name).
- **A session id is yours alone.** You cannot see, drive or stop another session's instance; there is no shared instance. Up to 9 instances per session; ids 0..9 are shared by every session on the machine.
- **You may not touch the human operator's screen.** `view --confirm` raises a window and may only be used on their request; nothing else ever changes their focus.
- **The judge is required for `WORKS`.** Without it `verify` refuses `JUDGE_DOWN` and `verify --arith` answers `UNJUDGED`.
- **An instance uses about 700 MB.** Down it when you finish.
- **Orca surface:** the tab must stay open - if someone closes it in Orca, the instance's verbs fail by name (the page is gone): `down` and `up` again. One Orca tab per instance; several instances (any mix of local and orca) may run in one session with `--id`.
- **Not exercised:** the Backtest journal panel, closing or modifying a position, the chart's drawing tools, `view --confirm` on a real display, a machine other than the one it was built on.

---

## 10. THE TRAPS (what a stranger gets wrong)

1. **Trusting `"ok":true`.** Open the frame. A blank frame has `colours` near 1. Frame byte counts and colour counts differ from this manual's samples every run; only the shape matters.
2. **Calling `verify --arith` a pass.** It answers `UNJUDGED`; only `verify` answers `WORKS`.
3. **Verifying on 15m or 30m.** It refuses `WEEK_MISMATCH` - switch to 1H/4H, do not "fix" the week.
4. **Forgetting `--session`** (shell) or reusing a name from an old run without checking `list`.
5. **Clicking with stale coordinates.** Always re-shoot first; coordinates are the PNG's pixels. The CREATE SESSION button moves down as sessions accumulate: a missed click creates nothing and prints `ok:true`. Check the `uid`.
6. **Reading an old PNG.** Use a new `--out` name each time.
7. **Forgetting `down`.** Instances hold memory and ids.
8. **Using `view --confirm` to look at your own work.** It raises a window on someone's screen.
9. **Skipping the install order.** computer-use first, then pinebox.
10. **Expecting a running omp session to pick up a new install.** Start a new one.

---

## 11. VERIFICATION - how you prove the job is done

You are done when ALL of these hold:
1. `pinebox verify --session S` printed `{"verdict":"WORKS",...}` (1H or 4H cell).
2. You opened the last frame and named what it shows: the chart title (symbol, timeframe), the status row (`FIXTURE · DXY · 1H · 508 bars`), the price range, the script's lines/markers.
3. For a Backtest job: `backtest --op state` shows the session `uid` (new, if you created one) and the `cursor` you stepped to, and the frame's title shows the ticker and timeframe you meant.
4. `pinebox down --session S --all` returned `{"ok":true,"down":"all",...}` and `pinebox list --session S` shows `"instances":[]`.

---

## 12. THE DRILL

**Method.** The manual was written by walking the tool cold, command by command (verbatim outputs in sections 3-5), then tested by FRESH OPERATORS: separate zero-context agents given ONLY this manual, each doing the whole job on the real tool and also hitting failure branches on purpose. Their questions were the holes; each was fixed in the manual and the drill was run again with new agents until a pass produced zero questions.

| Pass | Job | Result | Questions | What the questions found |
|---|---|---|---|---|
| 1 | up, 3 asset/timeframe switches, verify, Backtest step, create GBP/USD 30m, 4 failure branches, teardown | completed | 5 | how to read click coordinates off a PNG without a measuring tool; whether typing replaces the field; what `computer shell list` shows; where the bar count is read from; no wait between CREATE and `state` |
| 2 | the same plus TWO created sessions, row switching, 4 failure branches | completed | 5 | scaled image viewers (original vs displayed pixels); what the NEW SESSION form shows after creating; no row coordinates; the shortened `session` echo; a missed row click |
| 3 | 4 switches, verify, play/pause/step, THREE created sessions, row switching, a BUY order, 5 failure branches | completed | **0** | - |

**Fixed because of the drill:** the form scrolls (fixed coordinates hold for 6 creations with a tab round-trip, then must be re-read - measured: creations 1-6 succeeded, 7-10 missed); a created session is proved by a NEW `uid`, not by `ok:true`; image-viewer scaling; rows and ticket coordinates; the form is not the current market; the bar count comes from the status row or `asset --get`; `computer` commands for teardown; the `session` echo is shortened for display; `cursor` is zero-based.

**Instrument 2 (action count).** Actions the drill needed that were missing from the first enumeration: wait 3 seconds after CREATE, the tab round-trip before each creation, the row-click procedure, the order procedure, `computer shell list` after teardown - all added as steps. Actions enumerated and never needed: none.

**Instrument 3 (builder-leak scan).** The sections 1-12 contain no mechanism, architecture or rationale language (scan run; one "by design" in the computer manual was removed).

**Residual.** The drill ran on the machine the tool was built on, with agents that could read images. A machine without an image reader cannot complete the "open the frame" steps (the manual says so). The Backtest journal panel, closing or modifying a position and the drawing tools were not drilled (section 9).

---


## START HERE - THE THREE START VERBS (no other input)

To open Pinebox, call exactly ONE verb. Nothing else is needed: the agent tool supplies the session, the tool picks
the place, waits until Pinebox is loaded, and refuses by name if anything is wrong.

| the operator says | call | what happens |
|---|---|---|
| "open Pinebox on the Mac" | `spawn-cloud-mac` | a browser tab in the Orca window on the MAC, running natively there (title "Pinebox · Mac · S:N") |
| "open Pinebox on Linux" | `spawn-cloud-linux` | a browser tab in the Orca window on the LINUX machine, running natively there (title "Pinebox · Linux · S:N") |
| "open Pinebox locally" / "the local shell" | `spawn-local` | a local Pinebox window on this Linux machine |

Then every other verb acts on that Pinebox with no --id: `load --pine FILE`, `asset --symbol EURUSD`, `tf --tf 4H`,
`verify`, `tab --to backtest`, `backtest --op ...`, `shot --out F`. Finish with `down --all`.

Rules the tool enforces (each refused by name, exit 1):
- the start verbs take no place or mode argument: `spawn-cloud-mac --on linux` -> BAD_ARGS. The verb name IS the place.
- from a shell (not the agent tool) pass `--session NAME`, else NO_SESSION.
- a second Pinebox in the same session: add `--id N` (INSTANCE_LIVE names the free ids); then pass `--id N` to every verb.

Measured 2026-11-07 (Orca 1.4.252 on both machines): each start verb READY in 4-5 s; the agent tool called with only
`{"verb":"spawn-cloud-linux"}` opened the tab, `asset` and `tf` answered (511 / 128 bars), `down` closed it.

## CLOUD MODE (pinebox-cloud, blueprint DESIGN_BLUEPRINT_PINEBOX_CLOUD_v1.md)

The same CLI, a second shell. `pinebox up --session S --mode cloud` opens Pinebox as a BROWSER
TAB in the Orca window that hosts your terminal. The page (Pine IDE + Backtest room) is served by
the Cloudflare Worker `pinebox-cloud`; Pine scripts compile and run INSIDE the page (pinets 0.10.0
in a Web Worker); the backtest room, its sessions and the VIL ledger live in Durable Objects. No
display, no compositor, no local service: the Orca tab IS the instance. Every verb you send is
relayed by name to that page and answers the same JSON fields as local, plus "mode":"cloud".

Prerequisites (each refused by name when absent):
- an Orca terminal: ORCA_WORKTREE_ID + ORCA_CLI_BIN_DIR are exported there (ORCA_SESSION_ABSENT
  elsewhere - export them into your shell if a wrapper dropped them);
- ~/.config/pinebox/cf.env (mode 600) with PINEBOX_AGENT_TOKEN, the worker's agent bearer (AUTH_REQUIRED
  without it; the same file holds CLOUDFLARE_API_TOKEN, which only a worker deploy uses).

WHERE THE TAB OPENS - `--on mac` (default) or `--on linux`. Open it on the machine you are looking at:
- `--on mac`: `orca open-url` puts the page in the browser of the paired desktop (the Mac). It runs there natively
  (60 fps). The Linux Orca window lists it, but only as a label ("Showing on another device") - nothing renders there.
- `--on linux`: `orca tab create` puts the page in this machine's Orca window. It runs there natively. The Mac
  window lists it too, but as a streamed picture - measured laggy when dragging the chart. Use it from the Linux box.
- The tab title says which: "Pinebox · Mac · S:N" or "Pinebox · Linux · S:N". `pinebox list` shows `"on"`.
- Each instance is its own Pinebox (its own chart, script, backtest pane). Two instances, one per machine, are NOT
  mirrored: a verb changes only the instance it names (--session S --id N).
- Needs Orca 1.4.252 or later on BOTH machines (with older builds a Mac tab stayed hidden at 1x1, F-283).
- One-line rule for an agent: "open Pinebox on the Mac" -> `pinebox up --session S --mode cloud`;
  "open Pinebox on Linux" -> `pinebox up --session S --mode cloud --on linux`. No other step.

The procedure (measured 2026-11-07; each line is a real run):
```
pinebox up --session S --mode cloud
  page      Orca tab <browserPageId> · viewport 1569px · socket OPEN · IDE mounted
  READY     instance 1  mode cloud  url https://pinebox-cloud.cryptoforex36963.workers.dev/i/S:1?k=S
pinebox load --session S --pine FILE.pine   # the CLI reads FILE and relays the text; {bars,onChart,counts}
pinebox asset --session S --symbol EURUSD   # {symbol,timeframe,bars,market} read back from the chart
pinebox asset --session S --get             # read-only: the chart's market now (tf --get, week --get likewise)
pinebox tf --session S --tf 4H              # 15m|30m|1H|4H on the VISIBLE tab: Pine IDE chart, or the backtest room's view (surface:backtest)
pinebox chart --session S --op zoom --dir IN    # pan --dx N | zoom --dir IN|OUT | fit | view
pinebox widget --session S --action close --name editor   # editor|face|verdict|focus; list
pinebox shot --session S --out /tmp/c.png   # the page renderer's chart PNG, written to --out (default <instance>/frame.png), sha-checked: {path,bytes,sha256,market}
pinebox verify --session S                  # page arithmetic + the chart frame judged on :8090 -> WORKS
pinebox verify --session S --arith          # arithmetic only -> UNJUDGED (never WORKS)
pinebox tab --session S --to backtest       # pine | backtest; answers {active, ready}
pinebox backtest --session S --op session   # the session the BACKTEST pane holds (creates one if none)
pinebox backtest --session S --op create --name UNIQUE --symbol DXY --start 2025-06-02 --end 2025-07-01 [--balance 10000] [--strategy BS] [--description TEXT]   # a NEW session on the full store, the pane switched to it
pinebox backtest --session S --op step --n 5            # N one-bar steps; {moved, cursor}
pinebox backtest --session S --op place --side buy --type market --qty 10000
pinebox backtest --session S --op play --rate 5         # rate: 0.5 1 2 5 10 25
pinebox backtest --session S --op pause
pinebox backtest --session S --op close --pct 100
pinebox backtest --session S --op list                  # every durable session
pinebox backtest --session S --op state                 # .result.status: cursor, balance, equity, realized,
                                                        #   positions[] (the OPEN POSITION panel), recentFills[]
                                                        #   + closedTrades[] (the JOURNAL rows), stats
pinebox down --session S --all              # destroys the instance object AND closes the Orca tab
```
The instance boots on its state: DXY · 1H · week 2026-W28 (the fixture week), exactly like local.
Backtest sessions are durable: after `down` + `up` (a NEW tab) the pane restores the session at its
cursor with its balance and journal. They are removed only by `backtest --op delete --uid`.

How to SEE it: the tab is in your Orca window's tab strip, titled "Plutus Vision — Pine IDE +
Backtest", focused by `up`. With several Pinebox tabs open, `pinebox view --session S [--id N]
--confirm` brings THIS instance's tab to the front (--confirm = the operator asked to see it;
VIEW_UNCONFIRMED without it); its URL ends /i/S:N. `shot` returns the chart's own pixels; `verify` judges them. To look at
the whole Orca window from a script on this host, `PINEBOX/tools/screen-look.py OUT.png` takes one
read-only frame of EVERY active monitor (OUT-<connector>.png each - the Orca window can be on any of
them; GNOME Mutter ScreenCast; no input is sent). `screen-look.py OUT.png HDMI-3` takes that monitor
only; a connector that is not active is refused MONITOR_ABSENT with the active list.
`pinebox list --session S` shows a cloud instance as {id, mode:"cloud", url, page, tab:"open"|"closed",
alive}; `pinebox status --session S` shows its url, page and last refusals.

Refusals you will meet (all exit 1, token first):
- INSTANCE_LIVE - `up` on an instance whose tab is still open (use it, or `down` first)
- ORCA_TAB_CREATE_FAILED / ORCA_WRONG_WORKTREE / ORCA_TAB_NOT_SHOWN - Orca refused the tab
- ORCA_PAGE_NOT_SHOWN - the tab did not reach {viewport, socket OPEN, IDE mounted} in 40 s
- ASSET_ABSENT, FIXTURE_TF_ABSENT, WIDGET_NOT_FOUND, BAD_ARGS, LOAD_NEEDS_TEXT, NO_DRAWINGS,
  BACKTEST_TAB_INACTIVE (backtest ops need `tab --to backtest` first), BAD_DELTA,
  REPLAY_STEP_FAILED, JUDGE_FAILED, CLAUSE_NOT_FOUND, TEARDOWN_FAILED
- CLOUD_ONLY_FLAG - --rate on a LOCAL instance (the local play rate is --op speed --speed X);
  every other backtest op and flag is the same on both shells (A-9)
- the room's own refusals (cloud backtest ops): BAD_ORDER (place needs --side buy|sell and
  --type market|limit|stop; limit/stop need --price; --qty > 0), BAD_PCT (close --pct 1..100),
  BAD_RATE (play --rate not in 0.5 1 2 5 10 25), NO_SESSION (no session in the pane: --op session
  first), SESSION_NOT_FOUND (--uid unknown), BAD_OP (an op the room does not have),
  UNSUPPORTED "hedging is not allowed: a live <side> order (O3) is in the book" (one direction at a
  time: clear the working order with `backtest --op cancel --order O3`, or close the position with
  `--op close --pct 100`, then place)
- CODE_ROLLOVER (right after a worker redeploy: an object still ran the previous code; it restarts itself onto
  the new code - retry in a second) and PAGE_STALE (the tab ran an older page build; it reloads itself - retry
  in a few seconds)
- a dropped page socket (a worker redeploy, a network blip) shows `PAGE_ABSENT ... reconnecting
  (attempt n)` in the tab and re-opens by itself; INSTANCE_DESTROYED in the tab means `down` took
  the instance away (final - `up` opens a new tab)
- STALE_REAP_FAILED - `up` found a stale record on its id and could not bring it down (the
  message carries the teardown's own refusal)

A SECOND instance beside the cloud one (local or cloud): `up`/`spawn` without --id re-use your
session's instance and refuse INSTANCE_LIVE - that refusal lists the free pinebox ids right now
("free pinebox ids now: 2 3 4 ..."); pick one: `pinebox up --session S --id 4` (local) or
`pinebox up --session S --mode cloud --id 4`. From then on pass --id N to every verb (a verb
without --id refuses AMBIGUOUS_INSTANCE). An id another session holds refuses SESSION_FOREIGN.

Pictures: every frame is a PNG; open it in an image viewer (or the agent's image reader) and name
what it shows. `shot` = the chart only; `screen-look.py` = the whole monitor with the Orca window.

Traps: `terminal`/`attach` on a cloud instance refuse NO_DISPLAY (they need a Linux display); `look`
answers LOOK_USE_SHOT (a page cannot capture its own window - use `shot`); the CLI sends the agent
bearer pinebox-cloud-agent-v1 (a deploy-time constant) - the Cloudflare token is only for deploys.

## APPENDIX A - EVERY VERB (generated from the action table and the last verb sweep)

Flags may come in any order; `--session S` is accepted by every action except `probe`, `doctor` and `state battery`.

| verb | syntax | flags | a real run (command -> output) | a real refusal |
|---|---|---|---|---|
| `ports` | `pinebox ports --session S` | `--id` | `pinebox ports --session S --id N` -> `{"ok":true,"id":2,"ports":{"station":9941,"rail":9954,"server":10051,"cdp":9422,"ws":10131,"vnc":5902,"room":9643},"state":{"station":"held by pid 726043","rail":"held by pid 726265","server":"held by pid 726462","cdp":"held by pi ...` | `pinebox ports --session S --id 42` -> `REFUSED BAD_ID — pinebox instance id must be a canonical decimal 0..9, got '42'` |
| `up` | `pinebox up --session S` | `--id --week --pair --tf --pine --adapter --mode --on` | `pinebox up --session S --pine FILE.pine` -> `load ema-ribbon.pine DXY 1H -> {"bars":508,"onChart":6,"counts":{"plots":2,"plotPoints":800,"markers":4,"boxes":0,"labels":0,"lines":0,"tables":0,"polylines":0,"linefills":0,"trades":0}} status FIXTURE · DXY · 1H · 508 bars READY ...` | `pinebox up --session S --pine /tmp/no-such-file.pine` -> `page chrome in a window on :3 · CDP :9422 · profile /run/user/1000/pinebox/i2/chrome frame /run/user/1000/pinebox/i2/frame.png (144104 bytes, 283 colours, CDP capture) we ...` |
| `spawn` | `pinebox spawn --session S` | `--id --cmd --week --pair --tf --pine --adapter` | `rm -f /tmp/sweep-pb-spawn.png; pinebox spawn --session sweep-pbspawn --cmd "zenity --info --title SWEEP-PB-SPAWN --text spawned" && i=$(pinebox list --session sweep-pbspawn / jq -r ".instances[0].id")` -> `{"ok":true,"id":3,"recorded":{"symbol":"DXY","timeframe":"1H"},"page":{"bars":508,"market":{"symbol":"fixture:DXY","provider":"fixture","timeframe":"60","bars":5000,"offline":false}}} {"ok":true,"path":"/run/user/1000/computer-use ...` | `pinebox spawn --session sweep-pbspawn --id 0 --cmd "zenity --info --text x"` -> `REFUSED SESSION_FOREIGN — instance 0 (pinebox) belongs to another session (operator...); this session is sweep-pb... - instances are per session: run 'shell up' / 'pinebo ...` |
| `attach` | `pinebox attach --session S` | `--id` | `pinebox attach --session S --id N` -> `{"ok":true,"attached":true,"id":2,"slot":"3","adapter":"weston-x11","ports":{"station":9941,"rail":9954,"server":10051,"cdp":9422,"ws":10131,"vnc":5902,"room":9643},"services":{"station":9941,"rail":9954,"server":10051},"week":{"r ...` | `pinebox attach --session S --id 0` -> `REFUSED SESSION_FOREIGN — instance 0 (pinebox) belongs to another session (operator...); this session is sweep-pb... - instances are per session: run 'shell up' / 'pinebo ...` |
| `down` | `pinebox down --session S` | `--id --all` | `pinebox down --session S --all` -> `{"ok":true,"down":"all","instances":1}` | `pinebox down --session S --id 0` -> `REFUSED SESSION_FOREIGN — instance 0 (pinebox) belongs to another session (operator...); this session is sweep-pb... - instances are per session: run 'shell up' / 'pinebo ...` |
| `list` | `pinebox list --session S` | `-` | `pinebox list --session S` -> `{"ok":true,"instances":[{"id":2,"slot":"3","adapter":"weston-x11","ports":{"station":9941,"rail":9954,"server":10051,"cdp":9422,"ws":10131,"vnc":5902,"room":9643},"window":"4194307","colours":282,"pids":{"station":726034,"rail":72 ...` | `pinebox list --session S --bogus 1` -> `REFUSED BAD_ARGS — '--bogus' is not an argument of 'list' (it takes: --)` |
| `status` | `pinebox status --session S` | `--id --project` | `pinebox status --session S` -> `{"ok":true,"id":2,"ports":{"station":9941,"rail":9954,"server":10051,"cdp":9422,"ws":10131,"vnc":5902,"room":9643},"week":"2026-W28","pair":"DXY","tf":"1H","pids":{"station":726034,"rail":726265,"server":726462,"room":727625},"slo ...` | `pinebox status --session S --project abc` -> `REFUSED BAD_ARGS — --project is the number of instances to project the memory to (1..9), got 'abc'` |
| `shot` | `pinebox shot --session S` | `--id --out --section` | `pinebox shot --session S --section chart --out /tmp/sweep-pb-shot.png` -> `{"ok":true,"path":"/tmp/sweep-pb-shot.png","bytes":67049,"colours":391,"via":"cdp","section":"chart","c3":"held"}` | `pinebox shot --session S --out /tmp/sweep-not-a-png.txt` -> `REFUSED BAD_ARGS — --out must end in .png, got '/tmp/sweep-not-a-png.txt'` |
| `load` | `pinebox load --session S` | `--id --pine --pair --tf` | `pinebox load --session S --pine FILE.pine` -> `frame /run/user/1000/pinebox/i2/frame.png (151045 bytes, 281 colours, CDP capture) load ema-ribbon.pine DXY 1H -> {"bars":508,"onChart":6,"counts":{"plots":2,"plotPoints":800,"markers":4,"boxes":0,"labels":0,"lines":0,"tables":0," ...` | `pinebox load --session S --pine BROKEN.pine` -> `REFUSED PINE_COMPILE_FAILED — Failed to transpile Pine Script version 5: Unexpected token EOF '' at 5:1 (source /tmp/sweep-broken.pine, DXY 1H)` |
| `drive` | `pinebox drive --session S` | `--id --action --x --y --text --key --out` | `pinebox drive --session S --action key --key End` -> `{"ok":true,"verb":"key","key":"End","via":"cdp","c3":"held"}` | `pinebox drive --session S --action click` -> `REFUSED BAD_ARGS — drive click needs --x (a missing coordinate is not defaulted to 0: that clicks the page corner)` |
| `terminal` | `pinebox terminal --session S` | `--id --send --read --lines` | `pinebox terminal --session S --send "echo SWEEP-PB-TERM" && until_out SWEEP-PB-TERM pinebox terminal --session S --read --lines 20` -> `{"ok":true,"session":"cu-2-0"} {"ok":true,"session":"cu-2-0","text":"echo SWEEP-PB-TERM"}` | `pinebox terminal --session S --send ""` -> `REFUSED BAD_ARGS — terminal needs --send TEXT or --read` |
| `state` | `pinebox state --session S` | `--id --get --put --value` | `pinebox state --session S --put sweepk --value ok-88 && pinebox state --session S --get sweepk` -> `{"ok":true,"key":"sweepk","db":"/run/user/1000/computer-use/i2/fs/state.db"} {"ok":true,"key":"sweepk","value":"ok-88","db":"/run/user/1000/computer-use/i2/fs/state.db"}` | `pinebox state --session S --put` -> `REFUSED BAD_ARGS — flag --put needs a value` |
| `view` | `pinebox view --session S` | `--id --confirm` | `CU_HOST_DISPLAY=$VDISP pinebox view --session sweep-pbview --confirm && [ "$($HW $VDISP active)" = "$PHWIN" ] && root_still $VDISP /tmp/sweep-pb-view-root.png` -> `{"ok":true,"raised":"0x800005","display":":5","active":"0x800005"}` | `CU_HOST_DISPLAY=$VDISP pinebox view --session sweep-pbview` -> `REFUSED VIEW_UNCONFIRMED — view raises a window on the operator's screen. Pass --confirm only when the operator asked to see this instance.` |
| `week` | `pinebox week --session S` | `--id --set --get` | `pinebox week --session S --set 2026-W28` -> `week 2026-W28 (the IDE control now reads 2026-W28) {"ok":true,"id":2,"week":"2026-W28"}` | `pinebox week --session S --set 2026-W99` -> `REFUSED BAD_ARGS — week 2026-W99 does not exist (ISO weeks run 01..52, or 53 in a long year)` |
| `verify` | `pinebox verify --session S` | `--id --week --clause --arith --phase` | `pinebox verify --session S` -> `{"verdict":"WORKS","verify":{"ok":true,"id":2,"week":"2026-W28","verdict":"ARITH_OK","checks":[{"check":"rail","ok":true,"evidence":":9954 answers"},{"check":"station","ok":true,"evidence":":9941 compiles"},{"check":"ports","ok":t ...` | `pinebox verify --session S --clause C9.9` -> `REFUSED CLAUSE_NOT_FOUND — clause 'C9.9' has no id in /home/leviathan/.local/share/pinebox/judge/clauses.txt (ids: C0.1, C1.1, C1.2, C1.3, C2.1) - a clause without an id ...` |
| `insert` | `pinebox insert --session S` | `--id --pine --pair --tf` | `pinebox insert --session S --pine FILE.pine` -> `{"ok":true,"id":2,"verb":"insert","chars":613}` | `pinebox insert --session S --pine /tmp/no-such-file.pine` -> `REFUSED PINE_ABSENT — no such pine source: /tmp/no-such-file.pine` |
| `run` | `pinebox run --session S` | `--id --pine --pair --tf` | `pinebox run --session S --pine FILE.pine` -> `frame /run/user/1000/pinebox/i2/frame.png (150962 bytes, 281 colours, CDP capture) load ema-ribbon.pine DXY 1H -> {"bars":508,"onChart":6,"counts":{"plots":2,"plotPoints":800,"markers":4,"boxes":0,"labels":0,"lines":0,"tables":0," ...` | `pinebox run --session S --pine BROKEN.pine` -> `REFUSED PINE_COMPILE_FAILED — Failed to transpile Pine Script version 5: Unexpected token EOF '' at 5:1 (source /tmp/sweep-broken.pine, DXY 1H)` |
| `editor` | `pinebox editor --session S` | `--id --mode --text` | `pinebox editor --session S --mode get` -> `{"ok":true,"verb":"editor","source":"//@version=5\n// THE PINE SHELL - a study smoke case (the station's own catalog script).\n// A source whose geometry lies INSIDE the bar fixture's window, so the loaded chart is\n// verifiably ...` | `pinebox editor --session S --mode bogus` -> `REFUSED BAD_ARGS — editor needs --mode get/set (got 'bogus')` |
| `look` | `pinebox look --session S` | `--id --out --section` | `pinebox look --session S --out sweep-look.png` -> `{"ok":true,"id":2,"verb":"look","frame":{"path":"/run/user/1000/pinebox/i2/sweep-look.png","bytes":150865,"colours":282,"via":"cdp"},"sha":"52024648f0572f8e"}` | `pinebox look --session S --out ../escape.png` -> `REFUSED SCOPE_VIOLATION — look --out must be a bare file name ending .png (it is written inside the instance dir), got '../escape.png'` |
| `tab` | `pinebox tab --session S` | `--id --to` | `pinebox tab --session S --to backtest && pinebox shot --session S --out /tmp/sweep-pb-bt.png && pinebox tab --session S --to pine` -> `{"ok":true,"id":2,"verb":"tab","active":"backtest","ready":{"ready":true,"room":true,"speed":true,"timeline":true}} {"ok":true,"path":"/tmp/sweep-pb-bt.png","bytes":197810,"colours":195,"via":"cdp","c3":"held"} {"ok":true,"id":2," ...` | `pinebox tab --session S --to nowhere` -> `REFUSED TAB_NOT_FOUND — tab needs --to pine/backtest (got 'nowhere')` |
| `chart` | `pinebox chart --session S` | `--id --op --dx --dy --dir --size` | `pinebox chart --session S --op fit` -> `{"ok":true,"id":2,"verb":"chart","op":"fit","before":{"range":{"from":1782086400000,"to":1784440800000},"width":934,"height":742},"after":{"range":{"from":1782086400000,"to":1784440800000},"width":934,"height":742,"allBarsInView": ...` | `pinebox chart --session S --op resize --size 800x600` -> `REFUSED RESIZE_UNSUPPORTED — the renderer's resize() takes no size: it is 'resize() { this.syncSize(); }' (workbench.bundle.js:36404-36405), the chart always fills its co ...` |
| `asset` | `pinebox asset --session S` | `--id --symbol --tf --set --get` | `pinebox asset --session S --get` -> `{"ok":true,"id":2,"recorded":{"symbol":"DXY","timeframe":"1H"},"page":{"bars":508,"market":{"symbol":"fixture:DXY","provider":"fixture","timeframe":"60","bars":5000,"offline":false}}}` | `pinebox asset --session S --set XYZ` -> `REFUSED ASSET_ABSENT — unsupported instrument 'XYZ' (DXY, EURUSD, GBPUSD)` |
| `tf` | `pinebox tf --session S` | `--id --tf --symbol --set --get` | `pinebox tf --session S --get` -> `{"ok":true,"id":2,"recorded":{"symbol":"DXY","timeframe":"1H"},"page":{"bars":508,"market":{"symbol":"fixture:DXY","provider":"fixture","timeframe":"60","bars":5000,"offline":false}}}` | `pinebox tf --session S --set 7m` -> `REFUSED TF_SET_FAILED — unsupported timeframe '7m' (15m, 30m, 1H, 4H)` |
| `widget` | `pinebox widget --session S` | `--id --action --name` | `pinebox widget --session S --action list` -> `{"ok":true,"id":2,"verb":"widget","widgets":[{"name":"editor","pressed":true},{"name":"face","pressed":true},{"name":"verdict","pressed":false},{"name":"focus","pressed":false}],"panes":[{"id":"pine-shell-root","open":true},{"id": ...` | `pinebox widget --session S --action open --name no-such-widget` -> `REFUSED WIDGET_NOT_FOUND — no widget named 'no-such-widget' (the toggles are: editor, face, verdict, focus)` |
| `backtest` | `pinebox backtest --session S` | `--id --op --speed --date --n --side --type --qty --sl --tp --price --pct --rate --uid --order --text --tags --name --symbol --tf --balance --start --end --description --strategy` | `pinebox tab --session S --to backtest >/dev/null && pinebox backtest --session S --op state; pinebox tab --session S --to pine >/dev/null` -> `{"ok":true,"id":2,"verb":"backtest","op":"state","state":{"uid":"bt-mw5wfq2p-g6g3yr","cursor":10,"playing":false,"rate":1,"atStart":false,"atEnd":false,"startIndex":0,"now":"2026-06-22T10:00:00.000Z","nowMs":1782122400000,"startDa ...` | `pinebox backtest --session S --op bogus` -> `REFUSED BAD_ARGS — unknown backtest op 'bogus' (session/state/play/pause/step/speed/date/stop/list/create/open/place/modify/close/cancel/note/export/delete)` |
| `phase` | `pinebox phase --session S` | `--id --close` | `pinebox verify --session S --phase chart-up >/dev/null && pinebox phase --session S --close chart-up` -> `{"ok": true, "phase": "chart-up", "closed": true, "tickets": {"C0.1": "fee81e67ef03ea1be6b7d2560107863be18dfffa42274fe2b8f3fad5512cfecb", "C1.2": "5c2b7de139460e3c1c4b06c76a8c59348315aeead6eb7ae43de3bf17b1fdab7d"}, "artifact": "63 ...` | `pinebox phase --session S --close no-such-phase` -> `REFUSED PHASE_NOT_FOUND — no phase 'no-such-phase' in the ticket table (have: chart-up, ema-ribbon, week-jul)` |
| `spawn-local` | `pinebox spawn-local --session S` | `--id --week --pair --tf --pine` | (not a standalone sweep row; see the procedure) | - |
| `spawn-cloud-linux` | `pinebox spawn-cloud-linux --session S` | `--id --week --pair --tf --pine` | (not a standalone sweep row; see the procedure) | - |
| `spawn-cloud-mac` | `pinebox spawn-cloud-mac --session S` | `--id --week --pair --tf --pine` | (not a standalone sweep row; see the procedure) | - |
| `data` | `pinebox data --session S` | `--op` | (not a standalone sweep row; see the procedure) | - |

## APPENDIX B - EVERY REFUSAL TOKEN (the message is the tool's own words)

A refusal is `REFUSED  TOKEN  -  message` on stderr, exit 1. `<..>` stands for a value the tool fills in.

| token | the tool says | raised in |
|---|---|---|
| `ACTIVATE_FORBIDDEN` | raising a window steals the operator's focus. Use focus (a record write), screenshot/click/type/key (never raise), or view - the one verb permitted to raise. | `cu-v2/core/drive.sh` |
| `ADAPTER_UNAVAILABLE` | <..>: $(jq -r '.reason // | `cu-v2/core/surface.sh` |
| `AGENTOS_UNAVAILABLE` | the agentOS runtime (a WASM Linux on a Worker) is blueprint section 16B, Phase Two, and is not built in this version. Run on a Linux host, or on a non-Linux host with QEMU and CU_GUEST_IMAGE. | `cu-v2/core/guest/boot.sh` |
| `AMBIGUOUS_INSTANCE` | this session owns <..>.length} <..> instances (<..>.map((r) => r.id).join(", ")}) - pass --id to choose one | `cu-v2/core/registry-cli.ts` |
| `APP_EXITED` | <..>[0]} exited before mapping a window — $(tail -2 | `cu-v2/core/drive.sh` |
| `APP_NOT_READY` | pine.html is open on CDP :<..> but the IDE did not render within <..>s (no .pine-week control and chart renderer) - the host is starved or the page failed; nothing was driven | `pinebox-cli/stages/page.sh` |
| `APP_NO_WINDOW` | <..>[0]} ran but mapped no window on :<..> — <..> | `cu-v2/core/drive.sh` |
| `ASSET_ABSENT` | unsupported instrument '<..>' (DXY, EURUSD, GBPUSD) | `pinebox-cli/stages/v3_nav.sh` |
| `ASSET_SET_FAILED` | the page loaded <..> bars but its market is '<..>', not <..>: the instrument selector did not take the value | `pinebox-cli/stages/v3_nav.sh` |
| `BACKTEST_ROOM_DOWN` | the Backtest pane holds no room base (its control service is not connected) | `pinebox-cli/stages/v3_backtest.sh` |
| `BACKTEST_TAB_INACTIVE` | the Backtest tab is not active (switch with: pinebox tab --to backtest) | `pinebox-cli/stages/v3_backtest.sh` |
| `BAD_ADAPTER` | instance <..> records adapter '<..>', which is not in the adapters list (tampered record?) | `cu-v2/core/cli.sh` |
| `BAD_ADAPTER_LIST` | cannot read <..> | `cu-v2/core/probe.sh` |
| `BAD_ARGS` | --project is the number of instances to project the memory to (1..9), got '<..>' | `pinebox-cli/pinebox` |
| `BAD_CONFIG` | PB_CHROME_FLAGS must be space-separated --flag[=value] words, got '<..>' | `pinebox-cli/stages/page.sh` |
| `BAD_DISPLAY` | existing: '<..>' is not a local display (expected :N or :N.S) - a remote or malformed display is never bound | `cu-v2/core/adapters/existing.sh` |
| `BAD_ID` | pinebox instance id must be a canonical decimal 0..9, got '${1:-}' | `pinebox-cli/pinebox` |
| `BAD_KEY` | record key '<..>[i]}' | `cu-v2/core/lib.sh` |
| `BAD_ORDER` | place needs --side buy/sell | `pinebox-cli/stages/v3_backtest.sh` |
| `BAD_PCT` | close % must be 0 < pct <= 100 (got \ | `pinebox-cli/stages/v3_backtest.sh` |
| `BAD_PRICE` | <..> needs a trigger price (--price) | `pinebox-cli/stages/v3_backtest.sh` |
| `BAD_RECORD` | instance <..> records cdp '<..>', which is not a port | `cu-v2/core/drive.sh` |
| `BAD_SESSION` | a session id is 4..80 characters of [A-Za-z0-9._-], got '<..>(s).slice(0, 40)}' | `cu-v2/core/registry-cli.ts` |
| `BAD_VALUE` | record value for '<..>[i]}' has a newline | `cu-v2/core/lib.sh` |
| `BAD_VERB` | unknown verb '<..>' - run: pinebox help | `pinebox-cli/pinebox` |
| `BROWSER_UNAVAILABLE` | Pinebox's pinned browser is not installed at <..> (Chromium build $(cat | `pinebox-cli/stages/page.sh` |
| `C3_UNOBSERVABLE` | <..>: the host display exists but its focus could not be read, so 'the operator's focus did not move' cannot be proven | `cu-v2/core/govern.sh` |
| `CANVAS_ABSENT` | the chart canvas is not on the page (no renderer mounted): nothing to pan, zoom, fit or read | `pinebox-cli/stages/v3_nav.sh` |
| `CAPTURE_FAILED` | $(tail -1 | `pinebox-cli/stages/v3.sh` |
| `CDP_NOT_OWNED` | --cdp <..> is not the browser port recorded for instance <..> (<..>); spawn the browser with --cdp <..> first, or use --cdp 0 for the X path | `cu-v2/core/drive.sh` |
| `CDP_UNREADABLE` | could not read the week from the page over CDP :<..> - <..> | `pinebox-cli/stages/verify.sh` |
| `CHART_EMPTY_RANGE` | the renderer holds <..> bars but no MOVING bar is in view ($(jq -r '.flat // 0' <<< | `pinebox-cli/stages/verify.sh` |
| `CHART_NOT_DRAWN` | the renderer says <..> of <..> bars are in view (colours: <..>) but only <..> of <..> of them are on screen at their columns in those colours (rate <..>, floor <..>): the chart did not draw what it ho | `pinebox-cli/stages/verify.sh` |
| `CHART_NOT_READY` | the page has no renderer to ask yet: $(jq -r '.why' <<< | `pinebox-cli/stages/verify.sh` |
| `CHART_NOT_SETTLED` | the chart moved between two probes 0.4s apart (range/bars/colours differ): $(jq -c '[.vr,.inView]' <<< | `pinebox-cli/stages/verify.sh` |
| `CHART_PROBE_UNKNOWN` | the renderer probe answered state '<..>' - not a state this verifier knows | `pinebox-cli/stages/verify.sh` |
| `CHART_SETTLE_FAILED` | the chart never settled before the capture - <..> | `pinebox-cli/pinebox` |
| `CLAIM_LOCK_FAILED` | cannot create the instance root <..> | `pinebox-cli/ports.sh` |
| `CLAIM_REENTRANT` | pb_claim is not re-entrant: fd 6 is already open in this shell | `pinebox-cli/ports.sh` |
| `CLOUD_ONLY_FLAG` | --rate is the cloud room's play rate; the local room's rate is --op speed --speed X | `pinebox-cli/stages/v3_backtest.sh` |
| `CMD_NOT_FOUND` | exec: '<..>': executable file not found in PATH - nothing was claimed or started | `pinebox-cli/pinebox` |
| `COMPOSITOR_FATAL` | weston exited — $(tail -3 | `cu-v2/core/adapters/weston-vnc.sh` |
| `COMPOSITOR_NO_OUTPUT` | no \ | `cu-v2/core/adapters/weston-vnc.sh` |
| `CONFIG_BLOCK_ABSENT` | $(sed -E 's/^REFUSED +CONFIG_BLOCK_ABSENT +— +//' | `pinebox-cli/stages/services.sh` |
| `COORD_OUT_OF_SCREEN` | click <..>,<..> is outside the <..>x<..> screen of instance <..> | `cu-v2/core/drive.sh` |
| `CORE_REPLY_UNREADABLE` | the core's spawn reply was not JSON: $(printf '%s' | `pinebox-cli/stages/page.sh` |
| `DATE_OUT_OF_RANGE` | <..> is outside the session's window ($(jq -r '.lo[0:10]' <<< | `pinebox-cli/stages/v3_backtest.sh` |
| `DATE_SET_FAILED` | date must be YYYY-MM-DD, got '<..>' | `pinebox-cli/stages/v3_backtest.sh` |
| `DEPLOY_DRIFT` | $(printf '%s' | `cu-v2/deploy.sh` |
| `DISPLAY_DEAD` | existing: '<..>' does not answer xdpyinfo | `cu-v2/core/adapters/existing.sh` |
| `DISPLAY_IN_USE` | existing: display :<..> is already bound to instance <..> - bring that one down first (one instance per existing display) | `cu-v2/core/adapters/existing.sh` |
| `EDITOR_ABSENT` | the Pine editor is not mounted on this page | `pinebox-cli/stages/v3.sh` |
| `ENGINE_ABSENT` | run npm install in <..>/pine-ide/pine-station | `pinebox-cli/stages/services.sh` |
| `EVAL_FAILED` | $(tail -1 | `pinebox-cli/stages/v3.sh` |
| `FIT_INCOMPLETE` | fit left part of the $(jq -r '.total' <<< | `pinebox-cli/stages/v3_nav.sh` |
| `FIXTURE_ABSENT` | no bars fixture for week '<..>': <..> | `pinebox-cli/stages/services.sh` |
| `FOCUS_STOLEN` | <..>: <..> (a window of this tool took the operator's focus or the top of the stack) | `cu-v2/core/govern.sh` |
| `FRAME_ABSENT` | the run recorded no frame on disk (path '<..>') | `pinebox-cli/stages/v3.sh` |
| `FRAME_BLANK` | the captured frame has <..> colour(s) - a blank frame is not a frame | `pinebox-cli/stages/page.sh` |
| `FRAME_TRANSPORT_FAILED` | the page's chart frame did not arrive whole (sha mismatch or empty) - retry shot | `pinebox-cli/pinebox` |
| `FRAME_UNREADABLE` | the screenshot reply was not JSON: $(printf '%s' | `pinebox-cli/stages/page.sh` |
| `FRESHNESS_CHECK_FAILED` | the pixel-freshness instrument itself failed (exit <..>): $(tail -1 | `pinebox-cli/stages/verify.sh` |
| `GUEST_BOOT_FAILED` | qemu did not start: $(tail -3 | `cu-v2/core/guest/boot.sh` |
| `GUEST_HOSTKEY_ABSENT` | no recorded host key at <..> - the guest cannot be authenticated (record it: ssh-keyscan -t ed25519 the booted image) | `cu-v2/core/guest/boot.sh` |
| `GUEST_IMAGE_ABSENT` | CU_GUEST_IMAGE is not set. The guest is a qcow2 built from <..>/rootfs/manifest.txt (weston, Xwayland, Xvfb, chromium, node, tmux, sshd and this tool); build it, then export CU_GUEST_IMAGE=<path> | `cu-v2/core/guest/boot.sh` |
| `GUEST_IMAGE_INCOMPLETE` | the guest is missing binaries: $(head -3 | `cu-v2/core/guest/boot.sh` |
| `GUEST_SYNC_FAILED` | could not stream the tool into the guest at /opt/computer-use | `cu-v2/core/guest/boot.sh` |
| `HELPERS_UNAVAILABLE` | $(sed -E 's/^REFUSED +[A-Z_]+ +— +//' | `cu-v2/core/adapters/weston-x11.sh` |
| `HELPER_STALE` | helpers/build.sh failed | `cu-v2/deploy.sh` |
| `HELPER_SYMBOL_ABSENT` | <..> is not in nofocus.so | `cu-v2/deploy.sh` |
| `HOST_WINDOW_RESIZABLE` | host window <..> is not pinned to <..>x<..> (WM_NORMAL_HINTS: <..>) - the operator's window manager could resize the instance | `cu-v2/core/adapters/weston-x11.sh` |
| `INPUT_FAILED` | could not give window <..> keyboard focus on :<..> | `cu-v2/core/drive.sh` |
| `INSTANCE_BUSY` | an 'up' for instance <..> still holds the lock after 120s - not tearing down under it | `pinebox-cli/pinebox` |
| `INSTANCE_LIVE` | an 'up' for pinebox instance <..> is already in progress | `pinebox-cli/pinebox` |
| `JUDGE_FAILED` | the independent judge failed this frame on $(jq -r '[.failed[] as <..> / .results[<..>] / | `pinebox-cli/pinebox` |
| `LOCK_REENTRANT` | drv_spawn is not re-entrant: fd 9 is already open in this shell | `cu-v2/core/drive.sh` |
| `MCP_NOT_REGISTERED` | could not create <..> | `cu-v2/deploy.sh` |
| `MCP_NO_ANSWER` | <..> (<..> <..>) did not answer tools/list | `cu-v2/deploy.sh` |
| `MISSING_ID` | forwarded actions must carry --id | `cu-v2/core/guest/boot.sh` |
| `NAV_NO_EFFECT` | <..> left the chart state unchanged | `pinebox-cli/stages/v3_nav.sh` |
| `NEED_CMD` | app install needs the command after '--' | `cu-v2/core/cli.sh` |
| `NOT_CLAIMED` | instance <..> is not claimed by any session - run \ | `cu-v2/core/registry-cli.ts` |
| `NOT_UP` | pinebox instance <..> is not up - nobody has claimed it; run: pinebox up --id <..> | `pinebox-cli/pinebox` |
| `NO_APP` | no --name given and no default app registered for instance <..> | `cu-v2/core/cli.sh` |
| `NO_BARS` | pv-load returned success-shaped output with zero bars | `pinebox-cli/stages/load.sh` |
| `NO_DISPLAY` | instance $(flag id) is a cloud instance (a browser tab) - '<..>' needs a Linux display: use a local instance | `pinebox-cli/pinebox` |
| `NO_DRAWINGS` | pv-load returned zero chart objects | `pinebox-cli/stages/load.sh` |
| `NO_FREE_INSTANCE` | all <..> - lo + 1} <..> instance ids (<..>..<..>) are in use by sessions on this host - another session must shell down first | `cu-v2/core/registry-cli.ts` |
| `NO_FRESH_FRAME` | the chart pixels are unchanged since the last frame AND the renderer's bars are not on screen in them (rate <..>, floor <..>): this capture is stale, not a second look | `pinebox-cli/stages/verify.sh` |
| `NO_HOST_DISPLAY` | weston-x11 draws a window on the host display and none is set - use --adapter weston-vnc or xvfb | `cu-v2/core/adapters/weston-x11.sh` |
| `NO_HOST_WINDOW` | adapter existing has no window on a host display - use screenshot | `cu-v2/core/adapters/existing.sh` |
| `NO_IMAGE_CHECK` | could not count the colours of <..> (convert said '<..>') - the blank-frame check cannot run | `cu-v2/core/drive.sh` |
| `NO_INSTANCE` | this session (<..>(session)}...) has no <..> ?? ""} instance - run \ | `cu-v2/core/registry-cli.ts` |
| `NO_PAGE` | CDP :<..> has no pine.html target for :<..>; targets: <..> | `pinebox-cli/stages/page.sh` |
| `NO_RENDER_NODE` | CU_RENDERER=gl but no render node outside CU_RENDER_NODE='<..>' matches  ($(render_nodes / tr ' ' ';')) | `cu-v2/core/adapters/weston-x11.sh` |
| `NO_RUNTIME` | this host is $(uname -s), not Linux, and has neither QEMU nor agentOS - install QEMU (a Linux guest self-hosts the computer) or run on a Linux host | `cu-v2/core/runtime.sh` |
| `NO_SCRIPT_LOADED` | nothing was loaded into instance <..> (the page holds <..> bars and shows the IDE's own buffer) - load your indicator first: pinebox load --pine FILE (or up --pine FILE) | `pinebox-cli/stages/verify.sh` |
| `NO_SESSION` | the Backtest room has no session - the pane reads NO SESSION (create one with: pinebox backtest --op session) | `pinebox-cli/stages/v3_backtest.sh` |
| `NO_SLOT` | could not take the display-slot lock | `cu-v2/core/adapters/xvfb.sh` |
| `NO_SURFACE` | existing: no display to bind (set CU_EXISTING_DISPLAY or DISPLAY) | `cu-v2/core/adapters/existing.sh` |
| `NO_WINDOW_BOUND` | instance <..> has no window bound yet - spawn an app, then: computer focus --id <..> --title <regex> | `cu-v2/core/drive.sh` |
| `NO_XWAYLAND` | weston never reported an xserver — <..> | `cu-v2/core/adapters/weston-vnc.sh` |
| `OPERATOR_DISPLAY` | input into display :<..> is forbidden - :0/:1/:2 belong to the operator. Create an instance (computer shell up) and drive that. | `cu-v2/core/drive.sh` |
| `ORCA_SESSION_ABSENT` | instance $1 is a cloud instance (Orca tab <..>) - its liveness is the tab: run from the Orca terminal (ORCA_WORKTREE_ID + ORCA_CLI_BIN_DIR) | `pinebox-cli/pinebox` |
| `ORCA_TAB_NOT_SHOWN` | tab switch --focus answered: $(printf '%s' | `pinebox-cli/pinebox` |
| `PB_ROOT_UNAVAILABLE` | neither PINEBOX_ROOT nor XDG_RUNTIME_DIR is set - set PINEBOX_ROOT to a directory only you can write (there is no /tmp default: it is a predictable path in a shared directory) | `pinebox-cli/pinebox` |
| `PINE_ABSENT` | --pine '<..>' is not a file | `pinebox-cli/pinebox` |
| `PINE_LOAD_FAILED` | pv-load returned non-JSON output, so no successful load can be recorded: $(printf '%s' | `pinebox-cli/stages/load.sh` |
| `PINE_LOAD_TIMEOUT` | pv-load did not finish within 170s (source <..>, <..> <..>) | `pinebox-cli/stages/load.sh` |
| `PINE_UNREADABLE` | could not encode <..> | `pinebox-cli/stages/v3.sh` |
| `PORTS_MISMATCH` | the page served on :<..> does not name its own apiBase - it would read another instance's data | `pinebox-cli/stages/verify.sh` |
| `PORT_PROBE_FAILED` | cannot determine whether <..> port <..> is free (ss missing or errored) - refusing rather than assuming free | `pinebox-cli/ports.sh` |
| `PORT_TAKEN` | vnc port <..> is held by pid $(port_owner | `cu-v2/core/adapters/weston-vnc.sh` |
| `PORT_UNKNOWN` | cannot tell whether vnc port <..> is free (ss missing or failing) - refusing to bind blind | `cu-v2/core/adapters/weston-vnc.sh` |
| `PRICE_BAND_MISMATCH` | the price axis spans $(jq -c '.scale' <<< | `pinebox-cli/stages/verify.sh` |
| `PROBE_FAILED` | computer probe did not select runtime=native with a surface | `cu-v2/deploy.sh` |
| `RAIL_DOWN` | the rail (the rooms/face) does not answer on :<..> - the IDE's face is offline | `pinebox-cli/stages/verify.sh` |
| `RECORD_WRITE_FAILED` | could not update <..>/state.json with: <..> | `pinebox-cli/pinebox` |
| `REGISTRY_FAILED` | cannot create a temp file | `cu-v2/core/session.sh` |
| `RENDERER_ABSENT` | no pine.html under renderer root '<..>' | `pinebox-cli/stages/services.sh` |
| `RENDER_UNAVAILABLE` | gl on <..> (<..>) needs the <..> EGL vendor file, and /usr/share/glvnd/egl_vendor.d has none | `cu-v2/core/adapters/weston-x11.sh` |
| `REPLAY_ABSENT` | the Backtest room is not mounted on this page (window.PlutusBacktestRoom / #page-backtest-room) | `pinebox-cli/stages/v3_backtest.sh` |
| `REPLAY_PAUSE_FAILED` | the room is still playing after pause | `pinebox-cli/stages/v3_backtest.sh` |
| `REPLAY_PLAY_FAILED` | the room did not enter the playing state (atEnd=$(jq -r '.state.atEnd' <<< | `pinebox-cli/stages/v3_backtest.sh` |
| `REPLAY_STEP_FAILED` | step <..> of <..> refused (moved <..>) | `pinebox-cli/pinebox` |
| `REPLAY_STOP_FAILED` | the room is still playing after stop | `pinebox-cli/stages/v3_backtest.sh` |
| `RESIZE_FAILED` | resize needs --size WxH (digits only) | `pinebox-cli/stages/v3_nav.sh` |
| `ROOM_DOWN` | the room never answered /health as the room on :<..> - <..>/room.log: $(tail -3 | `pinebox-cli/stages/room.sh` |
| `ROOM_STATE_FAILED` | the room answered but the pane could not refresh: $(jq -r '.refreshErr' <<< | `pinebox-cli/stages/v3_backtest.sh` |
| `ROOM_UNAVAILABLE` | the Backtest room source is missing: <..> - reinstall Pinebox (deploy.sh push) | `pinebox-cli/stages/room.sh` |
| `SCOPE_VIOLATION` | <..> is a symlink - refusing to use it as the instance root | `pinebox-cli/pinebox` |
| `SEAL_INCOMPLETE` | the pinebox CLI is at <..> but its extension is absent at <..> | `cu-v2/deploy.sh` |
| `SECTION_NEEDS_CDP` | --section <..> reads the page's own layout over CDP, and instance <..> has no browser port - capture the whole window without --section | `cu-v2/core/drive.sh` |
| `SERVICE_NOT_LEADER` | <..> pid <..> is not its own process-group leader (pgid '<..>') - a group teardown would not reach it | `pinebox-cli/pinebox` |
| `SERVICE_NOT_STARTED` | <..>: no valid pid ('<..>') | `pinebox-cli/pinebox` |
| `SESSION_CREATE_FAILED` | the room has no CREATE SESSION button | `pinebox-cli/stages/v3_backtest.sh` |
| `SESSION_FOREIGN` | instance <..>.id} (<..>.kind}) belongs to another session (<..>(row.session)}...); this session is <..>(me)}... - | `cu-v2/core/registry-cli.ts` |
| `SESSION_NAME_TAKEN` | a session named '$(jq -r '.nameTaken' <<< | `pinebox-cli/stages/v3_backtest.sh` |
| `SESSION_QUOTA` | session <..>(session)}... already owns <..>.length} instance(s) (CU_MAX_PER_SESSION=<..>) - shell down one first | `cu-v2/core/registry-cli.ts` |
| `SESSION_SWITCH_AMBIGUOUS` | $(jq -r '.switchAmbiguous' <<< | `pinebox-cli/stages/v3_backtest.sh` |
| `SESSION_SWITCH_UNAVAILABLE` | $(jq -r '.switchErr' <<< | `pinebox-cli/stages/v3_backtest.sh` |
| `SHELL_DOWN_FAILED` | the core could not stop instance <..>'s display/browser - <..> | `pinebox-cli/pinebox` |
| `SHIM_NOT_EFFECTIVE` | host window <..> has _NET_WM_USER_TIME '<..>', expected 0 | `cu-v2/core/adapters/weston-x11.sh` |
| `SHIM_NOT_LOADED` | the compositor mapped its window without nofocus.so (no '[nofocus] map' line) — <..> | `cu-v2/core/adapters/weston-x11.sh` |
| `SHIM_UNAVAILABLE` | <..>/nofocus.so was not built | `cu-v2/core/adapters/weston-x11.sh` |
| `SLOT_FORBIDDEN` | :<..> is in the operator's range (:0/:1/:2) | `cu-v2/core/adapters/weston-vnc.sh` |
| `SPEED_SET_FAILED` | speed must be one of 0.5 1 2 5 10 25 (bars per second, the room's own select), got '<..>' | `pinebox-cli/stages/v3_backtest.sh` |
| `STALE_REAP_FAILED` | the stale cloud record for instance <..> did not come down: <..> | `pinebox-cli/pinebox` |
| `STATE_FAILED` | cannot create a temp file | `cu-v2/core/state.sh` |
| `STATION_DOWN` | the station on :<..> does not answer success:true on POST /run | `pinebox-cli/stages/verify.sh` |
| `STATION_WILL_NOT_COMPILE` | POST /run on :<..> never answered success:true - <..>/station.log: $(tail -2 | `pinebox-cli/stages/services.sh` |
| `STATUS_ROW_ABSENT` | the page shows no FIXTURE status row - it did not report loading this fixture | `pinebox-cli/stages/load.sh` |
| `STATUS_ROW_MISMATCH` | the page's status row '<..>' has no field equal to pair '<..>' | `pinebox-cli/stages/load.sh` |
| `STATUS_ROW_UNREADABLE` | could not read the page's status row over CDP: $(tail -1 | `pinebox-cli/stages/load.sh` |
| `SURFACE_BAD_DISPLAY` | adapter <..> returned '<..>', which is not a display number | `cu-v2/core/surface.sh` |
| `SURFACE_NO_DISPLAY` | adapter <..> produced no display | `cu-v2/core/surface.sh` |
| `TAB_NOT_FOUND` | tab needs --to pine/backtest (got '<..>') | `pinebox-cli/stages/v3_nav.sh` |
| `TAB_NOT_READY` | tab <..> is active but its content did not finish mounting within 20 s: <..> | `pinebox-cli/stages/v3_nav.sh` |
| `TAB_SWITCH_FAILED` | tab <..> did not become active (the active pane is '<..>') | `pinebox-cli/stages/v3_nav.sh` |
| `TEARDOWN_FAILED` | cloud instance <..> did not come down: <..> | `pinebox-cli/pinebox` |
| `TEARDOWN_INCOMPLETE` | the rail that never answered on :<..> could not be stopped | `pinebox-cli/stages/services.sh` |
| `TERMINAL_FAILED` | could not create tmux session $(term_sess | `cu-v2/core/terminal.sh` |
| `TF_SET_FAILED` | unsupported timeframe '<..>' (15m, 30m, 1H, 4H) | `pinebox-cli/stages/v3_nav.sh` |
| `TLS_CERT_FAILED` | openssl could not generate a certificate in <..> | `cu-v2/core/adapters/weston-vnc.sh` |
| `TOOL_ABSENT` | no core/ under <..> | `cu-v2/deploy.sh` |
| `VERIFY_WEEK_ABSENT` | the page answered no ISO week ('<..>') - week --set it first | `pinebox-cli/pinebox` |
| `VIEW_FAILED` | could not raise <..> on <..> | `cu-v2/core/adapters/weston-x11.sh` |
| `VIEW_NOT_RAISED` | asked the window manager on <..> to activate <..>; after 2 s the active window is <..> | `cu-v2/core/adapters/weston-x11.sh` |
| `VIEW_UNCONFIRMED` | view brings this instance's Orca tab to the front of the operator's window. Pass --confirm only when the operator asked to see this instance. | `pinebox-cli/pinebox` |
| `VNC_NEEDS_NO_DISPLAY` | a display (<..>) is answerable, so weston-vnc would render no window for the operator - use weston-x11; vnc exists for a host with no display (contract C6) | `cu-v2/core/adapters/weston-vnc.sh` |
| `VNC_NOT_LISTENING` | nothing listens on :<..> | `cu-v2/core/adapters/weston-vnc.sh` |
| `WEEK_MISMATCH` | the IDE is set to '<..>' but the loaded bars are week <..> (fixture <..>) - an indicator read here would be read on the wrong week | `pinebox-cli/stages/verify.sh` |
| `WEEK_NOT_IN_VIEW` | the requested week <..> has no moving bar in view (visible range $(jq -c '.vr' | `pinebox-cli/stages/verify.sh` |
| `WEEK_SET_FAILED` | the page has no .pine-week value to read (is the IDE rendered?) | `pinebox-cli/pinebox` |
| `WIDGET_NOT_FOUND` | the page has no .pine-lay-btn toggles (is the Pine IDE tab mounted?) | `pinebox-cli/stages/v3_nav.sh` |
| `WIDGET_STATE_UNCHANGED` | widget '<..>' did not become <..> (aria-pressed still $(jq -r '.after' <<< | `pinebox-cli/stages/v3_nav.sh` |
| `WINDOW_GONE` | host window <..> on <..> is gone or unmapped - the instance is not showing; run: computer shell up | `cu-v2/core/adapters/weston-x11.sh` |
| `WINDOW_LOWER_FAILED` | lower <..> | `cu-v2/core/adapters/weston-x11.sh` |
| `WINDOW_NOT_BELOW` | host window <..> still tops the operator's stack after <..> corrections | `cu-v2/core/adapters/weston-x11.sh` |
| `WINDOW_NOT_MAPPED` | the browser opened no window on :$(pb_rec_get | `pinebox-cli/stages/page.sh` |
| `WINDOW_RELEASE_FAILED` | release <..> | `cu-v2/core/adapters/weston-x11.sh` |
| `WINDOW_STACK_UNREADABLE` | cannot read the stacking order of <..> | `cu-v2/core/adapters/weston-x11.sh` |
| `WINDOW_STATE_UNREADABLE` | cannot read _NET_WM_STATE of <..> on <..> | `cu-v2/core/adapters/weston-x11.sh` |
| `WRONG_ECOSYSTEM` | instance <..> is a '<..>' instance, not a pinebox - drive it with \`computer\`, not \`pinebox\` | `pinebox-cli/pinebox` |
| `ZOOM_NO_EFFECT` | zoom <..> left the visible range unchanged (already at the zoom limit?) | `pinebox-cli/stages/v3_nav.sh` |

## APPENDIX C - THE omp TOOL PARAMETERS

Inside an omp session the tool takes these parameters (the same names as the flags, `_` for `-`).

| parameter | type | meaning |
|---|---|---|
| `id` | string | the pinebox instance id 0..9. OPTIONAL: omit it and the verb acts on YOUR session's only pinebox; `up` with no id allocates one for your session. An id owned by another session is refused (SESSION_FOREIGN). |
| `week` | string | the bar fixture week, e.g. 2026-07-06 (fixtures/bars/<week>.json must exist) |
| `pair` | string | the instrument, e.g. DXY |
| `tf` | string | the timeframe, e.g. 1H |
| `pine` | string | a Pine source file to load and run (stage 5) |
| `adapter` | string | force a surface adapter (weston-x11 / weston-vnc / xvfb / existing) |
| `out` | string | a file path for the frame |
| `action` | string | widget: list, open or close |
| `x` | number | drive click: page CSS pixels |
| `y` | number | drive click: page CSS pixels |
| `text` | string | drive type: the text |
| `key` | string | drive key: a CDP chord such as Enter or ctrl+a |
| `send` | string | terminal: text to send to the instance's tmux |
| `read` | boolean | terminal: read the pane |
| `get` | boolean | week / tf / asset: read the current value from the page instead of setting it |
| `put` | string | state: the key to write |
| `value` | string | state put: the value |
| `project` | number | status: project the measured memory to this many instances |
| `all` | boolean | down: every instance |
| `confirm` | boolean | view: REQUIRED - set only when the operator asked to see the instance; view raises a window on their screen |
| `set` | string | week: the ISO week label to set in the IDE, e.g. 2026-W28 |
| `mode` | string | up: local (default, the weston shell) or cloud (the browser runtime on Cloudflare Workers) |
| `to` | string | tab: pine or backtest |
| `op` | string | data: fetch-latest (top up every stored series to now). backtest: session/create/state/... as before. |
| `dx` | number | chart pan: horizontal fraction |
| `dy` | number | chart pan: vertical fraction |
| `dir` | string | chart zoom: IN or OUT |
| `size` | string | chart resize: WxH |
| `symbol` | string | asset: DXY, EURUSD or GBPUSD |
| `name` | string | widget: its name |
| `speed` | number | backtest speed: the room's bars-per-second select: 0.5, 1, 2, 5, 10 or 25 |
| `date` | string | backtest date: YYYY-MM-DD inside the session's window (the room's jump-to field + GO) |
| `n` | number | backtest: number of replay steps |
| `section` | string | shot/look: capture only a SECTION of the page, located from the page's own layout - chart (the chart workspace: symbol bar, tools, plot, axes) or plot (the plotting area only) |
| `cmd` | string | spawn: the program (and its arguments) to start INSIDE the new instance, e.g. "zenity --info --text hi"; checked before anything is claimed (CMD_NOT_FOUND) |
| `clause` | string | verify: the judge clause ids to require, comma-separated (judge/clauses.txt); default: judge/bindings.json for the loaded script and week |
| `arith` | boolean | verify: run ONLY the arithmetic checks (services, ports, week, bars, drawings, frame, pixels at the renderer's bar columns); the answer is UNJUDGED, never WORKS - nothing in it looked at what the chart shows |
| `phase` | string | verify: judge exactly the clauses this phase of judge/phases.json requires (P3g) |
| `close` | string | phase: the phase to close; refuses PHASE_TICKETS_MISSING unless the last judged frame has a passing signed ticket for each required clause |
| `lines` | number | terminal --read: how many lines of the instance's terminal to return (1..5000, default 50) |
| `side` | string | backtest place: buy / sell |
| `type` | string | backtest place: market / limit / stop |
| `qty` | number | backtest place/modify: units |
| `sl` | number | backtest place/modify: stop-loss price |
| `tp` | number | backtest place/modify: take-profit price |
| `price` | number | backtest place: limit/stop trigger price |
| `pct` | number | backtest close: percent of the position, 1..100 |
| `rate` | number | backtest play (cloud): bars per second, one of 0.5 1 2 5 10 25 |
| `uid` | string | backtest open/delete/export: a session uid from --op list |
| `order` | string | backtest modify/cancel: the order or position id the room shows |
| `tags` | string | backtest note: comma-separated tags |
| `balance` | number | backtest create: the starting balance (default 10000, the pane's field default) |
| `on` | string | up --mode cloud: where the page runs natively - mac (default; the paired desktop hosting this terminal, via orca open-url) or linux (this machine's Orca window, via orca tab create). Open it on the machine you are looking at. |
| `start` | string | backtest create: the replay window's START date, YYYY-MM-DD[THH:MM] UTC (the replay begins on the first bar at/after it; earlier bars stay visible as history) |
| `end` | string | backtest create: the replay window's END date, YYYY-MM-DD[THH:MM] UTC (the session holds bars up to it) |
| `description` | string | backtest create: what this session is for (optional) |
| `strategy` | string | backtest create: the strategy / playbook this session tests (optional) |

## APPENDIX D - WHERE THINGS ARE

- The installed tool: `~/.local/share/pinebox/` (`pinebox` is linked into `~/.local/bin`); the omp extension: `~/.omp/agent/extensions/pinebox/`; the display layer: `~/.omp/agent/extensions/computer-use-v2/`.
- One running instance's files: `/run/user/1000/pinebox/iN/` - `frame.png` (the last capture), `server.log`, `rail.log`, `room.log`, `load.err`, `refusals.jsonl` (every refusal with its time), the browser profile `chrome/`, the Backtest room's own database `room.db`.
- The pinned browser: `~/.local/share/pinebox/runtime/chrome/chrome-linux/chrome` (the build id is in `~/.local/share/pinebox/BROWSER_VERSION`).
- The fixture bars: `~/.local/share/pinebox/fork/fixtures/bars/` (default `2026-07-06.json`, 12 cells); the sample script: `~/.local/share/pinebox/test/fixtures/ema-ribbon.pine`.
- Rollback copies of earlier installs: `~/.cache/computer-use/rollback/`.
- When something is odd, read the newest lines of `server.log`, `rail.log` and `refusals.jsonl` in the instance folder, then look the token up in Appendix B.
