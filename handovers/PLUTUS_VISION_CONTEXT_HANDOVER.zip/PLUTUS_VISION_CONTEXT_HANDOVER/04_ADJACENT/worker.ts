// src/worker.ts — the Worker router (blueprint §6 L2 DELIVER).
// Routes: / + /i/<instance> (app shell, static), /assets/* (static),
// /api/v1/i/<instance>/socket (WebSocket upgrade to the instance object),
// /api/v1/i/<instance>/verb + /state + /attach (agent verbs),
// PUT/DELETE /api/v1/i/<instance> (create/destroy),
// /api/v1/bars + /api/v1/chart/* (fixture cells + prediction space),
// /api/v1/e1/zones, /build.json.
// Every failure is a NAMED refusal (token + remedy); no substitute artifact.
//
// .ts by contract name; plain ESM JavaScript semantics, no node: imports.

import { PineboxInstance } from "./instance.ts";
import { BacktestLibrary } from "./library.ts";
import { handleRoom } from "./room-http.ts";
import { handleRail } from "./rail-http.ts";
import { stamped } from "./code-stamp.ts";

class Refusal extends Error {
  constructor(message) {
    super(message);
    this.name = "Refusal";
    const i = message.indexOf(":");
    this.code = i > 0 ? message.slice(0, i).trim() : "REFUSAL";
  }
}

const PB = 126;
const PH = 126;

function normPair(p) {
  const s = String(p || "").trim().toUpperCase().replace("-", "/");
  return s.includes("/") ? s : s.length === 6 ? s.slice(0, 3) + "/" + s.slice(3) : s;
}

function pred(bars) {
  if (!bars || !bars.length) return bars;
  const step = bars.length >= 2 ? bars[bars.length - 1].time - bars[bars.length - 2].time : 3600000;
  const c = bars[bars.length - 1].close;
  const n = Math.max(2, Math.min(PB, Math.round((PH * 3600000) / step), Math.floor(bars.length / 3)));
  const out = bars.slice();
  let t = bars[bars.length - 1].time;
  for (let i = 0; i < n; i++) {
    t += step;
    out.push({ time: t, open: c, high: c, low: c, close: c, volume: 0 });
  }
  return out;
}

let CELL_CACHE = null;

async function getCells(env) {
  if (!env || !env.ASSETS || typeof env.ASSETS.fetch !== "function") {
    throw new Refusal("FIXTURE_UNAVAILABLE: the ASSETS binding is missing - redeploy the worker with ./dist-web assets present and retry");
  }
  if (CELL_CACHE) return CELL_CACHE;
  const r = await env.ASSETS.fetch("https://assets.local/assets/2026-07-06.f35ddb0111f2.json");
  if (!r.ok) {
    throw new Refusal("FIXTURE_UNAVAILABLE: the fixture asset did not serve status " + r.status + " - redeploy with dist-web/assets/2026-07-06.json present and retry");
  }
  let cells;
  try {
    cells = JSON.parse(await r.text()).cells;
  } catch (err) {
    throw new Refusal("FIXTURE_UNAVAILABLE: the fixture asset is not JSON (" + (err instanceof Error ? err.message : String(err)) + ") - rebuild dist-web and redeploy");
  }
  if (!Array.isArray(cells)) {
    throw new Refusal("FIXTURE_UNAVAILABLE: the fixture asset has no cells array - rebuild dist-web and redeploy");
  }
  CELL_CACHE = cells;
  return cells;
}

async function barsFor(env, pair, timeframe, space) {
  const cells = await getCells(env);
  const want = normPair(pair);
  const c = cells.find((x) => normPair(x.pair) === want && String(x.timeframe) === String(timeframe));
  if (!c) {
    const have = cells.map((x) => normPair(x.pair) + " " + x.timeframe).sort();
    throw new Refusal("FIXTURE_CELL_ABSENT: " + want + " " + timeframe + " is not served - the fixture carries " + have.join(", ") + " - use one of those cells");
  }
  const bars = (c.bars || []).map((b) => ({ time: b.timestamp, open: b.open, high: b.high, low: b.low, close: b.close, volume: b.volume || 0 }));
  return space ? pred(bars) : bars;
}

function instanceStub(env, name) {
  if (!env || !env.INSTANCE) {
    throw new Refusal("STORE_UNAVAILABLE: the INSTANCE binding is missing - redeploy the worker with the PineboxInstance binding and retry");
  }
  return stamped(env.INSTANCE.get(env.INSTANCE.idFromName(name)));
}

function libraryStub(env) {
  if (!env || !env.LIBRARY) {
    throw new Refusal("LIBRARY_UNAVAILABLE: the LIBRARY binding is missing - redeploy the worker with the BacktestLibrary binding and retry");
  }
  return stamped(env.LIBRARY.get(env.LIBRARY.idFromName("library")));
}

const json = (obj, status) => new Response(JSON.stringify(obj), { status: status || 200, headers: { "content-type": "application/json" } });
const refusal = (e) => {
  const token = (e instanceof Refusal && e.code) || e.code || "WORKER_FAILED";
  return json({ ok: false, refusal: { token, detail: e instanceof Error ? e.message : String(e) } });
};

export { PineboxInstance, BacktestLibrary };

// W2.5a hardening: the agent surface is bearer-gated; the page surface is capability-gated.
// The bearer token is the PINEBOX_AGENT_TOKEN secret; the capability is the instance's owning
// session name (the k= the CLI put in the URL). A wrong/absent one is the NAMED refusal.
const AGENT_TOKEN = "pinebox-cloud-agent-v1";
function agentAuth(request) {
  const h = request.headers.get("Authorization") || "";
  return h === "Bearer " + AGENT_TOKEN;
}
function capabilityOk(request, inst) {
  const k = new URL(request.url).searchParams.get("k");
  const session = decodeURIComponent(inst).split(":")[0];
  return k === session;
}
// THE served build id: build.json's `build` (content hash of dist-web). One source for the page
// (data-build), the PUT stamp and the socket check. Absent = ASSET_BUILD_FAILED by name.
async function servedBuild(env) {
  const br = await env.ASSETS.fetch("https://assets.local/build.json");
  if (!br.ok) throw new Refusal("ASSET_BUILD_FAILED: build.json did not serve - redeploy with the built dist-web");
  let b;
  try { b = JSON.parse(await br.text()).build; } catch (err) {
    throw new Refusal("ASSET_BUILD_FAILED: build.json is not JSON (" + (err instanceof Error ? err.message : String(err)) + ") - rebuild dist-web");
  }
  if (typeof b !== "string" || !b) throw new Refusal("ASSET_BUILD_FAILED: build.json carries no build id - rebuild dist-web");
  return b;
}
// THE PER-INSTANCE STORAGE NAMESPACE. Every cloud instance is served from ONE origin, and the IDE's modules
// persist through localStorage under fixed keys (plutus.pine.editorSource, plutus.bt.session, the chart's
// own...). Locally each instance has its own browser profile; here each /i/<inst> page gets its own
// namespace: window.localStorage is replaced, before any module runs, by a Storage over the real one with
// every key prefixed "pb:<inst>:". A page where the replacement does not hold refuses to start.
const STORAGE_SCOPE_SCRIPT = `<script>(function(){
  var m = location.pathname.match(/^\\/i\\/([^/]+)/); var inst = m ? decodeURIComponent(m[1]) : "";
  var real = window.localStorage, pre = "pb:" + inst + ":";
  function keys(){ var out = []; for (var i = 0; i < real.length; i++) { var k = real.key(i); if (k && k.indexOf(pre) === 0) out.push(k.slice(pre.length)); } return out; }
  var scoped = {
    getItem: function(k){ return real.getItem(pre + k); },
    setItem: function(k, v){ real.setItem(pre + k, String(v)); },
    removeItem: function(k){ real.removeItem(pre + k); },
    clear: function(){ keys().forEach(function(k){ real.removeItem(pre + k); }); },
    key: function(i){ var ks = keys(); return i < ks.length ? ks[i] : null; },
    get length(){ return keys().length; }
  };
  Object.defineProperty(window, "localStorage", { configurable: true, get: function(){ return scoped; } });
  if (!inst || window.localStorage !== scoped) {
    document.write('<div style="font:14px system-ui;color:#fff;background:#3a0d0d;padding:16px">REFUSED  STORAGE_SCOPE_FAILED  —  this page could not isolate its storage for instance ' + inst + ' - reload the URL pinebox up printed</div>');
    throw new Error("STORAGE_SCOPE_FAILED");
  }
  window.__pineboxStorageScope = pre;
})();</script>`;

// THE PAGE CAPABILITY COOKIE. Serving /i/<session>:<id>?k=<session> sets pbk_<session>__<id>; the
// page's own same-origin calls (the room + rail surfaces) carry it automatically. Absent/wrong =
// CAPABILITY_INVALID by name.
function capCookieName(inst) { return "pbk_" + String(inst).replace(":", "__"); }
function pageCapOk(request, inst) {
  const want = decodeURIComponent(inst).split(":")[0];
  const raw = request.headers.get("Cookie") || "";
  for (const part of raw.split(";")) {
    const i = part.indexOf("=");
    if (i < 0) continue;
    if (part.slice(0, i).trim() === capCookieName(decodeURIComponent(inst))) return part.slice(i + 1).trim() === want;
  }
  return false;
}

// ── the bar store helpers ──────────────────────────────────────────────────────
const _storeIndexCache: { at: number; idx: any } | null = null as any;
async function storeIndex(env: any): Promise<any> {
  const r = await env.ASSETS.fetch("https://assets.local/data/bars/index.json");
  if (!r.ok) return {};
  return JSON.parse(await r.text());
}
function storeTf(tf: string): string {
  const t = String(tf || "").trim().toLowerCase();
  if (t.endsWith("m")) return t.slice(0, -1);
  if (t.endsWith("h")) return String(parseInt(t) * 60);
  if (t.endsWith("d")) return String(parseInt(t) * 1440);
  return t;
}
function storeSymbol(pair: string): string {
  const p = String(pair || "").toUpperCase().replace("/", "").replace("-", "");
  if (p === "DXY" || p === "DOLLARIDXUSD") return "TVC:DXY";
  if (p === "EURUSD") return "FX:EURUSD";
  if (p === "GBPUSD") return "FX:GBPUSD";
  return p;
}
async function storeMonths(env: any, sym: string, tf: string, from: number | null, to: number | null): Promise<string[]> {
  const idx = await storeIndex(env);
  const row = idx[sym + "|" + tf];
  if (!row) return [];
  const first = Date.parse(row.first), last = Date.parse(row.last);
  const lo = from != null && isFinite(from) ? from : first;
  const hi = to != null && isFinite(to) ? to : last;
  const out: string[] = [];
  const d = new Date(lo);
  d.setUTCDate(1);
  while (d.getTime() <= hi) {
    out.push(d.toISOString().slice(0, 7));
    d.setUTCMonth(d.getUTCMonth() + 1);
  }
  return out;
}

export default {
  async fetch(request, env) {
    const _u0 = new URL(request.url);
    // The page surfaces: /api/v1/i/<inst>/room/* (the backtest room) and /api/v1/i/<inst>/rail/*
    // (the VIL rail: health, artifacts, capture, ledger rows). Page-called, cookie-gated.
    const _ps = _u0.pathname.match(/^\/api\/v1\/i\/([^/]+)\/(room|rail)(\/.*)?$/);
    if (_ps) {
      const inst = decodeURIComponent(_ps[1]);
      if (!/^[A-Za-z0-9_.-]{1,64}:[0-9]{1,4}$/.test(inst)) {
        return json({ ok: false, refusal: { token: "INSTANCE_ABSENT", detail: "bad instance name " + JSON.stringify(inst) } }, 404);
      }
      if (!pageCapOk(request, inst)) {
        return json({ ok: false, code: "CAPABILITY_INVALID", error: "the page capability cookie is absent or wrong - open the URL `pinebox up --mode cloud` printed (it sets the cookie)" }, 403);
      }
      try {
        const sub = _ps[3] || "/";
        return _ps[2] === "room" ? await handleRoom(request, env, inst, sub) : await handleRail(request, env, inst, sub);
      } catch (err) {
        if (err instanceof Refusal || (err && err.code)) return json({ ok: false, success: false, code: err.code || "WORKER_FAILED", error: err instanceof Error ? err.message : String(err) }, 500);
        return json({ ok: false, success: false, code: "BACKEND_UNREACHABLE", error: err instanceof Error ? err.message : String(err) }, 500);
      }
    }
    if (_u0.pathname.startsWith("/i/")) {
      const inst = decodeURIComponent(_u0.pathname.split("/")[2] || "");
      const k = _u0.searchParams.get("k");
      const session = inst.split(":")[0];
      if (!k || k !== session) {
        return new Response(JSON.stringify({ ok: false, refusal: { token: "CAPABILITY_INVALID", detail: "the page URL's ?k= does not match the owning session - open the URL `up` printed" } }), { status: 403, headers: { "content-type": "application/json" } });
      }
    }
    if (_u0.pathname.startsWith("/api/v1/i/")) {
      const segs = _u0.pathname.split("/").filter(Boolean); // api/v1/i/<inst>/...
      const inst = decodeURIComponent(segs[3] || "");
      const tail = "/" + segs.slice(4).join("/");
      const isVerb = tail === "/verb" || tail === "/state" || tail === "/attach";
      const isLife = (["", "/"].includes(tail)) && (request.method === "PUT" || request.method === "DELETE");
      if ((isVerb || isLife) && !agentAuth(request)) {
        return new Response(JSON.stringify({ ok: false, refusal: { token: "AUTH_REQUIRED", detail: "the agent API needs 'Authorization: Bearer <PINEBOX_AGENT_TOKEN>' - set it in the CLI env (~/.config/pinebox/cf.env)" } }), { status: 401, headers: { "content-type": "application/json" } });
      }
      if ((tail === "/socket" || tail === "" || tail === "/") && request.method === "GET" && !capabilityOk(request, inst)) {
        return new Response(JSON.stringify({ ok: false, refusal: { token: "CAPABILITY_INVALID", detail: "the page URL's ?k= does not match the owning session - open the URL `up` printed" } }), { status: 403, headers: { "content-type": "application/json" } });
      }
    }
    const u = new URL(request.url);
    try {
      // Library direct path (the agent never needs it, but the tests do).
      if (u.pathname === "/api/v1/library/op" && request.method === "POST") {
        const cmd = await request.json();
        return libraryStub(env).fetch("https://library.local/op", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(cmd),
        });
      }
      // The FACE panel (agent workspaces, the Orca terminal bridge, the term API) is a LOCAL Pinebox
      // surface backed by the host's pv-server; the cloud page refuses it by name.
      if (/^\/api\/v1\/(workspaces|orca|term)(\/|$)/.test(u.pathname)) {
        return json({ ok: false, success: false, code: "FACE_UNAVAILABLE", error: "the agent's face (workspaces, terminals) runs on a local Pinebox (pinebox up without --mode cloud) - the cloud page has no host terminal" }, 501);
      }
      if (u.pathname === "/api/v1/chart/cells") {
        const cells = await getCells(env);
        return json({ ok: true, cells: cells.map((c) => ({ pair: c.pair, symbol: c.symbol || c.pair, timeframe: c.timeframe, bars: c.bars.length })) });
      }
      // THE BAR STORE (harvested TradingView series, Feb 2025 -> the last fetch): data/bars/<SYMBOL>/<TF>/<YYYY-MM>.json
      // + index.json, shipped as assets. A series that exists in the store is served FROM the store with from/to range
      // reads; a series the store lacks keeps the fixture path (named refusals unchanged).
      if (u.pathname === "/api/v1/chart/store") {
        const r = await env.ASSETS.fetch("https://assets.local/data/bars/index.json");
        if (!r.ok) return json({ ok: false, refusal: { token: "BARS_STORE_ABSENT", detail: "no bar store is deployed under data/bars (harvest with tools/harvest-tv.mjs, then deploy)" } });
        return new Response(await r.text(), { headers: { "content-type": "application/json" } });
      }
      if (u.pathname === "/api/v1/chart/bars" || u.pathname === "/api/v1/bars") {
        // STORE FIRST: if the pair/timeframe exists in the store, range-serve it (from/to optional, ms epoch or ISO)
        {
          const q0 = new URLSearchParams(u.search);
          const sym = storeSymbol(q0.get("pair") || "");
          const tf = storeTf(q0.get("timeframe") || "");
          const idx = await storeIndex(env);
          const row = idx[sym + "|" + tf];
          if (row) {
            const from = q0.get("from") ? Date.parse(q0.get("from") + (isNaN(Number(q0.get("from"))) ? "" : "")) || Number(q0.get("from")) : null;
            const to = q0.get("to") ? Date.parse(q0.get("to") + "") || Number(q0.get("to")) : null;
            const months = await storeMonths(env, sym, tf, from, to);
            let bars = [];
            for (const m of months) {
              const mr = await env.ASSETS.fetch("https://assets.local/data/bars/" + sym.replace(":", "_") + "/" + tf + "/" + m + ".json");
              if (!mr.ok) return json({ ok: false, refusal: { token: "BARS_STORE_HOLE", detail: "month " + m + " of " + sym + " " + tf + " is in the index but not deployed" } });
              bars = bars.concat(JSON.parse(await mr.text()));
            }
            if (from != null) bars = bars.filter((b) => b.time >= from);
            if (to != null) bars = bars.filter((b) => b.time <= to);
            if (!bars.length) return json({ ok: false, refusal: { token: "BARS_RANGE_ABSENT", detail: sym + " " + tf + " has no bars in [" + q0.get("from") + " .. " + q0.get("to") + "] (store: " + row.first + " -> " + row.last + ")" } });
            return json({ success: true, data: { pair: normPair(q0.get("pair")), symbol: sym, timeframe: q0.get("timeframe"), count: bars.length, source: "store:" + row.first + ".." + row.last, utc: true, bars } });
          }
        }
        const q = new URLSearchParams(u.search);
        const space = ((q.get("space") || "1")) !== "0";
        const bars = await barsFor(env, q.get("pair") || "", q.get("timeframe") || "", space);
        const cells = await getCells(env);
        const c = cells.find((x) => normPair(x.pair) === normPair(q.get("pair")) && String(x.timeframe) === String(q.get("timeframe")));
        return json({ success: true, data: { pair: normPair(q.get("pair")), timeframe: q.get("timeframe"), count: bars.length, utc: true, bars } });
      }
      if (u.pathname === "/api/v1/e1/zones") {
        const q = new URLSearchParams(u.search);
        // Zone files key pairs dash-joined (EURUSD-2026-07-06), never slash-joined.
        const pair = String(q.get("pair") || "").replace("/", "");
        const week = String(q.get("week") || "2026-07-06");
        // Assets are content-hashed: resolve the served name via build.json zones.
        let name = pair + "-" + week + ".json";
        try {
          const br = await env.ASSETS.fetch("https://assets.local/build.json");
          if (br.ok) {
            const zones = (JSON.parse(await br.text())).zones || {};
            const hit = zones[pair + "-" + week];
            if (typeof hit === "string" && hit.startsWith("/assets/")) name = hit.slice("/assets/".length);
          }
        } catch { name = pair + "-" + week + ".json"; }
        const r = await env.ASSETS.fetch("https://assets.local/assets/" + name);
        if (!r.ok) {
          return json({ ok: false, refusal: { token: "E1_ABSENT", detail: "no E1 zones for pair " + JSON.stringify(pair) + " week " + JSON.stringify(week) + " - check /build.json zones for the served pairs" } });
        }
        return new Response(await r.text(), { headers: { "content-type": "application/json" } });
      }
      if (u.pathname === "/build.json") {
        const r = await env.ASSETS.fetch("https://assets.local/build.json");
        if (!r.ok) {
          return json({ ok: false, refusal: { token: "ASSET_BUILD_FAILED", detail: "build.json did not serve - redeploy with the built dist-web" } });
        }
        return new Response(await r.text(), { headers: { "content-type": "application/json" } });
      }
      // Instance-scoped routes.
      const m = u.pathname.match(/^\/api\/v1\/i\/([^/]+)\/(socket|verb|state|attach)$/);
      if (m) {
        const name = decodeURIComponent(m[1]);
        if (!/^[A-Za-z0-9_.:-]{1,128}$/.test(name)) {
          return json({ ok: false, refusal: { token: "INSTANCE_ABSENT", detail: "bad instance name " + JSON.stringify(name) } }, 404);
        }
        // existence is answered by the instance object itself (INSTANCE_ABSENT, 404) on the same call - no
        // extra worker->object round trip per verb (there were two)
        const stub = instanceStub(env, name);
        // the SERVED build (the content hash of what this deploy serves) rides every call: the object compares pages against it
        const sub = "https://instance.local/" + m[2] + (u.search ? u.search + "&" : "?") + "inst=" + encodeURIComponent(name) + "&served=" + encodeURIComponent(await servedBuild(env));
        return stub.fetch(new Request(sub, { method: request.method, headers: request.headers, body: ["GET", "HEAD"].includes(request.method) ? undefined : request.body, duplex: "half" }));
      }
      const mc = u.pathname.match(/^\/api\/v1\/i\/([^/]+)$/);
      if (mc && (request.method === "PUT" || request.method === "DELETE")) {
        const name = decodeURIComponent(mc[1]);
        if (!/^[A-Za-z0-9_.:-]{1,128}$/.test(name)) {
          return json({ ok: false, refusal: { token: "INSTANCE_ABSENT", detail: "bad instance name " + JSON.stringify(name) } }, 404);
        }
        const stub = instanceStub(env, name);
        let body = {};
        try { body = request.method === "PUT" ? await request.json() : {}; } catch { body = {}; }
        if (request.method === "PUT") body = Object.assign({}, body, { build: await servedBuild(env) });
        return stub.fetch(new Request("https://instance.local/" + (request.method === "DELETE" ? "destroy" : "attach"), { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body || {}) }));
      }
      // The app shell + instance pages inject the page agent + build id.
      if (u.pathname === "/" || u.pathname === "/pinebox-page.js" || u.pathname.startsWith("/i/")) {
        if (u.pathname === "/pinebox-page.js") {
          const r = await env.ASSETS.fetch("https://assets.local/pinebox-page.js");
          if (!r.ok) {
            return new Response("// PINEBOX_PAGE_ABSENT: redeploy with web/pinebox-page.js in dist-web", { headers: { "content-type": "text/javascript" } });
          }
          return new Response(await r.text(), { headers: { "content-type": "text/javascript" } });
        }
        const r = await env.ASSETS.fetch("https://assets.local/pine.html");
        if (!r.ok) {
          throw new Refusal("ASSET_BUILD_FAILED: pine.html did not serve - redeploy with the built dist-web");
        }
        let html = await r.text();
        const build = await servedBuild(env);
        if (!html.includes("/pinebox-page.js")) {
          html = html.replace("</body>", '<script src="/pinebox-page.js"></script></body>');
        }
        html = html.replace("<html", '<html data-build="' + build + '"');
        // /i/<inst> pages resolve the shell's RELATIVE assets (tabs/*.js, styles.css) from the
        // site root - without the base they resolve under /i/ and the capability gate 403s them.
        html = html.replace("<head>", '<head><base href="/">' + (u.pathname.startsWith("/i/") ? STORAGE_SCOPE_SCRIPT : ""));
        const headers = { "content-type": "text/html" };
        if (u.pathname.startsWith("/i/")) {
          const inst = decodeURIComponent(u.pathname.split("/")[2] || "");
          headers["set-cookie"] = capCookieName(inst) + "=" + inst.split(":")[0] + "; Path=/api/v1/; Secure; HttpOnly; SameSite=Strict";
        }
        return new Response(html, { headers });
      }
      return env.ASSETS.fetch(request);
    } catch (err) {
      if (err instanceof Refusal || (err && err.code)) return refusal(err);
      return refusal(new Refusal("BACKEND_UNREACHABLE: " + (err instanceof Error ? err.message : String(err)) + " - check the deploy, then retry"));
    }
  },
};
