// src/library.ts — BacktestLibrary: ONE Durable Object (SQLite class), named `library`.
// W2.2a/W2.2b. Tables: sessions/backtest_trades/backtest_events (the fork's
// schema.sql text verbatim) + own indexes. ReplayRoom + stats COPIED from the
// fork (byte-exact imports, adapted only for ESM). Play alarms (one alarm chain
// while any session plays; speeds 0.5/1/2/5/10/25 bars-per-second).
// Ops: create/state/play/pause/step/speed/date/stop/place/close/list/open/export/delete
// (delete is the ONLY remover; export returns trades+events+summary JSON).
//
// NO-SUBSTITUTE LAW: every missing substrate throws `new Refusal("<COMPONENT>_UNAVAILABLE: ...")`;
// every failed call returns a NAMED refusal result. No catch swallows an outcome:
// a catch either rethrows a Refusal/ReplayError or converts it into a refusal.
// No rung ladders (`a ?? b ?? c` over alternative sources), no dev defaults for
// money fields, no `marketFill`/`pct` invention beyond what the fork documents.

import { ReplayRoom, ReplayError, CODES } from "./room/replay.mjs";
import { summarize, canonSummary } from "./room/stats.mjs";
import { rolloverCheck } from "./code-stamp.ts";

/** A missing substrate or a failed call that must surface by NAME, never as a substitute. */
class Refusal extends Error {
  constructor(message) {
    super(message);
    this.name = "Refusal";
    const i = message.indexOf(":");
    this.code = i > 0 ? message.slice(0, i).trim() : "REFUSAL";
  }
}

const SPEEDS = [0.5, 1, 2, 5, 10, 25];
const MAX_BARS_PER_TICK = 25;
const FIXTURE_WEEK = "2026-07-06";

const refuse = (code, detail) => ({ ok: false, refusal: { token: code, detail: String(detail ?? "") } });
const ok = (result) => ({ ok: true, result });

function isValidUid(uid) {
  return typeof uid === "string" && /^[A-Za-z0-9_.:-]{1,64}$/.test(uid);
}

function normPair(p) {
  const s = String(p || "").trim().toUpperCase().replace("-", "/");
  return s.includes("/") ? s : s.length === 6 ? s.slice(0, 3) + "/" + s.slice(3) : s;
}

function toBars(cellBars) {
  if (!Array.isArray(cellBars) || cellBars.length === 0) return null;
  return cellBars.map((b) => ({
    time: b.timestamp, open: b.open, high: b.high, low: b.low, close: b.close, volume: b.volume || 0,
  }));
}

/** The fixture is the ONE substrate. Missing binding, failed fetch, bad JSON,
 *  or an absent cell all throw FIXTURE_UNAVAILABLE — never an empty series. */
// ── THE STORE LEG (operator 2026-11-07): exact TradingView series Feb 2025 -> now, shipped as assets.
// Every session and every view reads this store; a pair/timeframe it lacks is refused BY NAME (BARS_STORE_ABSENT).
// THE SERIES CACHE (operator: timeframe switching took 10 s+): the months are immutable, so a pair|tf is read
// from the assets ONCE per durable object lifetime and reused by every later op (view switches are now ~0 ms of IO).
const _seriesCache = new Map<string, Promise<any[] | null>>();
async function loadStoreBars(env, pair, timeframe): Promise<any[] | null> {
  const symKey = (pair.includes(":") ? pair : storeSymbolOf(pair)) + "|" + storeTfOf(timeframe);
  if (_seriesCache.has(symKey)) return _seriesCache.get(symKey);
  const p = loadStoreBarsUncached(env, pair, timeframe);
  _seriesCache.set(symKey, p);
  return p;
}
async function loadStoreBarsUncached(env, pair, timeframe): Promise<any[] | null> {
  const sym = pair.includes(":") ? pair : storeSymbolOf(pair);
  const tf = storeTfOf(timeframe);
  if (!sym || !tf) return null;
  const ir = await env.ASSETS.fetch("https://assets.local/data/bars/index.json");
  if (!ir.ok) return null;                       // no store deployed: the fixture path keeps its own refusals
  const idx = JSON.parse(await ir.text());
  const row = idx[sym + "|" + tf];
  if (!row) return null;                         // this pair/tf is not in the store: the fixture path
  const months: string[] = [];
  const d = new Date(row.first); d.setUTCDate(1);
  const end = new Date(row.last);
  while (d <= end) { months.push(d.toISOString().slice(0, 7)); d.setUTCMonth(d.getUTCMonth() + 1); }
  const out: any[] = [];
  for (const m of months) {
    const r = await env.ASSETS.fetch("https://assets.local/data/bars/" + sym.replace(":", "_") + "/" + tf + "/" + m + ".json");
    if (!r.ok) throw new Refusal("BARS_STORE_HOLE: the index lists month " + m + " of " + sym + " " + tf + " but it is not deployed - re-harvest + redeploy");
    out.push(...JSON.parse(await r.text()));
  }
  return out;
}
function storeSymbolOf(pair) {
  const p = String(pair || "").toUpperCase().replace(/[^A-Z0-9:]/g, "");
  if (p === "DXY" || p === "DOLLARIDXUSD") return "TVC:DXY";
  if (p === "EURUSD") return "FX:EURUSD";
  if (p === "GBPUSD") return "FX:GBPUSD";
  return null;
}
function storeTfOf(tf) {
  const t = String(tf || "").trim().toLowerCase();
  if (t.endsWith("m")) return t.slice(0, -1);
  if (t.endsWith("h")) return String(parseInt(t) * 60);
  return t === "15" || t === "30" || t === "60" || t === "240" ? t : null;
}


const SCHEMA_TRADES = `CREATE TABLE IF NOT EXISTS backtest_trades (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    trade_uid           TEXT    NOT NULL UNIQUE,
    session_uid         TEXT    NOT NULL,
    position_id         TEXT    NOT NULL,
    order_id            TEXT,
    seq                 INTEGER NOT NULL,
    symbol              TEXT    NOT NULL,
    timeframe           TEXT,
    side                TEXT    NOT NULL,
    kind                TEXT    NOT NULL,
    reason              TEXT,
    qty                 REAL    NOT NULL,
    price               REAL    NOT NULL,
    pct_of_position     REAL,
    pnl                 REAL    DEFAULT 0,
    r_multiple          REAL,
    position_pnl        REAL,
    position_bars       INTEGER,
    qty_remaining       REAL,
    sl                  REAL,
    tp                  REAL,
    bar_index           INTEGER NOT NULL,
    bar_time            INTEGER NOT NULL,
    bar_iso             TEXT    NOT NULL,
    note                TEXT,
    tags                TEXT,
    created_at          TEXT    NOT NULL DEFAULT (datetime('now'))
)`;
const SCHEMA_EVENTS = `CREATE TABLE IF NOT EXISTS backtest_events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_uid     TEXT    NOT NULL,
    seq             INTEGER NOT NULL,
    at              TEXT    NOT NULL DEFAULT (datetime('now')),
    actor           TEXT    NOT NULL DEFAULT 'human',
    verb            TEXT    NOT NULL,
    detail          TEXT,
    cursor          INTEGER,
    visible_bars    INTEGER
)`;
const SCHEMA_SESSIONS = `CREATE TABLE IF NOT EXISTS sessions (
  uid        TEXT PRIMARY KEY,
  name       TEXT NOT NULL,
  pair       TEXT NOT NULL,
  tf         TEXT NOT NULL,
  week       TEXT NOT NULL,
  start_at   INTEGER NOT NULL,
  cursor     INTEGER NOT NULL,
  balance0   REAL NOT NULL,
  status     TEXT NOT NULL,
  origin     TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
)`;

export class BacktestLibrary {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    if (!state || !state.storage || !state.storage.sql) {
      throw new Refusal("STORE_UNAVAILABLE: Durable Object SQLite storage is missing - redeploy with the v2 migration (new_sqlite_classes) applied and retry");
    }
    this.sql = state.storage.sql;
    this.rooms = new Map();
    this.streams = new Map(); // session uid -> token -> {token, frames[]} (the /stream push channel)
  }

  ensureSchema() {
    try {
      this.sql.exec(SCHEMA_SESSIONS);
      this.sql.exec(SCHEMA_TRADES);
      this.sql.exec(SCHEMA_EVENTS);
      this.sql.exec("CREATE INDEX IF NOT EXISTS idx_bt_trades_session ON backtest_trades(session_uid, seq)");
      this.sql.exec("CREATE INDEX IF NOT EXISTS idx_bt_trades_position ON backtest_trades(session_uid, position_id)");
      this.sql.exec("CREATE INDEX IF NOT EXISTS idx_bt_trades_kind ON backtest_trades(session_uid, kind)");
      this.sql.exec("CREATE INDEX IF NOT EXISTS idx_bt_events_session ON backtest_events(session_uid, seq)");
      this.sql.exec("CREATE INDEX IF NOT EXISTS idx_sessions_origin ON sessions(origin)");
      this.sql.exec("CREATE INDEX IF NOT EXISTS idx_library_sessions_pair_tf ON sessions(pair, tf)");
      // Control-shaped list + resume restore need room extension columns on the cloud
      // sessions table. Additive migration: each ALTER runs once; a duplicate-column
      // error means an older object already migrated and is ignored by name.
      const ADD_COLUMNS = [
        ["start_date", "TEXT"], ["end_date", "TEXT"], ["strategy", "TEXT"],
        ["playbook", "TEXT"], ["symbols", "TEXT"], ["balance", "REAL"],
        ["realized", "REAL"], ["equity", "REAL"], ["bars_total", "INTEGER"],
        ["visible_bars", "INTEGER"], ["fills", "INTEGER"], ["total_trades", "INTEGER"],
        ["win_rate", "REAL"], ["profit_factor", "REAL"], ["session_notes", "TEXT"],
        ["tags", "TEXT"], ["bars_source", "TEXT"], ["agent_id", "TEXT"],
      ];
      for (const [col, typ] of ADD_COLUMNS) {
        try {
          this.sql.exec("ALTER TABLE sessions ADD COLUMN " + col + " " + typ);
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          if (!/duplicate column/i.test(msg)) {
            throw new Refusal("STORE_UNAVAILABLE: schema migration failed on " + col + " (" + msg + ") - redeploy with the v2 migration applied and retry");
          }
        }
      }
    } catch (err) {
      if (err instanceof Error && /SQLITE_FULL/i.test(err.message)) {
        throw new Refusal("STORE_FULL: the library object reached its SQLite limit - run backtest --op export then --op delete on old sessions");
      }
      throw new Refusal("STORE_UNAVAILABLE: schema setup failed (" + (err instanceof Error ? err.message : String(err)) + ") - redeploy with the v2 migration applied and retry");
    }
  }

  one(q, ...params) {
    try {
      return this.sql.exec(q, ...params).toArray()[0] ?? null;
    } catch (err) {
      if (err instanceof Error && /SQLITE_FULL/i.test(err.message)) {
        throw new Refusal("STORE_FULL: the library object reached its SQLite limit - run backtest --op export then --op delete on old sessions");
      }
      throw new Refusal("STORE_UNAVAILABLE: a session read failed (" + (err instanceof Error ? err.message : String(err)) + ") - retry; if it repeats, export and delete old sessions");
    }
  }

  all(q, ...params) {
    try {
      return this.sql.exec(q, ...params).toArray();
    } catch (err) {
      if (err instanceof Error && /SQLITE_FULL/i.test(err.message)) {
        throw new Refusal("STORE_FULL: the library object reached its SQLite limit - run backtest --op export then --op delete on old sessions");
      }
      throw new Refusal("STORE_UNAVAILABLE: a session read failed (" + (err instanceof Error ? err.message : String(err)) + ") - retry; if it repeats, export and delete old sessions");
    }
  }

  run(q, ...params) {
    try {
      this.sql.exec(q, ...params);
    } catch (err) {
      if (err instanceof Error && /SQLITE_FULL/i.test(err.message)) {
        throw new Refusal("STORE_FULL: the library object reached its SQLite limit - run backtest --op export then --op delete on old sessions");
      }
      throw new Refusal("STORE_UNAVAILABLE: a session write failed (" + (err instanceof Error ? err.message : String(err)) + ") - retry; if it repeats, export and delete old sessions");
    }
  }

  setStatus(uid, status) {
    this.run("UPDATE sessions SET status=?, updated_at=? WHERE uid=?", status, Date.now(), uid);
  }

  recordEvent(uid, actor, verb, detail, st) {
    const row = this.one("SELECT COALESCE(MAX(seq),0)+1 AS n FROM backtest_events WHERE session_uid=?", uid);
    const seq = (row && row.n) || 1;
    this.run(
      "INSERT INTO backtest_events (session_uid, seq, actor, verb, detail, cursor, visible_bars) VALUES (?,?,?,?,?,?,?)",
      uid, seq, actor, verb,
      detail == null ? null : typeof detail === "string" ? detail : JSON.stringify(detail),
      st?.cursor ?? null, st?.visibleBars ?? null
    );
    return seq;
  }

  syncFills(uid, symbol, timeframe, fills, closed) {
    const byPos = new Map((closed || []).map((c) => [c.id, c]));
    const maxRow = this.one("SELECT COALESCE(MAX(seq),0) n FROM backtest_trades WHERE session_uid=?", uid);
    const maxSeq = maxRow ? maxRow.n : 0;
    const keep = new Set(fills.map((f) => f.seq));
    if (fills.length < maxSeq) {
      const rows = this.all("SELECT seq FROM backtest_trades WHERE session_uid=?", uid);
      for (const r of rows) {
        if (!keep.has(r.seq)) this.run("DELETE FROM backtest_trades WHERE session_uid=? AND seq=?", uid, r.seq);
      }
    }
    for (const f of fills) {
      const settled = f.kind === "exit" ? byPos.get(f.positionId) : null;
      const trade_uid = `${uid}:${f.positionId}:${f.seq}:${f.kind}`;
      this.run(
        `INSERT OR REPLACE INTO backtest_trades
        (trade_uid, session_uid, position_id, order_id, seq, symbol, timeframe, side, kind, reason,
         qty, price, pct_of_position, pnl, r_multiple, position_pnl, position_bars, qty_remaining,
         sl, tp, bar_index, bar_time, bar_iso, note, tags)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        trade_uid, uid, f.positionId, f.orderId ?? null, f.seq, symbol, timeframe, f.side, f.kind,
        f.reason ?? null, f.qty, f.price, f.pctOfPosition ?? null, f.pnl ?? 0,
        settled?.r ?? null, settled?.pnl ?? null, settled?.bars ?? null, f.qtyRemaining ?? null,
        settled?.sl0 ?? null, settled?.tp ?? null, f.barIndex, f.time, f.iso,
        settled?.note ?? null, settled?.tags ? JSON.stringify(settled.tags) : null
      );
    }
    return fills.length;
  }

  /** Rebuild the live ReplayRoom for uid from the durable rows + the audit trail.
   *  A corrupt event detail aborts the resume by NAME (SESSION_RESUME_UNAVAILABLE) —
   *  it is never replayed as an empty rule. */
  async hydrate(uid) {
    const row = this.one("SELECT * FROM sessions WHERE uid=?", uid);
    if (!row) return null;
    // ONE series: the store. A session resumes only where its own recorded start bar (start_at) is the bar the replay
    // starts on - otherwise it was built on a different series and is refused by name, never replayed at another moment.
    const bars = await loadStoreBars(this.env, row.pair, row.tf);
    if (!bars || !bars.length) throw new Refusal("BARS_STORE_ABSENT: the bar store has no " + row.pair + " " + row.tf + " series for session " + uid + " - pinebox data --op fetch-latest, then reopen");
    let room;
    try {
      let symbols = [row.pair];
      try {
        const sj = row.symbols ? JSON.parse(row.symbols) : null;
        if (Array.isArray(sj) && sj.length) symbols = sj.slice(0, 5);
      } catch {
        throw new Refusal("SESSION_RESUME_UNAVAILABLE: session " + uid + " has a corrupt symbols field - export then delete the session and recreate it");
      }
      room = new ReplayRoom({
        bars,
        session: {
          uid: row.uid, name: row.name, symbol: row.pair, timeframe: row.tf,
          strategy: row.strategy ?? null, playbook: row.playbook ?? null, symbols,
          startDate: row.start_date ?? null, endDate: row.end_date ?? null,
          startingBalance: row.balance0,
        },
      });
    } catch (err) {
      if (err instanceof ReplayError) throw err;
      throw new Refusal("SESSION_RESUME_UNAVAILABLE: session " + uid + " could not rebuild its engine (" + (err instanceof Error ? err.message : String(err)) + ") - export then delete the session and recreate it");
    }
    const sb0 = room.bars[room.startIndex];
    if (row.start_at != null && sb0 && Number(sb0.time) !== Number(row.start_at)) {
      throw new Refusal("SESSION_SERIES_MISMATCH: session " + uid + " started on the bar of " + new Date(Number(row.start_at)).toISOString() + " but the store's start bar is " + new Date(Number(sb0.time)).toISOString() + " - it was built on another series; export it, then create a new session");
    }
    const events = this.all("SELECT * FROM backtest_events WHERE session_uid=? ORDER BY seq ASC", uid);
    const APPLY = {
      create: () => {},
      step: (x) => room.step(Number(x.delta)),
      jump: (x) => room.jump(x),
      play: (x) => { room.play(x.rate ?? 1); room.pause(); },
      "play-step": () => room.step(1),
      "play-end": () => room.pause(),
      pause: () => room.pause(),
      speed: (x) => { const r = Number(x.rate); if (Number.isFinite(r) && r > 0) speed = r; },
      date: (x) => room.jump(x.date),
      place: (x) => room.place(x),
      modify: (x) => room.modify(x.id, x),
      close: (x) => room.closePartial(x.pct ?? 100, { positionId: x.positionId, reason: x.reason || "MANUAL", price: x.price }),
      cancel: (x) => room.cancel(x.id),
      note: (x) => room.note(x.text ?? "", { tradeId: x.tradeId, tags: x.tags }),
      finish: () => {},
    };
    let speed = 1;
    let replayed = 0;
    for (const ev of events) {
      if (ev.verb === "resume" || ev.verb === "CANON_API_UNAVAILABLE" || ev.verb === "REPLAY_PLAY_FAILED") continue;
      const fn = APPLY[ev.verb];
      if (!fn) {
        throw new Refusal("SESSION_RESUME_UNAVAILABLE: event #" + ev.seq + " '" + ev.verb + "' has no replay rule - export then delete the session and recreate it");
      }
      let x;
      if (ev.detail == null || ev.detail === "") {
        x = {};
      } else {
        try {
          x = JSON.parse(ev.detail);
        } catch {
          throw new Refusal("SESSION_RESUME_UNAVAILABLE: event #" + ev.seq + " '" + ev.verb + "' detail is not JSON - export then delete the session and recreate it");
        }
      }
      if (x == null || typeof x !== "object") {
        throw new Refusal("SESSION_RESUME_UNAVAILABLE: event #" + ev.seq + " '" + ev.verb + "' detail is not an object - export then delete the session and recreate it");
      }
      try {
        fn(x);
      } catch (err) {
        if (err instanceof ReplayError) throw err;
        throw new Refusal("SESSION_RESUME_UNAVAILABLE: event #" + ev.seq + " '" + ev.verb + "' failed on replay (" + (err instanceof Error ? err.message : String(err)) + ") - export then delete the session and recreate it");
      }
      replayed++;
    }
    room.pause();
    this.rooms.set(uid, { room, speed, playing: false });
    return { room, replayed, events: events.length };
  }

  async ensureLive(uid) {
    const live = this.rooms.get(uid);
    if (live) return live;
    const h = await this.hydrate(uid);
    if (!h) return null;
    return this.rooms.get(uid);
  }

  persist(uid, entry, actor, verb, detail, opts) {
    const st = entry.room.status();
    const fills = entry.room.fills.length;
    const finished = st.atEnd && entry.room.positions.length === 0;
    const next = (opts && opts.status) ? opts.status : (finished ? "COMPLETED" : "RUNNING");
    this.run(
      "UPDATE sessions SET cursor=?, status=?, balance=?, realized=?, equity=?, bars_total=?, visible_bars=?, fills=?, total_trades=?, win_rate=?, profit_factor=?, session_notes=?, tags=?, updated_at=? WHERE uid=?",
      st.cursor, next,
      st.balance, st.realized, st.equity, st.barsTotal, st.visibleBars, fills,
      st.stats.trades_total, st.stats.winRate.estimate, st.stats.profitFactor.value,
      st.sessionNotes ?? "", JSON.stringify(st.tags || []),
      Date.now(), uid
    );
    this.syncFills(uid, st.symbol, st.timeframe, entry.room.fills, entry.room.closed);
    this.recordEvent(uid, actor, verb, detail, st);
    return st;
  }

  rowStatus(uid) {
    const r = this.one("SELECT status FROM sessions WHERE uid=?", uid);
    return r ? r.status : null;
  }

  /** Push one frame to every live /stream poller for uid. The DO holds the frames
   *  (it outlives the page's response); each /stream response long-polls them via
   *  stream-pull. Dead sets are dropped; zero readers is a no-op returning 0. */
  broadcast(uid, evt) {
    let set = this.streams.get(uid);
    if (!set) {
      set = new Map();
      this.streams.set(uid, set);
    }
    for (const [, sub] of [...set]) {
      try {
        sub.frames.push(evt);
      } catch {
        set.delete(sub);
      }
    }
    return set.size;
  }

  streamRegister(uid) {
    if (!isValidUid(uid)) throw new Refusal("BAD_SESSION_ID: bad session id " + JSON.stringify(uid));
    const row = this.one("SELECT 1 AS x FROM sessions WHERE uid=?", uid);
    if (!row) throw new Refusal("SESSION_ABSENT: no session " + JSON.stringify(uid));
    let set = this.streams.get(uid);
    if (!set) {
      set = new Map();
      this.streams.set(uid, set);
    }
    for (const [, sub] of [...set]) {
      if (sub.frames.length > 200) {
        try { sub.close(); } catch { /* already gone */ }
        set.delete(sub.token);
      }
    }
    const token = `st-${Date.now().toString(36)}-${Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, "0")}`;
    const sub = { token, frames: [], created: Date.now(), close() { this.closed = true; } };
    set.set(token, sub);
    return { token };
  }

  streamPull(uid, token) {
    const set = this.streams.get(uid);
    if (!set) throw new Refusal("STREAM_GONE: no stream set for session " + JSON.stringify(uid) + " - reopen /stream");
    const sub = set.get(token);
    if (!sub) throw new Refusal("STREAM_UNKNOWN: unknown stream token - reopen /stream");
    const frames = sub.frames.splice(0, sub.frames.length);
    return { frames };
  }

  streamUnregister(uid, token) {
    const set = this.streams.get(uid);
    if (!set) return { gone: true };
    const sub = set.get(token);
    if (sub) {
      try { sub.close(); } catch { /* already gone */ }
      set.delete(token);
    }
    if (set.size === 0) this.streams.delete(uid);
    return { gone: false };
  }

  async maybeAlarm() {
    const any = [...this.rooms.values()].some((e) => e.playing);
    if (!any) return;
    const speeds = [...this.rooms.values()].filter((e) => e.playing).map((e) => e.speed || 1);
    const fastest = Math.max(...speeds);
    const delayMs = Math.max(40, Math.round(1000 / fastest));
    try {
      await this.state.storage.setAlarm(Date.now() + delayMs);
    } catch (err) {
      throw new Refusal("ALARM_FAILED: the replay alarm could not be set (" + (err instanceof Error ? err.message : String(err)) + ") - pause the session and retry play");
    }
  }

  async alarm() {
    this.ensureSchema();
    let advanced = 0;
    for (const [uid, entry] of [...this.rooms.entries()]) {
      if (!entry.playing) continue;
      const n = Math.max(1, Math.min(MAX_BARS_PER_TICK, Math.round(entry.speed || 1)));
      try {
        for (let i = 0; i < n; i++) {
          if (entry.room.cursor >= entry.room.endIndex) {
            entry.playing = false;
            entry.room.pause();
            this.recordEvent(uid, "system", "play-end", { reason: "last bar of the session" }, entry.room.status());
            this.setStatus(uid, "COMPLETED");
            this.broadcast(uid, { type: "ended", session: uid, cursor: entry.room.cursor });
            this.broadcast(uid, { type: "status", session: uid, status: entry.room.status(), verb: "play-end", actor: "system" });
            break;
          }
          entry.room.step(1);
          advanced++;
        }
        const st = this.persist(uid, entry, "system", "play-step", { rate: entry.speed });
        this.broadcast(uid, { type: "status", session: uid, status: st, verb: "play-step", actor: "system" });
      } catch (err) {
        entry.playing = false;
        entry.room.pause();
        const msg = err instanceof Error ? err.message : String(err);
        this.recordEvent(uid, "system", "REPLAY_PLAY_FAILED", { error: msg }, entry.room.status());
        this.setStatus(uid, "RUNNING");
        this.broadcast(uid, { type: "error", session: uid, code: err instanceof ReplayError ? err.code : "PLAY_ERROR", error: msg });
      }
    }
    await this.maybeAlarm();
    return { ok: true, advanced };
  }

  async op(cmd) {
    this.ensureSchema();
    const { op, uid, actor } = cmd;
    if (!op) return refuse("BAD_OP", "op is required (create|state|window|summary|fills|eventsrows|play|pause|step|speed|date|jump|stop|place|modify|close|cancel|note|list|open|export|delete)");
    const who = typeof actor === "string" && actor.length > 0 ? actor : "human";
    try {
      switch (op) {
        case "create": {
          const { name, pair, tf, week, startingBalance, origin } = cmd;
          const symbol = cmd.symbol != null ? cmd.symbol : pair;
          const timeframe = cmd.timeframe != null ? cmd.timeframe : tf;
          const stDate = cmd.startDate != null ? cmd.startDate : cmd.start_date;
          const enDate = cmd.endDate != null ? cmd.endDate : cmd.end_date;
          if (typeof name !== "string" || name.trim().length === 0) return refuse("BAD_ORDER", "create needs a non-empty name");
          if (typeof symbol !== "string" || symbol.trim().length === 0) return refuse("BAD_ORDER", "create needs symbol (pair)");
          if (typeof timeframe !== "string" || timeframe.trim().length === 0) return refuse("BAD_ORDER", "create needs timeframe");
          if (!Number.isFinite(Number(startingBalance)) || Number(startingBalance) <= 0) {
            return refuse("BAD_ORDER", "create needs a startingBalance number > 0 (no default is assumed)");
          }
          if (typeof origin !== "string" || origin.trim().length === 0) return refuse("BAD_ORDER", "create needs origin (<session>:<instance>)");
          if (week != null && String(week) !== FIXTURE_WEEK) {
            return refuse("WEEK_MISMATCH", "only week " + FIXTURE_WEEK + " is served (got " + JSON.stringify(week) + ")");
          }
          if (cmd.barsSource != null && cmd.barsSource !== "fixture" && cmd.barsSource !== "store" && cmd.barsSource !== "tv") {
            return refuse("BARS_SOURCE_UNAVAILABLE", "only barsSource fixture is served in the cloud (got " + JSON.stringify(cmd.barsSource) + ") - TV history is unavailable without the :9448 feed");
          }
          // EVERY session reads the full TradingView store (operator 2026-11-08: no data type). A pair/timeframe the store
          // does not carry is refused BY NAME - a session is never built on a different series than the one asked for.
          const bars = await loadStoreBars(this.env, symbol, timeframe);
          if (!bars || !bars.length) return refuse("BARS_STORE_ABSENT", "the bar store has no " + symbol + " " + timeframe + " series - it carries DXY, EURUSD, GBPUSD at 15m/30m/1H/4H (pinebox data --op fetch-latest)");
          const startMs = stDate == null || stDate === "" ? null : (typeof stDate === "number" ? stDate : Date.parse(stDate));
          const endMs = enDate == null || enDate === "" ? null : (typeof enDate === "number" ? enDate : Date.parse(enDate));
          if ((stDate != null && stDate !== "") && !Number.isFinite(startMs)) return refuse("BAD_DATE", "create startDate is not a date: " + JSON.stringify(stDate));
          if ((enDate != null && enDate !== "") && !Number.isFinite(endMs)) return refuse("BAD_DATE", "create endDate is not a date: " + JSON.stringify(enDate));
          let room;
          try {
            room = new ReplayRoom({
              bars,
              session: {
                uid: "tmp", name, symbol: symbol, timeframe: timeframe,
                strategy: typeof cmd.strategy === "string" ? cmd.strategy : null,
                playbook: typeof cmd.playbook === "string" ? cmd.playbook : null,
                symbols: [symbol],
                startDate: startMs == null ? null : new Date(startMs).toISOString(),
                endDate: endMs == null ? null : new Date(endMs).toISOString(),
                startingBalance: Number(startingBalance),
              },
            });
          } catch (err) {
            if (err instanceof ReplayError) throw err;
            throw new Refusal("SESSION_RESUME_UNAVAILABLE: the session engine could not start (" + (err instanceof Error ? err.message : String(err)) + ") - retry with a served pair/tf");
          }
          const id = `bt-${Date.now().toString(36)}-${Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, "0")}`;
          room.session.uid = id;
          const now = Date.now();
          const st0 = room.status();
          this.run(
            "INSERT INTO sessions (uid, name, pair, tf, week, start_at, cursor, balance0, status, origin, created_at, updated_at, start_date, end_date, strategy, playbook, symbols, balance, realized, equity, bars_total, visible_bars, fills, total_trades, win_rate, profit_factor, session_notes, tags, bars_source, agent_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            id, name, symbol, String(timeframe), FIXTURE_WEEK,
            bars[room.startIndex].time, room.cursor, Number(startingBalance), "RUNNING", origin, now, now,
            startMs == null ? null : new Date(startMs).toISOString(), endMs == null ? null : new Date(endMs).toISOString(),
            typeof cmd.strategy === "string" ? cmd.strategy : null, typeof cmd.playbook === "string" ? cmd.playbook : null,
            JSON.stringify([symbol]),
            st0.balance, st0.realized, st0.equity, st0.barsTotal, st0.visibleBars, 0,
            st0.stats.trades_total, st0.stats.winRate.estimate, st0.stats.profitFactor.value,
            typeof cmd.description === "string" ? cmd.description : "", "[]", "store", who
          );
          this.rooms.set(id, { room, speed: 1, playing: false });
          this.recordEvent(id, who, "create", { pair: symbol, tf: timeframe, week: FIXTURE_WEEK }, room.status());
          this.broadcast(id, { type: "created", session: id, cursor: st0.cursor, visibleBars: st0.visibleBars });
          return ok({ session: id, status: room.status() });
        }
        case "state": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          return ok({ session: uid, status: live.room.status(), playing: live.playing, speed: live.speed });
        }
        case "view": {
          // ONE SESSION, ANY VIEW (operator 2026-11-07): the session's own bar series is aggregated to the asked
          // timeframe up to the CURRENT cursor - a timeframe change never creates a session, never moves the clock,
          // never fills differently (the fills already happened on the session's own bars).
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          const tf = storeTfOf(cmd.tf);
          if (!tf) return refuse("BAD_TF", "view needs tf 15m|30m|1H|4H (got " + JSON.stringify(cmd.tf) + ")");
          const st = live.room.status();
          const ms = { "15": 900e3, "30": 1800e3, "60": 3600e3, "240": 14400e3 }[tf];
          const bars = live.room.bars;
          const out = [];
          // A FINER view than the session's own timeframe cannot be built from the session's bars (a bucket smaller
          // than a bar returns the bar itself - measured 2026-11-08: tf=15 served 1H bars, step 60 min x5411). It is the
          // STORE's own series for the session's symbol, cut at the replay clock (the close of the cursor bar): only bars
          // that have CLOSED by then - no lookahead. A coarser view aggregates the revealed session bars (below).
          const sessMs = bars.length > 1 ? bars[1].time - bars[0].time : ms;
          const sessTfMs = { "15m": 900e3, "30m": 1800e3, "1H": 3600e3, "4H": 14400e3 }[String(st.timeframe)] || sessMs;
          if (ms < sessTfMs) {
            const clock = bars[st.cursor].time + sessTfMs;
            const series = await loadStoreBars(this.env, String(st.symbol || live.room.session.symbol || ""), tf);
            if (!series || !series.length) return refuse("VIEW_STORE_ABSENT", "the bar store has no " + tf + "-minute series for " + (st.symbol || "this session's symbol") + " - a finer view reads the store (pinebox data --op fetch-latest)");
            for (const b of series) { if (b.time + ms <= clock) out.push({ time: b.time, open: b.open, high: b.high, low: b.low, close: b.close, volume: b.volume || 0 }); }
          }
          let cur = null;
          for (let i = 0; ms >= sessTfMs && i <= st.cursor; i++) {
            const b = bars[i];
            if (i === 0 || cur === null) {
              cur = { time: b.time - (b.time % ms), open: b.open, high: b.high, low: b.low, close: b.close, volume: b.volume || 0 };
              out.push(cur);
              continue;
            }
            const slot = b.time - (b.time % ms);
            if (slot === cur.time) {
              cur.high = Math.max(cur.high, b.high);
              cur.low = Math.min(cur.low, b.low);
              cur.close = b.close;
              cur.volume += b.volume || 0;
            } else {
              cur = { time: slot, open: b.open, high: b.high, low: b.low, close: b.close, volume: b.volume || 0 };
              out.push(cur);
            }
          }
          const lookback = Number(cmd.lookback != null ? cmd.lookback : 300);
          const n = Number.isFinite(lookback) ? Math.max(1, Math.floor(lookback)) : 300;
          return ok({
            session: uid, tf: cmd.tf, timeframe: st.timeframe, cursor: st.cursor,
            barsTotal: out.length, from: Math.max(0, out.length - n),
            bars: out.slice(Math.max(0, out.length - n)),
            now: st.now,
            startIndex: st.startIndex,
          });
        }
        case "window": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          const raw = cmd.lookback != null ? Number(cmd.lookback) : 200;
          const lookback = Number.isFinite(raw) ? Math.max(1, Math.floor(raw)) : 200;
          let w;
          try {
            w = live.room.window(lookback);
          } catch (err) {
            if (err instanceof ReplayError) throw err;
            throw new Refusal("REPLAY_FAILED: window failed (" + (err instanceof Error ? err.message : String(err)) + ") - read state and retry");
          }
          const st = live.room.status();
          const cap = st.now && Number.isFinite(st.now.time) ? st.now.time : null;
          const bars = cap == null ? w.bars : w.bars.filter((b) => b && Number(b.time) <= cap);
          return ok({ session: uid, symbol: st.symbol, timeframe: st.timeframe, futureHidden: st.futureHidden, from: Math.max(0, st.cursor + 1 - bars.length), to: st.cursor, bars });
        }
        case "summary": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          let summary;
          try {
            summary = live.room.summary({ startedMs: live.startedMs ?? null, outcome: cmd.outcome || "RUNNING" });
          } catch (err) {
            if (err instanceof ReplayError) throw err;
            throw new Refusal("REPLAY_FAILED: summary failed (" + (err instanceof Error ? err.message : String(err)) + ") - read state and retry");
          }
          return ok({ session: uid, summary });
        }
        case "fills": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          const limit = Math.min(500, Math.max(1, Number(cmd.limit) || 500));
          const rows = this.all("SELECT * FROM backtest_trades WHERE session_uid=? ORDER BY seq ASC LIMIT ?", uid, limit);
          return ok({ session: uid, fills: rows });
        }
        case "eventsrows": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          const limit = Math.min(200, Math.max(1, Number(cmd.limit) || 200));
          const rows = this.all("SELECT * FROM backtest_events WHERE session_uid=? ORDER BY seq DESC LIMIT ?", uid, limit);
          return ok({ session: uid, events: rows });
        }
        case "play": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          const rate = Number(cmd.rate);
          if (!SPEEDS.includes(rate)) return refuse("BAD_RATE", "play needs an explicit rate, one of " + SPEEDS.join("/") + " bars-per-second (got " + JSON.stringify(cmd.rate) + ")");
          try {
            live.room.play(rate);
          } catch (err) {
            if (err instanceof ReplayError) throw err;
            throw new Refusal("REPLAY_PLAY_FAILED: play rejected the rate (" + (err instanceof Error ? err.message : String(err)) + ") - retry with one of " + SPEEDS.join("/"));
          }
          live.speed = rate;
          live.playing = true;
          const playSt = this.persist(uid, live, who, "play", { rate });
          this.broadcast(uid, { type: "status", session: uid, status: playSt, verb: "play", actor: who });
          await this.maybeAlarm();
          return ok({ session: uid, status: playSt, playing: true, speed: rate });
        }
        case "pause": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          live.room.pause();
          live.playing = false;
          const st = this.persist(uid, live, who, "pause", {});
          this.broadcast(uid, { type: "status", session: uid, status: st, verb: "pause", actor: who });
          await this.maybeAlarm();
          return ok({ session: uid, status: st, playing: false });
        }
        case "step": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          const d = Number(cmd.delta);
          if (d !== 1 && d !== -1) {
            return refuse("BAD_DELTA", "step delta must be +1 or -1, one bar per call (got " + JSON.stringify(cmd.delta) + ") - loop the call N times");
          }
          try {
            live.room.step(d);
          } catch (err) {
            if (err instanceof ReplayError) throw err;
          }
          const st = this.persist(uid, live, who, "step", { delta: d });
          this.broadcast(uid, { type: "status", session: uid, status: st, verb: "step", actor: who });
          return ok({ session: uid, status: st });
        }
        case "speed": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          const rate = Number(cmd.rate);
          if (!SPEEDS.includes(rate)) return refuse("BAD_RATE", "speed must be one of " + SPEEDS.join("/") + " bars-per-second (got " + JSON.stringify(cmd.rate) + ")");
          live.speed = rate;
          this.recordEvent(uid, who, "speed", { rate }, live.room.status());
          await this.maybeAlarm();
          return ok({ session: uid, speed: rate, status: live.room.status() });
        }
        case "date": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          const t = typeof cmd.date === "number" ? cmd.date : typeof cmd.date === "string" ? Date.parse(cmd.date) : NaN;
          if (!Number.isFinite(t)) return refuse("BAD_DATE", "date needs one target: an ISO-8601 string or epoch ms (got " + JSON.stringify(cmd.date) + ")");
          try {
            live.room.jump(t);
          } catch (err) {
            if (err instanceof ReplayError) throw err;
            throw new Refusal("REPLAY_FAILED: the date jump failed (" + (err instanceof Error ? err.message : String(err)) + ") - read state for the bar range and retry");
          }
          const st = this.persist(uid, live, who, "jump", { date: cmd.date });
          live.playing = false;
          this.broadcast(uid, { type: "status", session: uid, status: st, verb: "jump", actor: who });
          await this.maybeAlarm();
          return ok({ session: uid, status: st });
        }
        case "jump": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          const hasIdx = cmd.barIndex != null && String(cmd.barIndex) !== "";
          const hasMs = cmd.ms != null && String(cmd.ms) !== "";
          const hasTime = cmd.time != null && String(cmd.time) !== "";
          const hasBars = cmd.bars != null && String(cmd.bars) !== "";
          const n = (hasIdx ? 1 : 0) + (hasMs ? 1 : 0) + (hasTime ? 1 : 0) + (hasBars ? 1 : 0);
          if (n !== 1) return refuse("BAD_DELTA", "jump needs exactly one of {ms,time,barIndex,bars} - see control.mjs /jump");
          let arg;
          if (hasIdx) arg = { barIndex: Number(cmd.barIndex) };
          else if (hasMs) arg = { ms: Number(cmd.ms) };
          else if (hasTime) arg = { time: cmd.time };
          else arg = { bars: Number(cmd.bars) };
          try {
            live.room.jump(arg);
          } catch (err) {
            if (err instanceof ReplayError) throw err;
            throw new Refusal("REPLAY_FAILED: jump failed (" + (err instanceof Error ? err.message : String(err)) + ") - read state for the bar range and retry");
          }
          live.playing = false;
          const st = this.persist(uid, live, who, "jump", arg);
          this.broadcast(uid, { type: "status", session: uid, status: st, verb: "jump", actor: who });
          await this.maybeAlarm();
          return ok({ session: uid, status: st });
        }
        case "stop": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          live.room.pause();
          live.playing = false;
          const summary = live.room.summary({ outcome: cmd.outcome || "COMPLETE" });
          const st = this.persist(uid, live, who, "finish", { outcome: cmd.outcome || "COMPLETE" }, { status: "COMPLETED" });
          this.setStatus(uid, "COMPLETED");
          this.broadcast(uid, { type: "finished", session: uid, summary });
          this.rooms.delete(uid);
          return ok({ session: uid, summary, status: st });
        }
        case "place": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          if (!cmd.order || typeof cmd.order !== "object") return refuse("BAD_ORDER", "place needs an order object");
          const body = { ...cmd.order };
          // The fork's control surface records market tickets with marketFill:'now' (fill at
          // the last visible close); the library takes the same shape so a replay matches.
          if (String(body.type || "market").toLowerCase() === "market" && body.marketFill == null) body.marketFill = "now";
          let placed;
          try {
            placed = live.room.place(body);
          } catch (err) {
            if (err instanceof ReplayError) throw err;
            throw new Refusal("REPLAY_FAILED: the order was rejected (" + (err instanceof Error ? err.message : String(err)) + ") - fix the order fields and retry");
          }
          const st = this.persist(uid, live, who, "place", body);
          this.broadcast(uid, { type: "status", session: uid, status: st, verb: "place", actor: who });
          return ok({ session: uid, order: placed.order, status: st });
        }
        case "modify": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          if (cmd.id == null || String(cmd.id) === "") return refuse("ORDER_NOT_FOUND", "modify needs id (got " + JSON.stringify(cmd.id) + ")");
          try {
            live.room.modify(cmd.id, cmd);
          } catch (err) {
            if (err instanceof ReplayError) throw err;
            throw new Refusal("REPLAY_FAILED: modify failed (" + (err instanceof Error ? err.message : String(err)) + ") - read state and retry");
          }
          const st = this.persist(uid, live, who, "modify", cmd);
          this.broadcast(uid, { type: "status", session: uid, status: st, verb: "modify", actor: who });
          return ok({ session: uid, status: st });
        }
        case "close": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          try {
            live.room.closePartial(cmd.pct ?? 100, { positionId: cmd.positionId, reason: cmd.reason || "MANUAL", price: cmd.price });
          } catch (err) {
            if (err instanceof ReplayError) throw err;
            throw new Refusal("REPLAY_FAILED: the close was rejected (" + (err instanceof Error ? err.message : String(err)) + ") - read state and retry");
          }
          const st = this.persist(uid, live, who, "close", { pct: cmd.pct ?? 100, positionId: cmd.positionId ?? null });
          this.broadcast(uid, { type: "status", session: uid, status: st, verb: "close", actor: who });
          return ok({ session: uid, status: st });
        }
        case "cancel": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          try {
            live.room.cancel(cmd.id);
          } catch (err) {
            if (err instanceof ReplayError) throw err;
            throw new Refusal("REPLAY_FAILED: cancel failed (" + (err instanceof Error ? err.message : String(err)) + ") - read state and retry");
          }
          const st = this.persist(uid, live, who, "cancel", { id: cmd.id });
          this.broadcast(uid, { type: "status", session: uid, status: st, verb: "cancel", actor: who });
          return ok({ session: uid, status: st });
        }
        case "note": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = await this.ensureLive(uid);
          if (!live) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          try {
            live.room.note(cmd.text ?? "", { tradeId: cmd.tradeId ?? cmd.trade_id, tags: cmd.tags });
          } catch (err) {
            if (err instanceof ReplayError) throw err;
            throw new Refusal("REPLAY_FAILED: note failed (" + (err instanceof Error ? err.message : String(err)) + ") - read state and retry");
          }
          const st = this.persist(uid, live, who, "note", { text: cmd.text ?? "", tradeId: cmd.tradeId ?? cmd.trade_id, tags: cmd.tags });
          this.broadcast(uid, { type: "status", session: uid, status: st, verb: "note", actor: who });
          return ok({ session: uid, status: st });
        }
        case "list": {
          const rows = this.all("SELECT * FROM sessions ORDER BY created_at DESC LIMIT ?", Math.min(200, Number(cmd.limit || 50)));
          const sessions = rows.map((r) => {
            let st = null;
            const live = this.rooms.get(r.uid);
            let status_error = null;   // a live room whose status cannot be read is NAMED on its row, never a silent blank
            if (live) { try { st = live.room.status(); } catch (e) { status_error = "ROOM_STATUS_FAILED: " + String((e && e.message) || e); } }
            let symbols = [r.pair], symbols_error = null;
            if (r.symbols) { try { const j = JSON.parse(r.symbols); if (Array.isArray(j) && j.length) symbols = j; } catch (e) { symbols_error = "SYMBOLS_UNREADABLE: " + String((e && e.message) || e); } }
            let lg = null;
            if (live && st) lg = live.room.fills.length;
            if (lg == null) lg = r.fills;
            return {
              session_uid: r.uid, name: r.name, symbol: r.pair, timeframe: r.tf, status: r.status,
              start_date: r.start_date ?? null, end_date: r.end_date ?? null, cursor: r.cursor,
              strategy: r.strategy ?? null, description: r.session_notes || null, starting_balance: r.balance0 ?? null,
              visible_bars: r.visible_bars ?? (st ? st.visibleBars : null),
              total_trades: r.total_trades ?? (st ? st.stats.trades_total : null),
              win_rate: r.win_rate ?? (st && st.stats.winRate ? st.stats.winRate.estimate : null),
              profit_factor: r.profit_factor ?? (st && st.stats.profitFactor ? st.stats.profitFactor.value : null),
              balance: r.balance ?? (st ? st.balance : r.balance0),
              realized: r.realized ?? null,
              fills: lg ?? (st ? (st.recentFills.length ? st.recentFills[st.recentFills.length - 1].seq : 0) : 0),
              started_at: Number.isFinite(Number(r.created_at)) ? new Date(Number(r.created_at)).toISOString() : null,
              last_activity_at: Number.isFinite(Number(r.updated_at)) ? new Date(Number(r.updated_at)).toISOString() : null,
              agent_id: r.agent_id ?? null,
              ...(status_error ? { status_error } : {}), ...(symbols_error ? { symbols_error } : {}),
              symbols,
            };
          });
          return ok({ sessions });
        }
        case "open": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const h = await this.ensureLive(uid);
          if (!h) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          const st = h.room.status();
          this.recordEvent(uid, who, "resume", { replayed: 0, resumed: false }, st);
          this.broadcast(uid, { type: "status", session: uid, status: st, verb: "resume", actor: who });
          return ok({ session: uid, status: st, playing: h.playing, speed: h.speed, resumed: false, replayed: 0 });
        }
        case "export": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const h = await this.ensureLive(uid);
          if (!h) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid));
          const st = h.room.status();
          const trades = this.all("SELECT * FROM backtest_trades WHERE session_uid=? ORDER BY seq ASC", uid);
          const events = this.all("SELECT * FROM backtest_events WHERE session_uid=? ORDER BY seq ASC", uid);
          const summary = h.room.summary({ outcome: "COMPLETE" });
          return ok({ session: uid, trades, events, summary });
        }
        case "delete": {
          if (!isValidUid(uid)) return refuse("BAD_SESSION_ID", "bad session id " + JSON.stringify(uid));
          const live = this.rooms.get(uid);
          if (live) {
            live.room.pause();
            this.rooms.delete(uid);
          }
          // The tables always exist (ensureSchema ran at op entry): no guard, no
          // alternative — a missing row is a refusal, never a silent zero.
          const evDel = this.sql.exec("DELETE FROM backtest_events WHERE session_uid=?", uid);
          const trDel = this.sql.exec("DELETE FROM backtest_trades WHERE session_uid=?", uid);
          const had = this.one("SELECT 1 AS x FROM sessions WHERE uid=?", uid);
          if (!had) return refuse("SESSION_ABSENT", "no session " + JSON.stringify(uid) + " to delete");
          this.run("DELETE FROM sessions WHERE uid=?", uid);
          return ok({ session: uid, deleted: { session: 1, trades: trDel.rowsWritten, events: evDel.rowsWritten } });
        }
        default:
          return refuse("BAD_OP", "unknown library op " + JSON.stringify(op));
      }
    } catch (err) {
      if (err instanceof Refusal) return refuse(err.code, err.message);
      if (err instanceof ReplayError) return refuse(err.code, err.message);
      if (err instanceof Error && typeof err.code === "string" && err.code) return refuse(err.code, err.message);
      return refuse("LIBRARY_FAILED", err instanceof Error ? err.message : String(err));
    }
  }

  async fetch(request) {
    const roll = rolloverCheck(request, this.state);
    if (roll) return roll;
    const u = new URL(request.url);
    const asJson = (obj, status) => new Response(JSON.stringify(obj), { status: status || 200, headers: { "content-type": "application/json" } });
    if (u.pathname === "/stream-register" && request.method === "POST") {
      try {
        this.ensureSchema();
        const out = this.streamRegister(u.searchParams.get("session"));
        return asJson({ ok: true, result: out });
      } catch (err) {
        if (err instanceof Refusal) return asJson({ ok: false, refusal: { token: err.code, detail: err.message } }, err.code === "SESSION_ABSENT" || err.code === "BAD_SESSION_ID" ? 404 : 400);
        return asJson({ ok: false, refusal: { token: "LIBRARY_FAILED", detail: String(err) } });
      }
    }
    if (u.pathname === "/stream-pull" && request.method === "POST") {
      try {
        const out = this.streamPull(u.searchParams.get("session"), u.searchParams.get("token"));
        return asJson({ ok: true, result: out });
      } catch (err) {
        if (err instanceof Refusal) return asJson({ ok: false, refusal: { token: err.code, detail: err.message } }, 404);
        return asJson({ ok: false, refusal: { token: "LIBRARY_FAILED", detail: String(err) } }, 500);
      }
    }
    if (u.pathname === "/stream-unregister" && request.method === "POST") {
      try {
        const out = this.streamUnregister(u.searchParams.get("session"), u.searchParams.get("token"));
        return asJson({ ok: true, result: out });
      } catch (err) {
        if (err instanceof Refusal) return asJson({ ok: false, refusal: { token: err.code, detail: err.message } }, 400);
        return asJson({ ok: false, refusal: { token: "LIBRARY_FAILED", detail: String(err) } }, 500);
      }
    }
    if (request.method !== "POST") {
      return new Response(JSON.stringify(refuse("BAD_OP", "POST only")), { status: 405, headers: { "content-type": "application/json" } });
    }
    let cmd;
    try {
      cmd = await request.json();
    } catch {
      return new Response(JSON.stringify(refuse("BAD_OP", "body must be JSON")), { status: 400, headers: { "content-type": "application/json" } });
    }
    try {
      const out = await this.op(cmd);
      const notFound = !out.ok && out.refusal && (out.refusal.token === "SESSION_ABSENT" || out.refusal.token === "BAD_OP" || out.refusal.token === "BAD_SESSION_ID");
      return new Response(JSON.stringify(out), { status: notFound ? 404 : 200, headers: { "content-type": "application/json" } });
    } catch (err) {
      const out = err instanceof Refusal ? refuse(err.code, err.message) : refuse("LIBRARY_FAILED", err instanceof Error ? err.message : String(err));
      return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
    }
  }
}

export default BacktestLibrary;
export { summarize, canonSummary, CODES, SPEEDS };
