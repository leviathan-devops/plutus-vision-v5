# HOW PINEBOX CLOUD WAS BUILT — the end-to-end record, checkpoint by checkpoint

**What this document is:** the study guide for building a tool whose full runtime (an IDE, a chart, a script engine, a
replay/backtest room) runs **natively in a browser tab on whatever device opens it**, hosted by Cloudflare, driven by an
agent's CLI on a Linux box — with no container, no video stream, no loopback service. It records the order things were
built in, every checkpoint that froze a working state, the defects each stage hit (with their F-numbers in
`ship-docs/FAILURE_LOG.md`), and the rules that came out of them. It is written for the next build that has to do
something similar.

**Companion documents (read in this order):**

| # | Document | What it answers |
|---|---|---|
| 1 | `design/DESIGN_BLUEPRINT_PINEBOX_CLOUD_v1.md` (490 lines) | the design that was approved: placement, objects, verbs, refusals |
| 2 | `design/CLOUDFLARE_ARCHITECTURE_PINEBOX_CLOUD.md` (317 lines) | the system as built and measured: routes, objects, config, deploy, failure modes |
| 3 | **this file** | how it got from nothing to working, and what broke on the way |
| 4 | `ship-docs/FAILURE_LOG.md` F-237..F-309 | every defect, verbatim, with its proof |
| 5 | `reports/Pinebox_Cloud_Engineering_Report_v1.md` | the "any device" test round (Chrome on Linux, a browser in Cloudflare's datacenter) |
| 6 | `checkpoints/<token>/CHECKPOINT_MANIFEST.md` | the frozen state at each milestone, with its picture (`visual/runtime-state.png`) |

---

## 1. THE RESULT (what "working" means, measured)

```
 agent on Linux                       Cloudflare (one Worker, two Durable Object classes)        any browser
 ─────────────────                    ────────────────────────────────────────────────────        ─────────────
 pinebox spawn-cloud-mac  ──PUT /api/v1/i/<S>:<N>──►  PineboxInstance "<S>:<N>"  (live state, SQLite)
   (= up --mode cloud)                                                    ▲
 orca open-url <page URL> ───────────────────────────────────────────────┼──────────►  Orca tab on the Mac:
                                     Worker static assets ── pine.html + JS ──────────►  page loads, Pine IDE +
                                                                          │              Backtest room render
                                     /api/v1/i/<S>:<N>/socket?role=primary ◄──WS──────  the page agent attaches
 pinebox asset --symbol EURUSD ──POST /verb {verb,args}──► instance ──WS {type:verb}──►  page switches chart
                               ◄──────── {ok,result} ◄───── instance ◄──WS answer─────  (measured ~200 ms RT)
 pinebox backtest --op create ──► /room/* ──────────────► BacktestLibrary "library" (durable sessions, fills,
                                                           journal; bars from the TradingView store in assets)
 pinebox down ──DELETE──► instance closes sockets, deletes its storage; orca tab close
```

Measured at the end (2026-11-08):
- The page runs **in the viewing device's browser**: inside the Orca tab on the Mac it reports `Asia/Riyadh`, `MacIntel`,
  60 fps while the chart is dragged (checkpoint `cu-v2-pinebox-cloud-browser-operational-2026-11-08`, commit `53bea33`).
- The same URL opened in **plain Chrome on Linux** and in **a browser in Cloudflare's datacenter** rendered and was
  driven by verbs from the Linux box (Engineering Report v1 §3, §5).
- Agent verbs round-trip through Cloudflare in ~200-250 ms (F-259: two avoidable round trips removed; the budget of
  150 ms was below this topology's floor and was re-stated with its measurement).
- Three zero-input start verbs: `spawn-cloud-mac` (native on the Mac), `spawn-cloud-linux` (native in the Linux Orca
  window), `spawn-local` (the local weston Pinebox) — checkpoint `cu-v2-pinebox-fully-operational-runtime-verified-2026-11-07`.
- The backtest room: one session = a market + a date window + a strategy; any timeframe is a VIEW (15m/30m/1H/4H) of the
  same session; data = the exact TradingView series (TVC:DXY, FX:EURUSD, FX:GBPUSD, Feb 2025 → now) shipped as Worker
  assets; a Pine IDE indicator exports into the room's Indicators dialog and runs as a real Vela indicator.

---

## 2. THE DECISION THAT MADE IT WORK — placement (and how it was first got wrong)

The single most important decision: **where does the page render?** Orca offers two placements for a browser tab:

| Command | Where the page runs | What the viewer gets | Verdict |
|---|---|---|---|
| `orca tab create --url U --worktree id:$ORCA_WORKTREE_ID` | Chromium on the **Linux server** | an ack-paced JPEG screencast (measured **0.6 frames/s** on the operator's tab while the page itself ran 60 fps) | REJECTED (blueprint R0; F-278) |
| `orca open-url --url U --worktree id:$ORCA_WORKTREE_ID` | the **viewing device's** own browser | the real page, natively | THE DESIGN |

History of this decision, because it was lost once:
1. The blueprint (`DESIGN_BLUEPRINT_PINEBOX_CLOUD_v1.md` line 5 R0 + line 384 D1) chose `open-url` and rejected the
   streamed placement.
2. On 2026-11-06 `open-url` produced a 1×1 page that never mounted (`ORCA_PAGE_NOT_SHOWN`, three measurements). To get a
   visible tab, the CLI was switched to `tab create` on 11-07 — the rejected placement — without saying so. Every check
   (screenshots, judge, spines, blind runs) ran on the Linux machine and passed; none measured what reached the
   operator's screen. The operator caught it: "it literally feels like it moves at 1 fps" (F-278, AP-48).
3. Root cause of the 1×1 page, read from Orca's own source (`npx @electron/asar extract /opt/Orca/resources/app.asar`):
   the server may only place a page on a desktop after that desktop has **registered as a page host**, which it does
   only when it opens a browser tab itself (Cmd+Shift+B). Zero registrations were in the server's logs (F-279).
4. The fix had three parts: `up --mode cloud` uses **only** `open-url`; with no host registered it refuses
   `ORCA_DEVICE_HOST_ABSENT` and names the one step (press Cmd+Shift+B once on the Mac); a page that reports the
   server's time zone is refused `ORCA_PAGE_STREAMED` (the stream can never silently return).
5. Both Orca apps updated to 1.4.252 → tool-opened tabs appeared on the Mac by themselves (F-283), checkpoint
   `cu-v2-pinebox-cloud-mac-native-spawn-operational-2026-11-07` (`b536651`).
6. Later the operator wanted a native tab in the Linux window too: `--on linux` uses `tab create` and expects the
   Linux time zone — native THERE, and named as such (`Pinebox · Linux · S:N` tab titles), checkpoint
   `cu-v2-pinebox-multi-cloud-runtime-fully-operational-2026-11-07` (`c54015f`).

**Rule for the next build:** decide the placement first, write it down, and verify it ON THE VIEWING DEVICE (time zone,
platform, frame rate measured inside the page). A screenshot taken on the server proves nothing about the viewer.

---

## 3. THE BUILD, IN ORDER — with the checkpoint that froze each stage

### Stage 0 — the local tool worked first (baseline)
- Checkpoint `cu-v2-pinebox-final-2026-11-04` (`d320bf7`): a self-contained local Pinebox (weston display, Chromium,
  pv-server rail, Pine station, backtest room) with switching on both tabs. Everything in the cloud version is a port of
  this working local tool — the cloud build never invented a feature the local one did not already have.
- Lesson carried forward: **build the cloud version as a re-host of a working product, verb for verb** (`cloud-map.json`,
  26/26 verbs mapped).

### Stage 1 — the blueprint (`design/DESIGN_BLUEPRINT_PINEBOX_CLOUD_v1.md`)
- Decisions (verbatim in the blueprint): Worker static assets serve the page; **`PineboxInstance`** Durable Object = one
  per Pinebox instance, holds live state, relays agent verbs **by name** to the page over its WebSocket; **`BacktestLibrary`**
  Durable Object = exactly one (`library`), the durable backtest store (SQLite); **no container** (a container would only
  bring back streamed pixels); the CLI's `--mode cloud`; the refusal registry.
- Validator PASS (490 lines).

### Stage 2 — prove the transport before building on it (W3)
- A throwaway probe worker `pinebox-cloud-probe`: a DO echo socket, 30/30 round trips, p50 99 ms / p95 101 ms.
- Then the app worker `pinebox-cloud` at `https://pinebox-cloud.cryptoforex36963.workers.dev` (`/pine` 200; bars;
  cells; `FIXTURE_CELL_ABSENT` named). Prediction parity 24/24 (`tools/pred-parity.mjs`).

### Stage 3 — the objects and the page agent (W4)
- `pinebox-cloud/src/library.ts` (BacktestLibrary), `src/instance.ts` (PineboxInstance), `src/worker.ts` (router),
  `web/pinebox-page.js` (the page agent), `cloud-map.json` 26/26. `test/w4.mjs`: parity, durability, ambiguity, UTC.
- W6 gates added to `worker.ts`, each proven both ways: `AUTH_REQUIRED` 401 (agent bearer), `CAPABILITY_INVALID` 403
  (the page's `k` = the session name), `INSTANCE_ABSENT` 404.

### Stage 4 — the CLI relay (W5)
- `pinebox-cli/stages/cloud.sh`: `cloud_up` (PUT the instance, open the tab, wait for the page socket + IDE mount),
  `cloud_verb` (POST `/verb`), `cloud_down` (DELETE + tab close). `pinebox-cli/pinebox`: `pb_bind` sets `CLOUD_RELAY=1`
  from `state.json .mode == "cloud"`; a pre-dispatch `case` routes every verb to `cloud_relay`.
- Defects of this stage (all fixed): the registry's 90 s sweep deleted cloud claims lacking an `i<id>/state.env`
  marker; `cloud_up` refusals used `exit` and fired the cleanup trap; this host's `jq` silently output nothing for
  `--argjson` merges (all relay jq rebuilt on `fromjson` forms); a swallowed teardown (`|| true`) became
  `TEARDOWN_FAILED` by name.

### Stage 5 — THE FIRST LOOK: it had never worked in a browser (F-244..F-255)
Everything up to here was proven with curl and a node WebSocket client. The first time the page was opened in a real
browser tab and LOOKED at:
- every `/i/<inst>` asset 403'd and the page agent connected to the wrong instance (F-244);
- three disagreeing build-id sources refused the page socket (F-245) → one build id, stamped into `build.json`;
- `DELETE /api/v1/i/<inst>` never destroyed anything (F-246) → a real `/destroy`;
- the page silently used the HOST's loopback services (pv-server, station, rail) — it only "worked" because the Linux
  box was running them (F-247) → Pine runs in the page (pinets in a Web Worker), the backtest room and the VIL rail on
  Durable Objects, a loopback census of the dist = 0;
- the Web Worker had no message listener (F-248); `dist-web/tabs/pine-ide` was an absolute symlink into the local fork,
  so cloud edits changed the local tool (F-249);
- `cf()` read `$3` under `set -u`, so `down --mode cloud` could never succeed (F-250).
- Checkpoint `cu-v2-pinebox-cloud-orca-tab-final-2026-11-07` (`11f3c69`): the page as a tab, Pine in a Web Worker, room +
  rail on DOs, zero loopback.

**Rule:** a cloud page is not proven by an API test. Open it in a browser, take a screenshot, OPEN the screenshot, and
run a loopback census (`grep -rc "127\.0\.0\.1\|localhost" dist-web`) — a page that works only because the build machine
is running services is not a cloud page.

### Stage 6 — gates, blind runs and an independent re-verifier (F-256..F-277)
Fresh agents given only the operator manual ("blind runs"), 33 sealed row gates, and an independent verifier found what
the builder could not:
- cloud claims reaped by the computer-use core (F-256, F-258 — the marker written under the wrong root);
- **every cloud instance shared one editor/chart/room mirror** (F-260) → a per-instance `localStorage` namespace injected
  by the Worker before any module loads;
- a closing socket blocked the next page's primary forever (F-265);
- every worker redeploy left open tabs dead (F-270) → stale pages reload themselves; the instance stopped pinning the
  PUT-time build (F-272);
- **the cloud room's chart was drawn by local instance 0 through a loopback default** (F-273) — found by the
  re-verifier, invisible to the builder because instance 0 happened to be running;
- a deploy left the library DO on the previous code for minutes (F-276) → a code-version stamp on every object call and a
  `CODE_ROLLOVER` reset.
- Blind runs went 5 → 7 → 2 → 1 → 0 → 3 → 2 → 3 → 2 → 0 questions; every question was a manual fix or a product fix.

**Rule:** the builder's own tests share the builder's blind spots. Use agents with no context and only the manual, and a
verifier that re-runs everything on the frozen artifacts.

### Stage 7 — the device and the latency (F-278..F-282)
- F-278 (the stream) and F-279 (registration) as in §2 → checkpoint
  `cu-v2-pinebox-cloud-streamed-latency-diagnosed-device-placement-open-2026-11-08` (`d8c962e`), then
  `cu-v2-pinebox-cloud-browser-operational-2026-11-08` (`53bea33`): Asia/Riyadh, MacIntel, 60 fps.
- F-280: the backtest room replayed with zero history (a few candles floating) → the default start is the middle of the
  data.
- F-282: a page that vanished (a closed remote browser) locked its instance forever → liveness takeover: ping the old
  primary; no pong in 2 s → close it (4408) and accept the new page.
- "Any device" test: plain Chrome on Linux and a browser in Cloudflare's datacenter both rendered and were driven.

### Stage 8 — one command per placement (zero-input verbs)
- `spawn-cloud-mac`, `spawn-cloud-linux`, `spawn-local` — each a fixed preset of `up`, no flags needed, overrides
  refused. A flag-order bug in the relay serializer was found on the way (the agent tool passes the session as
  `CU_SESSION_ID`, which dropped the first flag).
- Checkpoint `cu-v2-pinebox-fully-operational-runtime-verified-2026-11-07` (`20bbdfd`). F-287: every backtest session
  spawned with zone lines drawn — the drawing code was deleted.

### Stage 9 — the backtest room becomes a real backtesting tool
- Checkpoint `cu-v2-pinebox-backtest-fixes-t1-t4-2026-11-07` (`e732318`): clean panel defaults; session delete;
  the left column; **the TradingView bar store** (exact TVC:DXY / FX:EURUSD / FX:GBPUSD × 15m/30m/1H/4H, Feb 2025 →
  the last fetch, harvested by `tools/harvest-tv.mjs` from the same TradingView-API library the Plutus dashboard uses,
  shipped as Worker assets and served by both rails); FETCH LATEST DATA. Defects: stale UI after deploys (three stacked
  layers, F-290), a delete that never deleted (F-291), store reads that silently missed (minutes vs `1H`, F-292).
- Checkpoint `cu-v2-pinebox-all-seven-fixes-2026-11-07` (`2faabc7`): one session, any timeframe (a `/view` op);
  EXPORT TO BACKTEST — a Pine IDE script lands in the room's Indicators dialog and runs as a real Vela indicator
  (the dashboard's engine contract: `/prepare` + `/model`; in the cloud the model is computed in the page's Web Worker).
  Defects: the indicator manifest never settled because a function was called into a Promise (F-294); the cloud IDE
  module overwritten by the fork's copy (F-296).

### Stage 10 — timeframe views, the create form, store-only sessions (F-297..F-308)
- A timeframe pick never settled: a pre-`/view` snap-back re-issued the session's timeframe on every change (F-297),
  and the room's own delayed re-issue overrode a second pick (F-299). Now: cloud picks 137-222 ms, local 25-41 ms.
- 15m/30m views drew 1H candles under a 15m label (F-298) — found only by measuring the step between the bars the chart
  was fed. A finer view now reads the store's own series cut at the replay clock (no lookahead).
- `pinebox tf` acts on the visible tab (F-300); the create form carries the TradeZella fields (name, description,
  strategy, symbols, start/end date, start balance) and no data type (F-301); create and resume read only the store
  (`BARS_STORE_ABSENT`, `SESSION_SERIES_MISMATCH`, F-307); page refusals follow the CLI convention (F-308).
- 2026-11-08: a symbol switch with no running session for that symbol died `api is not a function` — a hoisted
  `var api` shadowed the room's `api()` (fixed `c0fd58f` lineage; see F-309 for what remains open on that path).
- Before packaging, every backtest session was deleted through each room's own `/delete` op (cloud library 60/60,
  local stores room-1..room-8), so the package and the live tool start clean.

---

## 4. THE REPLICATION RECIPE (for a similar build)

1. **Have a working local tool first.** Map every verb (`cloud-map.json` style). The cloud build is a re-host.
2. **Decide the placement and write the measurement that proves it** (time zone + platform + fps inside the page, on
   the viewing device). Reject any placement that streams pixels.
3. **Prove the transport with a throwaway worker** (DO WebSocket echo, p50/p95) before building objects.
4. **One Worker, static assets for the page, one Durable Object per live instance, one durable store object.** Relay
   agent verbs BY NAME over the page's socket; the page agent executes them in the page and answers.
5. **Everything the page needs comes from the Worker's origin.** Run a loopback census on the dist; build bundles with
   no loopback defaults; data the tool needs (bars) ships as assets.
6. **One build id, one code version.** Stamp the assets (cache-busting `?v=`), stamp every object call, let stale pages
   reload themselves, reset an object that runs old code.
7. **Per-instance isolation in the browser** (a storage namespace injected before any module loads).
8. **Every missing dependency is a named refusal** — never a substitute (`AUTH_REQUIRED`, `INSTANCE_ABSENT`,
   `ORCA_DEVICE_HOST_ABSENT`, `ORCA_PAGE_STREAMED`, `BARS_STORE_ABSENT`, `PINE_ENGINE_UNAVAILABLE`, ...). Prove each with
   two runs: dependency removed → token + nonzero exit; present → no token.
9. **Verify by looking, on the real device**, with blind agents and an independent re-verifier, and measure the thing
   itself (a pick timed until the chart shows it; the bar step; a cold reload) rather than a proxy.
10. **Freeze each working state as a checkpoint** with its picture, and keep the failure log append-only.

Deploy (the exact commands, from the repo root `PINEBOX/`):
```bash
bash pinebox-cloud/tools/build-web.sh                       # dist-web: stamped assets, build.json, bar store
source ~/.config/pinebox/cf.env                              # the Cloudflare token (mode 600, never in code or chat)
CLOUDFLARE_ACCOUNT_ID=<account> CLOUDFLARE_API_TOKEN="$CLOUDFLARE_API_TOKEN" \
  <wrangler> deploy --config pinebox-cloud/wrangler.jsonc   # main src/worker.ts, assets ./dist-web
curl -s https://pinebox-cloud.cryptoforex36963.workers.dev/build.json   # served build == pinebox-cloud/dist-web/build.json
./deploy.sh push --adopt-live && ./deploy.sh status          # the CLI side; status must read IDENTICAL
```

---

## 5. OPEN AT PACKAGING TIME (2026-11-08)

| Item | State |
|---|---|
| F-309: a symbol switch that creates a new session starts it at the old 3-week fixture's first bar (22 Jun 2026) instead of the current replay moment; `startAtSameMoment` and the symbol lookup still read the fixture cell list (pair `GBP/USD`) | OPEN — operator froze code changes for packaging |
| F-284 / F-288: Orca 1.4.252 changed `screenshot --json` and `orca mouse`; helper scripts still use the old forms | OPEN |
| F-285: "could not create a managed browser tab" on the Mac's first tab after a restart (Orca-side) | OPEN |
| F-286: a Mac-placed tab shows on the Linux window only as a label (Orca has no reverse stream) | by Orca's design; `--on linux` is the answer |
| F-289: `chart --op pan` on a cloud tab moves only the left edge | OPEN |
| Regression suite (58-row sweep, crash ×3, 33 gates) not re-run after F-297..F-308 | NOT RUN |
| Agent verb latency ~200-250 ms (two network legs) | measured, by topology (F-259) |
