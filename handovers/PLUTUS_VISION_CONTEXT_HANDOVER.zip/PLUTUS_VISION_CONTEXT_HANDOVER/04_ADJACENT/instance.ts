
import { rolloverCheck } from "./code-stamp.ts";// src/instance.ts — PineboxInstance: live state (SQLite), ONE primary WebSocket
// + any viewers (hibernation API, serializeAttachment {role, attachedAt}), verb
// relay BY NAME to the primary page (never JavaScript text), build id
// check (BUILD_MISMATCH on attach). The BacktestLibrary is a different object
// (RoomSurface owns it); this instance never routes backtest server-side.
//
// NO-SUBSTITUTE LAW: every missing substrate throws `new Refusal("<COMPONENT>_UNAVAILABLE: ...")`;
// every failed relay returns a NAMED refusal result. No catch swallows an outcome.
// The relay carries verb NAMES only. A verb the page lacks = VERB_UNMAPPED.

class Refusal extends Error {
  constructor(message) {
    super(message);
    this.name = "Refusal";
    const i = message.indexOf(":");
    this.code = i > 0 ? message.slice(0, i).trim() : "REFUSAL";
  }
}

const refuse = (code, detail) => ({ ok: false, refusal: { token: code, detail: String(detail ?? "") } });
const answered = (rid, ok, result, refusal) => {
  const out = { rid, ok };
  if (ok) out.result = result ?? null;
  else out.refusal = refusal;
  return out;
};

function rid() {
  return "r" + Date.now().toString(36) + Math.floor(Math.random() * 0xffffff).toString(16).padStart(6, "0");
}

function isValidName(name) {
  return typeof name === "string" && /^[A-Za-z0-9_.:-]{1,128}$/.test(name);
}

const SCHEMA_INSTANCE = `CREATE TABLE IF NOT EXISTS instance (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at INTEGER NOT NULL
)`;
const SCHEMA_EVENTS = `CREATE TABLE IF NOT EXISTS events (
  id     INTEGER PRIMARY KEY AUTOINCREMENT,
  rid    TEXT NOT NULL,
  verb   TEXT NOT NULL,
  ok     INTEGER NOT NULL,
  token  TEXT,
  ms     INTEGER NOT NULL,
  at     INTEGER NOT NULL
)`;

const READONLY_VERBS = new Set(["status"]);
// Verbs the page owns (relayed BY NAME; a verb the page lacks is refused
// VERB_NOT_PAGE there). asset/tf/week/tab are page verbs: the page drives the
// page's own market + week control + PVActivate + the BACKTEST pane's room,
// and the DO records the value ONLY after the page confirms it.
const PAGE_RELAY_VERBS = { load: true, run: true, insert: true, editor: true, asset: true, tf: true, week: true, tab: true, chart: true, widget: true, backtest: true, shot: true, look: true, verify: true, drive: true };

export class PineboxInstance {
  constructor(state, env) {
    this.state = state;
    this.env = env;
    if (!state || !state.storage || !state.storage.sql) {
      throw new Refusal("STORE_UNAVAILABLE: Durable Object SQLite storage is missing - redeploy with the v2 migration (new_sqlite_classes) applied and retry");
    }
    this.sql = state.storage.sql;
    this.socketsByRole = new Map();
    this.pending = new Map();
  }

  ensureSchema() {
    try {
      this.sql.exec(SCHEMA_INSTANCE);
      this.sql.exec(SCHEMA_EVENTS);
      this.sql.exec("CREATE INDEX IF NOT EXISTS idx_instance_events_verb ON events(verb, at)");
    } catch (err) {
      if (err instanceof Error && /SQLITE_FULL/i.test(err.message)) {
        throw new Refusal("STORE_FULL: the instance object reached its SQLite limit - down the instance and up again");
      }
      throw new Refusal("STORE_UNAVAILABLE: schema setup failed (" + (err instanceof Error ? err.message : String(err)) + ") - redeploy with the v2 migration applied and retry");
    }
  }

  one(q, ...params) {
    try {
      return this.sql.exec(q, ...params).toArray()[0] ?? null;
    } catch (err) {
      if (err instanceof Error && /SQLITE_FULL/i.test(err.message)) {
        throw new Refusal("STORE_FULL: the instance object reached its SQLite limit - down the instance and up again");
      }
      throw new Refusal("STORE_UNAVAILABLE: a live-state read failed (" + (err instanceof Error ? err.message : String(err)) + ") - retry");
    }
  }

  run(q, ...params) {
    try {
      this.sql.exec(q, ...params);
    } catch (err) {
      if (err instanceof Error && /SQLITE_FULL/i.test(err.message)) {
        throw new Refusal("STORE_FULL: the instance object reached its SQLite limit - down the instance and up again");
      }
      throw new Refusal("STORE_UNAVAILABLE: a live-state write failed (" + (err instanceof Error ? err.message : String(err)) + ") - retry");
    }
  }

  getKey(k) {
    const r = this.one("SELECT value FROM instance WHERE key=?", k);
    return r ? r.value : null;
  }

  setKey(k, v) {
    this.run("INSERT OR REPLACE INTO instance (key, value, updated_at) VALUES (?,?,?)", k, String(v), Date.now());
  }

  delKey(k) {
    this.run("DELETE FROM instance WHERE key=?", k);
  }

  record(ridV, verb, wasOk, token, ms) {
    try {
      this.sql.exec("INSERT INTO events (rid, verb, ok, token, ms, at) VALUES (?,?,?,?,?,?)", ridV, verb, wasOk ? 1 : 0, token ?? null, ms, Date.now());
    } catch {
      throw new Refusal("STORE_UNAVAILABLE: the relay receipt could not be recorded - retry the verb");
    }
  }

  sockets() {
    try {
      return this.state.getWebSockets();
    } catch (err) {
      throw new Refusal("SOCKET_STORE_UNAVAILABLE: hibernation socket list failed (" + (err instanceof Error ? err.message : String(err)) + ") - redeploy with the v2 migration applied and retry");
    }
  }

  primarySocket() {
    const all = this.sockets();
    for (const ws of all) {
      try {
        const tag = ws.deserializeAttachment();
        // only an OPEN socket is the primary: a socket whose close is in flight (the tab just closed, the
        // object was destroyed) stays in the hibernation list and must not refuse the next page
        if (tag && tag.role === "primary" && ws.readyState === 1) return ws;
      } catch {
        throw new Refusal("SOCKET_STORE_UNAVAILABLE: a socket attachment could not be read - reload the page and retry");
      }
    }
    return null;
  }

  // THE served build: the worker passes the content hash of what the current deploy serves on every call.
  servedBuild(u) {
    const b = u.searchParams.get("served");
    if (!b) throw new Refusal("BUILD_UNAVAILABLE: the call carries no served build - the worker passes it on every instance call; redeploy the worker");
    return b;
  }


  // ping the current primary page; true when it answers {type:"pong", pid} within ms
  primaryAnswers(ms) {
    const ws = this.primarySocket();
    if (!ws) return Promise.resolve(false);
    const pid = "ping-" + crypto.randomUUID();
    return new Promise((resolve) => {
      const timer = setTimeout(() => { this.pending.delete(pid); resolve(false); }, ms);
      this.pending.set(pid, () => { clearTimeout(timer); this.pending.delete(pid); resolve(true); });
      try { ws.send(JSON.stringify({ type: "ping", pid })); } catch { clearTimeout(timer); this.pending.delete(pid); resolve(false); }
    });
  }

  hasPrimary() {
    return this.primarySocket() !== null;
  }

  stateFrame() {
    return {
      build: this.getKey("build"),
      instance: {
        pair: this.getKey("pair") || "DXY",
        tf: this.getKey("tf") || "1H",
        week: this.getKey("week") || "2026-07-06",
        tab: this.getKey("tab") || "pine",
        scriptSha: this.getKey("script_sha") || undefined,
      },
      room: this.getKey("library_uid") ? { uid: this.getKey("library_uid"), cursor: 0, total: 0, playing: false } : undefined,
    };
  }

  broadcast(frame) {
    const msg = JSON.stringify(frame);
    for (const ws of this.sockets()) {
      try { ws.send(msg); } catch { /* a closed viewer never blocks the broadcast */ }
    }
  }

  async indicatorsRoute(request) {
    const method = request.method;
    if (method === "GET") return Response.json({ ok: true, indicators: this.getKey("indicators") ? JSON.parse(this.getKey("indicators")) : [] });
    const body = await request.json().catch(() => ({}));
    let list = this.getKey("indicators") ? JSON.parse(this.getKey("indicators")) : [];
    if (method === "DELETE") { list = list.filter((x) => x.name !== body.name); this.setKey("indicators", JSON.stringify(list)); return Response.json({ ok: true, indicators: list }); }
    if (method !== "PUT") return Response.json({ ok: false, code: "METHOD", error: "GET list, PUT upsert {name,script}, DELETE {name}" }, { status: 405 });
    const name = String(body.name || "").trim(), script = String(body.script || "");
    if (!name) return Response.json({ ok: false, code: "BAD_INDICATOR", error: "name is required" }, { status: 400 });
    if (!script) return Response.json({ ok: false, code: "BAD_INDICATOR", error: "script is required" }, { status: 400 });
    const entry = { name, script, language: "pine", category: "My Scripts", exportedAt: new Date().toISOString() };
    const at = list.findIndex((x) => x.name === name);
    if (at >= 0) list[at] = entry; else list.push(entry);
    this.setKey("indicators", JSON.stringify(list));
    return Response.json({ ok: true, indicators: list });
  }

  async fetch(request) {
    const roll = rolloverCheck(request, this.state);
    if (roll) return roll;
    const u = new URL(request.url);
    this.ensureSchema();
    if (u.pathname === "/exists") {
      const stored = this.getKey("build");
      return new Response(JSON.stringify({ exists: stored != null }), { headers: { "content-type": "application/json" } });
    }
    // every routed call except the create/attach (PUT) and destroy needs a LIVE instance (one PUT stamped its build)
    if (!u.pathname.endsWith("/attach") && !u.pathname.endsWith("/open") && !u.pathname.endsWith("/destroy") && !u.pathname.endsWith("/exists") && this.getKey("build") == null) {
      const nm = u.searchParams.get("inst") || "this instance";
      return new Response(JSON.stringify({ ok: false, refusal: { token: "INSTANCE_ABSENT", detail: "no instance object " + nm + " - run: pinebox up --mode cloud (it PUTs the instance)" } }), { status: 404, headers: { "content-type": "application/json" } });
    }
    if (u.pathname.endsWith("/socket")) {
      return this.onSocket(request, u);
    }
    if (u.pathname.endsWith("/verb") && request.method === "POST") {
      return this.onVerb(request, u);
    }
    if (u.pathname.endsWith("/indicators") || u.pathname.includes("/indicators/")) return this.indicatorsRoute(request);
    if (u.pathname.endsWith("/state") && request.method === "GET") {
      return this.onState();
    }
    if (u.pathname.endsWith("/exists")) {
      const stored = this.state.storage.get("build");
      return new Response(JSON.stringify({ exists: stored != null }), { headers: { "content-type": "application/json" } });
    }
    if (u.pathname.endsWith("/rail-store") && request.method === "POST") {
      return this.onRailStore(request);
    }
    if (u.pathname.endsWith("/destroy") && request.method === "POST") {
      return this.onDestroy();
    }
    if ((u.pathname.endsWith("/attach") || u.pathname.endsWith("/open")) && request.method === "POST") {
      return this.onAttach(request);
    }
    return new Response(JSON.stringify(refuse("BAD_OP", "unknown instance path " + u.pathname)), { status: 404, headers: { "content-type": "application/json" } });
  }

  // THE RAIL STORE: the page-called VIL rail (same-origin, cookie-gated at the worker) keeps
  // its ledger rows + captures in THIS object's SQLite. Ops: vil-rows {week} -> {rows[]},
  // vil-row-append {row} -> {stored row, bytes, count}, vil-capture {name, sha256, bytes,
  // pngBase64} -> {stored}. Tables are created here (the store's own schema); a row that
  // fails validation is refused by name, never written. Large PNG base64 is kept in a
  // separate captures table; vil_rows carries the ledger fields the page reads.
  async onRailStore(request) {
    let body;
    try { body = await request.json(); }
    catch { return new Response(JSON.stringify(refuse("BAD_OP", "the rail-store body must be JSON")), { status: 400, headers: { "content-type": "application/json" } }); }
    const op = body && body.store;
    if (op !== "vil-rows" && op !== "vil-row-append" && op !== "vil-capture") {
      return new Response(JSON.stringify(refuse("BAD_OP", "rail-store needs store vil-rows|vil-row-append|vil-capture (got " + JSON.stringify(op) + ")")), { status: 400, headers: { "content-type": "application/json" } });
    }
    try {
      this.sql.exec(`CREATE TABLE IF NOT EXISTS vil_rows (
        id INTEGER PRIMARY KEY AUTOINCREMENT, week TEXT NOT NULL, body TEXT NOT NULL,
        created_at INTEGER NOT NULL)`);
      this.sql.exec(`CREATE INDEX IF NOT EXISTS idx_vil_rows_week ON vil_rows(week, id)`);
      this.sql.exec(`CREATE TABLE IF NOT EXISTS vil_captures (
        name TEXT PRIMARY KEY, sha256 TEXT NOT NULL, bytes INTEGER NOT NULL,
        png_base64 TEXT NOT NULL, created_at INTEGER NOT NULL)`);
    } catch (err) {
      const r = err instanceof Refusal ? refuse(err.code, err.message) : refuse("STORE_UNAVAILABLE", String(err));
      return new Response(JSON.stringify(r), { headers: { "content-type": "application/json" } });
    }
    try {
      if (op === "vil-rows") {
        const week = String((body && body.week) || "");
        const rows = this.sql.exec("SELECT body FROM vil_rows WHERE week=? ORDER BY id ASC", week).toArray()
          .map((r) => { try { return JSON.parse(r.body); } catch { return { _unparsed: String(r.body).slice(0, 200) }; } });
        return new Response(JSON.stringify({ ok: true, result: { rows } }), { headers: { "content-type": "application/json" } });
      }
      if (op === "vil-row-append") {
        const row = (body && body.row) || {};
        const line = JSON.stringify(row);
        this.sql.exec("INSERT INTO vil_rows (week, body, created_at) VALUES (?,?,?)", String(row.week || ""), line, Date.now());
        const count = this.sql.exec("SELECT COUNT(*) c FROM vil_rows WHERE week=?", String(row.week || "")).toArray()[0].c;
        return new Response(JSON.stringify({ ok: true, result: { row, bytes: new TextEncoder().encode(line).length, count } }), { headers: { "content-type": "application/json" } });
      }
      const name = String((body && body.name) || "");
      const sha256 = String((body && body.sha256) || "");
      const bytes = Number((body && body.bytes) || 0);
      const pngBase64 = String((body && body.pngBase64) || "");
      if (!name || !/^[0-9a-f]{64}$/.test(sha256) || !(bytes > 0) || !pngBase64) {
        return new Response(JSON.stringify(refuse("VIL_CAPTURE_EMPTY", "vil-capture needs {name, sha256, bytes, pngBase64}")), { status: 400, headers: { "content-type": "application/json" } });
      }
      this.sql.exec("INSERT OR REPLACE INTO vil_captures (name, sha256, bytes, png_base64, created_at) VALUES (?,?,?,?,?)", name, sha256, bytes, pngBase64, Date.now());
      return new Response(JSON.stringify({ ok: true, result: { stored: name } }), { headers: { "content-type": "application/json" } });
    } catch (err) {
      const r = err instanceof Refusal ? refuse(err.code, err.message) : refuse("STORE_UNAVAILABLE", String(err));
      return new Response(JSON.stringify(r), { headers: { "content-type": "application/json" } });
    }
  }

  async onSocket(request, u) {
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response(JSON.stringify(refuse("BAD_OP", "socket path needs a WebSocket upgrade")) , { status: 426, headers: { "content-type": "application/json" } });
    }
    const role = (u.searchParams.get("role") || "viewer").toLowerCase();
    const clientBuild = u.searchParams.get("build");
    const wantBuild = this.servedBuild(u);
    if (clientBuild !== wantBuild) {
      return new Response(JSON.stringify(refuse("BUILD_MISMATCH", "the page build " + clientBuild + " differs from the object build " + wantBuild + " - reload the tab from the URL up printed")), { status: 409, headers: { "content-type": "application/json" } });
    }
    if (role !== "primary" && role !== "viewer") {
      return new Response(JSON.stringify(refuse("BAD_OP", "role must be primary|viewer (got " + JSON.stringify(role) + ")")) , { status: 400, headers: { "content-type": "application/json" } });
    }
    if (role === "primary" && this.hasPrimary()) {
      // a device that vanished (a closed browser, a sleeping laptop, a remote renderer that exited) leaves its socket
      // OPEN here until TCP notices: ASK it. A live page answers a ping within 2 s and keeps the instance (409); a
      // silent one is closed 4408 PAGE_UNRESPONSIVE_REPLACED and the new page takes the instance.
      if (await this.primaryAnswers(2000)) {
        return new Response(JSON.stringify(refuse("PAGE_ALREADY_ATTACHED", "a live primary page is already attached (it answered a ping) - close the other primary tab, or attach as viewer")), { status: 409, headers: { "content-type": "application/json" } });
      }
      const stale = this.primarySocket();
      try { stale.close(4408, "PAGE_UNRESPONSIVE_REPLACED"); } catch (err) {
        throw new Refusal("SOCKET_CLOSE_FAILED: the silent primary socket could not be closed (" + (err instanceof Error ? err.message : String(err)) + ") - retry");
      }
    }
    const pair = new WebSocketPair();
    const label = u.searchParams.get("label") || "";
    let server = pair[1];
    try {
      this.state.acceptWebSocket(server, [role]);
    } catch (err) {
      throw new Refusal("SOCKET_STORE_UNAVAILABLE: the socket could not be accepted (" + (err instanceof Error ? err.message : String(err)) + ") - reload the page and retry");
    }
    try {
      server.serializeAttachment({ role, build: clientBuild, attachedAt: Date.now(), label: String(label).slice(0, 64) });
    } catch (err) {
      throw new Refusal("SOCKET_STORE_UNAVAILABLE: the socket role could not be stored (" + (err instanceof Error ? err.message : String(err)) + ") - reload the page and retry");
    }
    server.send(JSON.stringify({ type: "state", ...this.stateFrame() }));
    return new Response(null, { status: 101, webSocket: pair[0] });
  }

  async onVerb(request, u) {
    let body;
    try {
      body = await request.json();
    } catch {
      return new Response(JSON.stringify(refuse("BAD_OP", "the verb body must be JSON")) , { status: 400, headers: { "content-type": "application/json" } });
    }
    const { rid: clientRid, verb, args, deadlineMs } = body || {};
    if (typeof verb !== "string" || verb.length === 0) {
      return new Response(JSON.stringify(refuse("BAD_OP", "the verb body needs {rid, verb, args}")) , { status: 400, headers: { "content-type": "application/json" } });
    }
    const id = typeof clientRid === "string" && clientRid.length > 0 ? clientRid : rid();
    const t0 = Date.now();
    const keyVerb = String(verb);
    // Local instance verbs answered without a page.
    if (keyVerb === "status") {
      const ms = Date.now() - t0;
      const rows = this.sql.exec("SELECT verb, COUNT(*) c, AVG(ms) p FROM events GROUP BY verb").toArray();
      const roles = {};
      for (const ws of this.sockets()) {
        try {
          const tag = ws.deserializeAttachment();
          if (tag && tag.role && ws.readyState === 1) roles[tag.role] = (roles[tag.role] || 0) + 1;   // OPEN sockets only
        } catch {
          throw new Refusal("SOCKET_STORE_UNAVAILABLE: a socket attachment could not be read - reload the page and retry");
        }
      }
      this.record(id, "status", true, null, ms);
      return new Response(JSON.stringify(answered(id, true, { mode: "cloud", verbs: rows, roles, library_uid: this.getKey("library_uid") })), { headers: { "content-type": "application/json" } });
    }
    if (keyVerb === "state") {
      const ms = Date.now() - t0;
      const k = args && args.get ? String(args.get) : args && args.put ? String(args.put) : null;
      if (!k) {
        const out = answered(id, false, null, { token: "STATE_KEY_INVALID", detail: "state needs get|put + a user. key" });
        this.record(id, "state", false, "STATE_KEY_INVALID", ms);
        return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
      }
      if (!k.startsWith("user.")) {
        const out = answered(id, false, null, { token: "STATE_KEY_INVALID", detail: "state keys must start with user. (got " + JSON.stringify(k) + ")" });
        this.record(id, "state", false, "STATE_KEY_INVALID", ms);
        return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
      }
      if (args && args.put) {
        try { this.setKey(k, String(args.value ?? "")); } catch (err) {
          const r = err instanceof Refusal ? refuse(err.code, err.message) : refuse("STORE_UNAVAILABLE", String(err));
          return new Response(JSON.stringify(answered(id, false, null, r.refusal)), { headers: { "content-type": "application/json" } });
        }
        this.record(id, "state", true, null, Date.now() - t0);
        return new Response(JSON.stringify(answered(id, true, { key: k, value: String(args.value ?? "") })), { headers: { "content-type": "application/json" } });
      }
      const out = answered(id, true, { key: k, value: this.getKey(k) });
      this.record(id, "state", true, null, Date.now() - t0);
      return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
    }
    if (keyVerb === "ports" || keyVerb === "list" || keyVerb === "spawn" || keyVerb === "terminal") {
      const ms = Date.now() - t0;
      if (keyVerb === "spawn" || keyVerb === "terminal") {
        const out = answered(id, false, null, { token: "NO_DISPLAY", detail: "spawn/terminal need a Linux display - use the local mode for this instance" });
        this.record(id, keyVerb, false, "NO_DISPLAY", ms);
        return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
      }
      const out = answered(id, true, { mode: "cloud", note: "no ports exist; the instance URL is the address" });
      this.record(id, keyVerb, true, null, ms);
      return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
    }
    // Page verbs relay BY NAME to the primary page. asset/tf/week/tab join
    // them: the page drives its own market + week control + PVActivate + the
    // BACKTEST pane's room; the DO records the view-state keys ONLY after the
    // page confirms the same value (page-then-record: a read-back that
    // disagrees is a mechanism failure, never silently stored).
    if (PAGE_RELAY_VERBS[keyVerb]) {
      const primary = this.primarySocket();
      if (!primary) {
        const out = answered(id, false, null, { token: "PAGE_ABSENT", detail: "no primary page is attached - view (reopen the URL up printed), then retry" });
        this.record(id, keyVerb, false, "PAGE_ABSENT", Date.now() - t0);
        return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
      }
      // a page running an OLDER build than the one this deploy serves never answers a verb: it is told to load
      // the new build (it reloads and re-attaches) and the verb is refused by name - the caller retries
      const served = this.servedBuild(u);
      let pageBuild = null;
      try { pageBuild = (primary.deserializeAttachment() || {}).build || null; } catch {
        throw new Refusal("SOCKET_STORE_UNAVAILABLE: the primary socket's attachment could not be read - reload the page and retry");
      }
      if (pageBuild !== served) {
        try { primary.send(JSON.stringify({ type: "reload", build: served })); primary.close(4409, "PAGE_STALE"); } catch (err) {
          throw new Refusal("PAGE_STALE: the page runs build " + pageBuild + " (served: " + served + ") and could not be told to reload (" + (err instanceof Error ? err.message : String(err)) + ") - reload the tab");
        }
        const out = answered(id, false, null, { token: "PAGE_STALE", detail: "the tab ran build " + pageBuild + "; it is loading the served build " + served + " - retry in a few seconds" });
        this.record(id, keyVerb, false, "PAGE_STALE", Date.now() - t0);
        return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
      }
      const deadline = Math.max(500, Math.min(60000, Number(deadlineMs) || 25000));
      const req = { rid: id, verb: keyVerb, args: args || {}, deadlineMs: deadline };
      const pageResult = await new Promise((resolve) => {
        let done = false;
        const finish = (payload) => {
          if (done) return;
          done = true;
          this.pending.delete(id);
          resolve(payload);
        };
        this.pending.set(id, finish);
        try {
          primary.send(JSON.stringify({ type: "verb", ...req }));
        } catch {
          finish(answered(id, false, null, { token: "PAGE_ABSENT", detail: "the primary socket could not be written - view then retry" }));
          return;
        }
        setTimeout(() => {
          finish(answered(id, false, null, { token: "VERB_TIMEOUT", detail: "the primary page did not answer within " + deadline + "ms - status shows the last event; view then retry" }));
        }, deadline);
      });
      const ms = Date.now() - t0;
      if (!pageResult.ok) {
        this.record(id, keyVerb, false, (pageResult.refusal && pageResult.refusal.token) || "VERB_FAILED", ms);
        return new Response(JSON.stringify(pageResult), { headers: { "content-type": "application/json" } });
      }
      const res = pageResult.result || {};
      if (keyVerb === "asset" || keyVerb === "tf") {
        const want = keyVerb === "asset" ? "symbol" : "timeframe";
        const col = keyVerb === "asset" ? "pair" : "tf";
        const got = res[want] != null ? String(res[want]) : null;
        if (got == null) {
          const out = answered(id, false, null, { token: "VERB_FAILED", detail: "the page answered " + keyVerb + " without a read-back field '" + want + "' - nothing was recorded" });
          this.record(id, keyVerb, false, "VERB_FAILED", ms);
          return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
        }
        try { this.setKey(col, got); } catch (err) {
          const r = err instanceof Refusal ? refuse(err.code, err.message) : refuse("STORE_UNAVAILABLE", String(err));
          return new Response(JSON.stringify(answered(id, false, null, r.refusal)), { headers: { "content-type": "application/json" } });
        }
        this.broadcast({ type: "state", ...this.stateFrame() });
        const out = answered(id, true, res);
        this.record(id, keyVerb, true, null, Date.now() - t0);
        return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
      }
      if (keyVerb === "week") {
        if (res.week == null) {
          const out = answered(id, false, null, { token: "VERB_FAILED", detail: "the page answered week without a read-back field 'week' - nothing was recorded" });
          this.record(id, keyVerb, false, "VERB_FAILED", ms);
          return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
        }
        try { this.setKey("week", String(res.week)); } catch (err) {
          const r = err instanceof Refusal ? refuse(err.code, err.message) : refuse("STORE_UNAVAILABLE", String(err));
          return new Response(JSON.stringify(answered(id, false, null, r.refusal)), { headers: { "content-type": "application/json" } });
        }
        this.broadcast({ type: "state", ...this.stateFrame() });
        const out = answered(id, true, res);
        this.record(id, keyVerb, true, null, Date.now() - t0);
        return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
      }
      if (keyVerb === "tab") {
        if (res.active == null) {
          const out = answered(id, false, null, { token: "VERB_FAILED", detail: "the page answered tab without a read-back field 'active' - nothing was recorded" });
          this.record(id, keyVerb, false, "VERB_FAILED", ms);
          return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
        }
        try { this.setKey("tab", String(res.active)); } catch (err) {
          const r = err instanceof Refusal ? refuse(err.code, err.message) : refuse("STORE_UNAVAILABLE", String(err));
          return new Response(JSON.stringify(answered(id, false, null, r.refusal)), { headers: { "content-type": "application/json" } });
        }
        this.broadcast({ type: "state", ...this.stateFrame() });
        const out = answered(id, true, res);
        this.record(id, keyVerb, true, null, Date.now() - t0);
        return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
      }
      const out = answered(id, true, res);
      this.record(id, keyVerb, true, null, ms);
      return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
    }
    const out = answered(id, false, null, { token: "VERB_NOT_PAGE", detail: "the instance answers no verb " + JSON.stringify(keyVerb) + " - it owns status/state/ports/spawn/attach/terminal only; every other verb is answered by the page or the CLI" });
    this.record(id, keyVerb, false, "VERB_NOT_PAGE", Date.now() - t0);
    return new Response(JSON.stringify(out), { headers: { "content-type": "application/json" } });
  }

  // DESTROY (pinebox down --mode cloud): close every page socket with 4404 INSTANCE_DESTROYED and
  // wipe the instance's own storage. The BacktestLibrary is a different object and is untouched (R5).
  async onDestroy() {
    let closed = 0;
    for (const ws of this.sockets()) {
      try { ws.close(4404, "INSTANCE_DESTROYED"); closed++; } catch (err) {
        throw new Refusal("TEARDOWN_FAILED: a page socket would not close (" + (err instanceof Error ? err.message : String(err)) + ") - retry pinebox down");
      }
    }
    try { await this.state.storage.deleteAll(); } catch (err) {
      throw new Refusal("TEARDOWN_FAILED: the instance storage could not be wiped (" + (err instanceof Error ? err.message : String(err)) + ") - retry pinebox down");
    }
    return new Response(JSON.stringify({ ok: true, result: { destroyed: true, socketsClosed: closed } }), { headers: { "content-type": "application/json" } });
  }

  async onAttach(request) {
    let body = {};
    try { body = await request.json(); } catch { /* attach carries no required body */ }
    if (!body || typeof body.build !== "string" || !body.build) {
      return new Response(JSON.stringify(refuse("BUILD_UNAVAILABLE", "the attach carries no build id - the worker stamps build.json's build on PUT; redeploy the worker")), { status: 409, headers: { "content-type": "application/json" } });
    }
    const pairs = [["pair", body.pair], ["tf", body.tf], ["week", body.week], ["tab", body.tab], ["script_sha", body.scriptSha]];
    for (const [k, v] of pairs) {
      if (v != null) {
        try { this.setKey(k, String(v)); } catch (err) {
          const r = err instanceof Refusal ? refuse(err.code, err.message) : refuse("STORE_UNAVAILABLE", String(err));
          return new Response(JSON.stringify(r), { headers: { "content-type": "application/json" } });
        }
      }
    }
    {
      try { this.setKey("build", String(body.build)); } catch (err) {
        const r = err instanceof Refusal ? refuse(err.code, err.message) : refuse("STORE_UNAVAILABLE", String(err));
        return new Response(JSON.stringify(r), { headers: { "content-type": "application/json" } });
      }
    }
    this.broadcast({ type: "state", ...this.stateFrame() });
    return new Response(JSON.stringify({ ok: true, result: { attached: true, state: this.stateFrame() } }), { headers: { "content-type": "application/json" } });
  }

  async onState() {
    const rows = this.sql.exec("SELECT verb, COUNT(*) c, AVG(ms) p FROM events GROUP BY verb").toArray();
    const roles = {};
    for (const ws of this.sockets()) {
      try {
        const tag = ws.deserializeAttachment();
        if (tag && tag.role && ws.readyState === 1) roles[tag.role] = (roles[tag.role] || 0) + 1;   // OPEN sockets only
      } catch {
        throw new Refusal("SOCKET_STORE_UNAVAILABLE: a socket attachment could not be read - reload the page and retry");
      }
    }
    return new Response(JSON.stringify({ ok: true, state: this.stateFrame(), verbs: rows, roles, library_uid: this.getKey("library_uid") }), { headers: { "content-type": "application/json" } });
  }

  async webSocketMessage(ws, message) {
    let msg;
    if (typeof message === "string") {
      try { msg = JSON.parse(message); } catch {
        try { ws.send(JSON.stringify(refuse("BAD_OP", "the socket message must be JSON"))); } catch { /* closed */ }
        return;
      }
    } else {
      try { ws.send(JSON.stringify(refuse("BAD_OP", "the socket message must be a text frame"))); } catch { /* closed */ }
      return;
    }
    if (msg && msg.type === "pong" && typeof msg.pid === "string") {
      const done = this.pending.get(msg.pid);
      if (done) done();
      return;
    }
    // Page answers carry {rid, ok, result|refusal}.
    if (msg && typeof msg.rid === "string" && typeof msg.ok === "boolean") {
      const finish = this.pending.get(msg.rid);
      if (!finish) return;
      if (msg.ok) finish({ rid: msg.rid, ok: true, result: msg.result ?? null });
      else {
        const tok = (msg.refusal && msg.refusal.token) || "VERB_FAILED";
        const det = (msg.refusal && msg.refusal.detail) || "the page refused without detail";
        finish({ rid: msg.rid, ok: false, refusal: { token: tok, detail: det } });
      }
      return;
    }
    // Page state pushes rebroadcast to every viewer.
    if (msg && msg.type === "state" && msg.state) {
      this.broadcast({ type: "state", ...this.stateFrame() });
      return;
    }
  }

  async webSocketClose(ws, code, reason) {
    try { ws.close(code, reason); } catch { /* already closed */ }
  }

  async webSocketError(ws, error) {
    try { ws.close(1011, String((error && error.message) || "socket error")); } catch { /* already closed */ }
  }
}

export default PineboxInstance;
