# PINEBOX CLOUD - THE CLOUDFLARE ARCHITECTURE (as built and measured, 2026-11-08)

**What this document is:** the permanent record of how `pinebox up --mode cloud` works. It covers the Cloudflare
objects, the code that runs in each place, the wire contracts, the naming, the deploy procedure, the failure modes and
the measured evidence. The design authority is `design/DESIGN_BLUEPRINT_PINEBOX_CLOUD_v1.md`; this file records what was
actually built against it. Every path is relative to the repo root `/home/leviathan/JARVIS_WORKSPACE/Shared_Workspace/PINEBOX`
unless it is absolute.

**Repo HEAD when written:** `c15f483`. **Deployed worker:** `pinebox-cloud` on account `973c234c2f4bfc9086089ab1364d10bb`.

---

## 1. THE ONE-PARAGRAPH ANSWER

Pinebox Cloud is **hosted by Cloudflare and runs in whatever browser opens it**. A Cloudflare Worker named
`pinebox-cloud` serves the whole Pinebox web app (the Pine IDE, the chart, the backtest room) as static files. It also
runs the backend in two Durable Objects. `PineboxInstance` (one per Pinebox instance) holds the instance's live state
and relays the agent's verbs to the page. `BacktestLibrary` (one for the whole account) is the durable backtest store.
No physical machine hosts the app. The Linux box is only where the agent's CLI (`pinebox`) runs. The page is drawn by
the browser that opened the URL: Orca on the Mac, plain Chrome on Linux, or a browser in Cloudflare's own datacenter
(all three measured, section 10). The agent never touches the page directly. It sends a verb over HTTPS to the
instance object, the object forwards it over the page's WebSocket, the page does the work and answers.

---

## 2. THE MAP

```
 ┌───────────── CLOUDFLARE (account 973c234c…, workers.dev) ─────────────┐
 │  Worker "pinebox-cloud"  src/worker.ts (331 lines)                    │
 │   ├─ static assets  ./dist-web  (binding ASSETS)                      │
 │   │    /i/<inst>  -> pine.html + base href + storage namespace        │
 │   ├─ /api/v1/i/<inst>/{socket,verb,state,attach}  -> INSTANCE         │
 │   ├─ /api/v1/i/<inst>/room/*   src/room-http.ts  -> LIBRARY           │
 │   ├─ /api/v1/i/<inst>/rail/*   src/rail-http.ts  (Pine run, VIL)      │
 │   ├─ /api/v1/chart/{cells,bars}, /api/v1/bars  (bundled bars)         │
 │   └─ /build.json  (the served build id)                               │
 │                                                                       │
 │  DO class PineboxInstance  src/instance.ts (606 lines)                │
 │    one object per "<session>:<id>"  (idFromName)                      │
 │    SQLite: instance(key,value) + events(verb log)                     │
 │    holds the page's WebSocket (hibernation API)                       │
 │                                                                       │
 │  DO class BacktestLibrary  src/library.ts (942 lines)                 │
 │    ONE object: idFromName("library")                                  │
 │    SQLite: every backtest session, order, fill, journal row           │
 │    replay engine src/room/replay.mjs (980) + stats.mjs (165)          │
 └──────────┬───────────────────────────────────────────▲────────────────┘
            │ HTTPS: the files + WebSocket (verbs)      │ HTTPS: verbs
            ▼                                           │ Bearer agent token
 ┌──────────────────────────────┐        ┌──────────────┴──────────────┐
 │ ANY BROWSER  (renders it)    │        │ LINUX BOX  (agent only)     │
 │ web/pinebox-page.js (1419)   │        │ ~/.local/bin/pinebox        │
 │  the page agent: answers     │        │  stages/cloud.sh            │
 │  verbs, runs Pine in a       │        │  cloud_up / cloud_verb /    │
 │  Web Worker (pine-worker.js) │        │  cloud_down                 │
 │ Orca tab on Mac / Chrome /   │        │ (no Pinebox page served     │
 │ Cloudflare remote browser    │        │  from here)                 │
 └──────────────────────────────┘        └─────────────────────────────┘
```

---

## 3. WHAT EXISTS IN THE CLOUDFLARE ACCOUNT (measured 2026-11-08 through the API)

Command: `GET /accounts/973c…/workers/scripts` and `GET /workers/durable_objects/namespaces` with the token in
`~/.config/pinebox/cf.env`.

| Kind | Name | What it is | Status |
|---|---|---|---|
| Worker | `pinebox-cloud` | THE Pinebox Cloud app + API | production |
| DO namespace | `pinebox-cloud` / `PineboxInstance` | one object per instance | production |
| DO namespace | `pinebox-cloud` / `BacktestLibrary` | the single backtest store | production |
| Worker | `pinebox-cloud-probe` | W3 latency probe (DO echo socket, 30/30, p50 99 ms) | measurement artifact, kept |
| workers.dev subdomain | `cryptoforex36963` | gives `https://pinebox-cloud.cryptoforex36963.workers.dev` | production URL |
| Workers (deleted) | `pinebox-cloud-dev-agent`, `-dev-modprobe`, `-dev-reload`, `-dev-rollover`, `-dev-room` | throwaway copies used to prove fixes before touching main | **deleted 2026-11-08** (API DELETE, success:true) |

**Naming rule:** everything Pinebox owns starts with `pinebox-`. The production worker is exactly `pinebox-cloud`.
Any `pinebox-cloud-dev-<topic>` is temporary and must be deleted when its proof is done. Other workers in the account
belong to other projects. Find Pinebox's with `jq -r '.result[].id' | grep '^pinebox-'`.

**What is NOT in the account:** no custom domain, no R2 bucket, no KV namespace, no D1 database, no Queues. All durable
state is Durable Object SQLite. The URL is the free `workers.dev` route.

---

## 4. THE CONFIG (`pinebox-cloud/wrangler.jsonc`, verbatim)

```jsonc
{
  "name": "pinebox-cloud",
  "main": "src/worker.ts",
  "compatibility_date": "2025-01-01",
  "assets": { "directory": "./dist-web", "binding": "ASSETS" },
  "migrations": [ { "tag": "v2", "new_sqlite_classes": ["PineboxInstance", "BacktestLibrary"] } ],
  "durable_objects": { "bindings": [
      { "name": "INSTANCE", "class_name": "PineboxInstance" },
      { "name": "LIBRARY",  "class_name": "BacktestLibrary" } ] },
  "build": { "command": "bash tools/build-web.sh" }
}
```

`build.command` runs on every `wrangler deploy`. `tools/build-web.sh` (38 lines) does four things:
1. derives `dist-web/charts/workbench.bundle.js` from the fork's chart bundle with no loopback defaults (refuses `DIST_LOOPBACK_PRESENT`);
2. writes `dist-web/build.json` with `build` = a content hash of every served file;
3. writes `src/code-version.ts` (the code version baked into the worker);
4. builds `dist-web/tabs/pine-ide/pine-worker.js` (`tools/build-pine-worker.sh`).

---

## 5. THE SOURCE TREE (`pinebox-cloud/`)

```
pinebox-cloud/
├── wrangler.jsonc            the Cloudflare config (section 4)
├── src/                      runs IN CLOUDFLARE
│   ├── worker.ts       331   the router (section 6)
│   ├── instance.ts     606   PineboxInstance DO (section 7)
│   ├── library.ts      942   BacktestLibrary DO (section 8)
│   ├── room-http.ts    511   /room/* -> library ops (the room control contract)
│   ├── rail-http.ts    404   /rail/* (Pine artifacts, VIL ledger rows, run records)
│   ├── code-stamp.ts    32   the code version on every object call (CODE_ROLLOVER)
│   ├── code-version.ts   2   generated by build-web.sh
│   └── room/replay.mjs 980   the replay engine (byte-identical to the local fork's copy)
│       room/stats.mjs  165   edge statistics
├── web/                      the page sources
│   ├── pinebox-page.js 1419  the page agent (section 9)
│   └── pine-worker.js   485  Pine engine (PineTS) as a dedicated Web Worker
├── dist-web/                 THE SERVED FILES (static assets)
│   ├── pine.html, styles.css, tokens.css, build.json, pinebox-page.js, prediction.js
│   ├── charts/workbench.bundle.js   the chart (LuxAlgo Vela based)
│   ├── tabs/  pineshell.js, _shell.js, backtest.js, pine-ide/* (real files, NOT a symlink - F-2xx)
│   ├── vendor/, assets/
├── tools/  build-web.sh, build-pine-worker.sh, deploy-look.sh
├── cloud-map.json            26 CLI verbs -> who answers each in cloud mode
└── test/   w4.mjs + RESULTS.md (parity/durable/ambiguity/UTC against the deployed worker)
```

---

## 6. THE WORKER ROUTER (`src/worker.ts`)

| Route | Method | Handler | Auth | Notes |
|---|---|---|---|---|
| `/`, `/i/<inst>` | GET | serves `pine.html` with `<base href="/">` and a per-instance `localStorage` namespace script | `k=<session>` capability | page URL: `/i/<session>:<id>?k=<session>` |
| `/pinebox-page.js` | GET | the page agent | none | static |
| `/assets/*`, `/tabs/*`, `/charts/*` … | GET | `ASSETS` binding | none | static |
| `/api/v1/i/<inst>` | PUT | create the instance (stores pair/tf/week/build) | Bearer | `cloud_up` |
| `/api/v1/i/<inst>` | DELETE | destroy: closes sockets, `deleteAll()` storage | Bearer | `cloud_down`; absent afterwards -> `INSTANCE_ABSENT` 404 |
| `/api/v1/i/<inst>/socket` | GET Upgrade | the page's WebSocket (`role=primary|viewer`, `k`, `build`) | `k` | `PAGE_ALREADY_ATTACHED` 409, `PAGE_STALE` |
| `/api/v1/i/<inst>/verb` | POST `{verb,args}` | relay to the page or answer locally (`status`, `state`) | Bearer | `VERB_TIMEOUT`, `PAGE_ABSENT` |
| `/api/v1/i/<inst>/state` | GET | the instance's stored state + roles | Bearer | |
| `/api/v1/i/<inst>/room/*` | * | `handleRoom` -> BacktestLibrary | page cookie capability | the backtest room |
| `/api/v1/i/<inst>/rail/*` | * | `handleRail` | page cookie capability | Pine run records, artifacts |
| `/api/v1/library/op` | POST | library op | Bearer | |
| `/api/v1/chart/cells`, `/api/v1/chart/bars`, `/api/v1/bars` | GET | the bundled fixture bars (canon weeks) | none | `FIXTURE_CELL_ABSENT` named |
| `/api/v1/e1/zones` | GET | E1 zone lines for the room chart | none | |
| `/build.json` | GET | `{build}` the served build id | none | |

**Auth model:**
- **The agent bearer** `PINEBOX_AGENT_TOKEN` is read from `~/.config/pinebox/cf.env`; the CLI refuses `AGENT_TOKEN_UNAVAILABLE` without it. Missing -> `AUTH_REQUIRED` 401.
- **The page capability** is `k=<session>` in the URL. Wrong -> `CAPABILITY_INVALID` 403.
- **The Cloudflare API token** (`CLOUDFLARE_API_TOKEN`, same file, mode 600) is for `wrangler deploy` and the account API only. It is never sent to the worker.

---

## 7. `PineboxInstance` (`src/instance.ts`)

```
 PUT /api/v1/i/S:N ──► fetch() :195 ──► stores build/pair/tf/week (setKey)
 page WS upgrade ───► onSocket() :289
                       role=primary already OPEN?
                         └─ ping it (primaryAnswers 2 s)
                              pong  -> 409 PAGE_ALREADY_ATTACHED
                              none  -> close old 4408
                                       PAGE_UNRESPONSIVE_REPLACED, accept
                       build != served -> {type:reload} 4409 PAGE_STALE
 POST verb ─────────► onVerb() :331
                       status/state answered locally (SQLite)
                       else -> primarySocket().send({type:verb,rid,…})
                            -> pending.set(rid) -> await answer or
                               VERB_TIMEOUT; no socket -> PAGE_ABSENT
 page message ──────► webSocketMessage() :562  {rid,ok,result|refusal}
                       or {type:pong,pid}  -> resolves pending
 DELETE ────────────► onDestroy() :510  close sockets, deleteAll()
```

- **Identity:** `env.INSTANCE.idFromName("<session>:<id>")`. The CLI instance `pinebox-native` id 2 is object `pinebox-native:2`.
- **Storage:** SQLite tables `instance(key TEXT PRIMARY KEY, value TEXT)` and `events(rid, verb, ok, token, ms, at)`. `status` aggregates `events` per verb.
- **Hibernation:** sockets use `state.acceptWebSocket` with a serialized `{role}` attachment, so an idle instance costs nothing and wakes on the next message. Roles count only OPEN sockets.
- **Liveness takeover (2026-11-08, commit `cd3cfef`, deployed with `c15f483`):** a page that vanished, such as a closed remote browser or a sleeping device, used to block the instance forever (`PAGE_ALREADY_ATTACHED`). Now a new primary pings the old one. If no pong arrives in 2 s, the old socket is closed 4408 and the new page takes over.

---

## 8. `BacktestLibrary` (`src/library.ts`, `src/room-http.ts`, `src/room/replay.mjs`)

- **Identity:** ONE object for the account, `idFromName("library")`. Every backtest session from every instance lives here. It survives `down`/`up`; only `--op delete --uid` removes a session (operator ruling R5).
- **Ops** (`library.ts` switch, lines 505-861): `create state window summary fills eventsrows play pause step speed date jump stop place modify close cancel note list open export delete`.
- **Replay engine:** `room/replay.mjs` is byte-identical to `pinebox-cli/fork/dashboard/backtest-room/replay.mjs`, so the local and cloud rooms run the same code. Default start = the middle bar (F-280); an explicit start date wins; a bad date -> `BAD_DATE`.
- **Code rollover:** a long-lived object keeps old code for minutes after a deploy. `code-stamp.ts` stamps every call with the worker's code version, and a mismatched object answers `CODE_ROLLOVER` and restarts, so the retry runs the new code (F-276).
- **Data:** bars come from the bundled fixture (`/api/v1/chart/cells`: canon weeks, e.g. DXY 1H 382 bars). No live market feed is connected to the cloud room yet (section 12).

---

## 9. THE PAGE (`web/pinebox-page.js`, served as `dist-web/pinebox-page.js`)

1. Reads the instance from the path (`/i/<inst>`) and `k` from the query. It opens `wss://…/api/v1/i/<inst>/socket?role=primary&k=…&build=<build.json>`.
2. Boots the shell to the instance's stored market (`bootToState`) and mounts the Pine IDE (`window.PlutusPineShell`) and the room (`window.PlutusBacktestRoom`).
3. Answers each `{type:"verb"}` with `{rid, ok, result|refusal}`: asset, tf, week, load, run, insert, editor, chart, widget, tab, backtest, shot, look, verify, drive, view, phase, state. It answers `{type:"ping"}` with `{type:"pong"}`.
4. Pine runs in a dedicated Web Worker (`tabs/pine-ide/pine-worker.js`, the PineTS engine). Nothing calls the Linux box: the loopback census of `dist-web` is 0 (enforced by `build-web.sh`).
5. Reconnects with backoff (500 ms × 2^n, max 15 s) and shows `REFUSED PAGE_ABSENT … reconnecting (attempt N)` in a banner until the socket is OPEN.

---

## 10. HOW IT RUNS ON DIFFERENT DEVICES (all measured 2026-11-08)

| Where the browser is | How it was opened | What the page reported | Driven by verbs from Linux | Evidence |
|---|---|---|---|---|
| Orca tab on the operator's Mac | `pinebox up --mode cloud` (`orca open-url`) | `tz Asia/Riyadh`, `MacIntel`, 1377x933, **60 fps p95 18 ms** | yes: asset/tab/backtest, real wheel/drag | `reports/proof-2026-11-08/native/{up,where,fps}.txt`, `device-tab-from-linux.png` |
| Plain Google Chrome 154 on the Linux box (no Orca) | the URL in `--app` mode on an isolated display | `{"ua":"Chrome/154.0.0.0","orca":false,"tz":"Asia/Dubai","vp":"1580x904","ws":1}`, **60 fps** (299 frames) | yes: `{"ok":true,"sym":"EURUSD","bars":511}`, `{"ok":true,"tf":"4H","bars":128}`, `{"ok":true,"active":"backtest"}` | `plain-chrome-linux.png` |
| A browser in Cloudflare's datacenter (Browser Rendering API) | the URL, nothing else installed | attached in 2 s; rendered the full IDE + chart | yes: `{"ok":true,"sym":"GBPUSD","bars":511}`, `{"ok":true,"tf":"4H","bars":128}`, editor closed `{"ok":true}` - all three visible in the remote browser's own final frame (GBPUSD · 4h, editor panel gone) | `cloudflare-browser-remote-driven.png` (render http=200, 76116 bytes) |

The third row is the "any device" proof: a machine the operator and the agent don't own loaded the URL and rendered
Pinebox itself. The agent then drove that page from the Linux box through the instance object. Its first attempt was
refused (`PAGE_ALREADY_ATTACHED` held by an earlier render that had exited), which led to the liveness takeover in section 7.

**Latency, measured (F-259):**
- The operator's own interaction (drag, zoom, typing) runs in the local browser at 60 fps.
- An agent verb takes about 226 ms typical / 255 ms p95 on a warm connection, because it makes two trips (Linux -> Cloudflare, Cloudflare -> the page's device).
- The CLI end-to-end is about 477 ms p50, because process start and TLS are included.

---

## 11. THE CLI SIDE (`pinebox-cli/stages/cloud.sh`, `pinebox-cli/pinebox`)

| Function | What it does | Refusals by name |
|---|---|---|
| `cf METHOD PATH [BODY]` | curl to `CLOUD_BASE` with the agent bearer | `AGENT_TOKEN_UNAVAILABLE`, `CLOUD_UNREACHABLE` |
| `cloud_up ID SESSION` | PUT the instance; `orca open-url` the page on the device; waits for socket OPEN + IDE mounted; rejects a host-rendered page | `ORCA_SESSION_ABSENT`, `ORCA_DEVICE_HOST_ABSENT`, `ORCA_PAGE_STREAMED`, `INSTANCE_LIVE` |
| `cloud_verb ID VERB ARGS SESSION` | POST the verb, print the answer | the page's own tokens |
| `cloud_down ID` | closes the Orca tab, DELETEs the instance (addresses the record's own URL) | `TEARDOWN_FAILED` |
| `cloud_relay` (in `pinebox`) | serializes CLI flags to `{verb,args}`; `step --n N` = N `{op:step,delta:1}` | |
| `cloud_shot` | writes the page's own capture to `--out` | |

**Orca placement:** `orca open-url` puts the page in the browser of the desktop that hosts the calling terminal.
`orca tab create` would instead render it on Linux and stream JPEGs; that path is removed and refused (F-278, F-279).
The desktop must have registered as this server's page host once, by opening any browser tab in the workspace
(Cmd+Shift+B). After that, `up` opens tabs with no click. They land in the background (F-281 open).

---

## 12. WHAT IS NOT DONE (honest gaps)

| # | Gap | Mechanism | Next |
|---|---|---|---|
| 1 | Room data is the bundled canon week only | `/api/v1/chart/cells` serves fixtures; the TV FEED option has no source (local `PLUTUS_TV_FEED=http://127.0.0.1:1`, cloud `/tv-cells` refuses) | connect a real market-data source with a date-range selector (report v1 §7) |
| 2 | The 5000-bar request size | our constants: tv-feed `MAX_LIMIT=5000`, `bars.mjs limit:'5000'` | removed with gap 1 |
| 3 | A tool-opened tab lands in the background on the Mac | Orca: `tab switch --focus` updates only the server's session snapshot | open (F-281) |
| 4 | Verb latency 226/255 ms | two network trips by construction | design change only (F-259) |
| 5 | No custom domain | workers.dev route | operator decision |

---

## 13. DEPLOY + VERIFY (the exact procedure)

```bash
cd /home/leviathan/JARVIS_WORKSPACE/Shared_Workspace/PINEBOX/pinebox-cloud
source ~/.config/pinebox/cf.env
CLOUDFLARE_ACCOUNT_ID=973c234c2f4bfc9086089ab1364d10bb CLOUDFLARE_API_TOKEN="$CLOUDFLARE_API_TOKEN" \
  /home/leviathan/JARVIS_WORKSPACE/Shared_Workspace/PLUTUS_VISION/archive/cf-draft-2026-11-01/node_modules/.bin/wrangler \
  deploy --config wrangler.jsonc
cd .. && git add pinebox-cloud/src/code-version.ts pinebox-cloud/dist-web/build.json && git commit -m "build(cloud): ids"
curl -s https://pinebox-cloud.cryptoforex36963.workers.dev/build.json | jq -r .build     # == dist-web/build.json
```

Verify on a real page, not with curl alone:
1. `pinebox up --session X --mode cloud` -> READY;
2. `pinebox asset --session X --get` -> `ok:true`;
3. open a capture of the tab;
4. `pinebox down --session X --all` -> the tab is gone and `GET …/state` answers `INSTANCE_ABSENT`.

---

## 14. FAILURE MODES (each named; none falls back)

| Token | Where | Meaning | Remedy |
|---|---|---|---|
| `AUTH_REQUIRED` 401 | worker | no/wrong bearer | `PINEBOX_AGENT_TOKEN` in cf.env |
| `CAPABILITY_INVALID` 403 | worker | wrong `k` | use the URL `up` printed |
| `INSTANCE_ABSENT` 404 | worker | never created / destroyed | `pinebox up` |
| `PAGE_ABSENT` | instance | no page attached | open the page / wait for reconnect |
| `PAGE_ALREADY_ATTACHED` 409 | instance | a LIVE page holds primary | close it or attach as viewer |
| `PAGE_UNRESPONSIVE_REPLACED` 4408 | instance | a silent primary was replaced | none (informational close code) |
| `PAGE_STALE` 4409 | instance | the page runs an older build | it reloads itself |
| `VERB_TIMEOUT` | instance | page did not answer in the deadline | check the page |
| `CODE_ROLLOVER` | objects | object on old code after a deploy | retry |
| `STORE_UNAVAILABLE` / `STORE_FULL` | objects | SQLite failed / full | redeploy migration / down+up |
| `FIXTURE_CELL_ABSENT` | worker | no bundled bars for pair/tf/week | pick an existing cell |
| `ORCA_DEVICE_HOST_ABSENT` | CLI | the desktop never registered | one Cmd+Shift+B on the desktop |
| `ORCA_PAGE_STREAMED` | CLI | page ran in the host's time zone | refused by design |
| `TEARDOWN_FAILED` | CLI | DELETE failed | retry down |

---

## 15. HISTORY OF THE DEFECTS THIS ARCHITECTURE FIXED

The full entries are in `ship-docs/FAILURE_LOG.md` (F-244..F-281) and `ship-docs/DEBUG_LOG.md` (EN-217..EN-222).
The architecturally important ones:
- **F-24x:** the page had never been opened in a real browser (scripts 403, socket refused on build-id mismatch).
- the cloud page silently used Linux services (loopback); now the census is 0;
- `down` deleted nothing; `/destroy` now really deletes;
- a symlink sent cloud edits into the local Pinebox;
- instances shared one editor (now per-instance storage namespace);
- **F-276:** stale object code after a deploy (code stamp);
- **F-278/F-279:** the streamed tab (0.6 frames/s) replaced by device placement;
- **F-280:** the room started with no history;
- **2026-11-08:** a vanished page blocked its instance forever; fixed by the liveness takeover.
